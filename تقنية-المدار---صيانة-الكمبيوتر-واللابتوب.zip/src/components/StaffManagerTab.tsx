import { FormEvent, useState } from 'react';
import {
  CheckSquare,
  Edit3,
  Plus,
  Shield,
  Trash2,
  UserCheck,
  UserPlus,
  UserX,
  X,
} from 'lucide-react';
import type { CustomerOrder, PermissionKey, StaffUser } from '../types';
import { formatArabicDate, PERMISSION_OPTIONS } from '../utils/format';

interface StaffManagerTabProps {
  authToken: string;
  staffUsers: StaffUser[];
  orders: CustomerOrder[];
  onStaffChange: (users: StaffUser[]) => void;
  onAuthError: () => void;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

export function StaffManagerTab({
  authToken,
  staffUsers,
  orders,
  onStaffChange,
  onAuthError,
  onSuccess,
  onError,
}: StaffManagerTabProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffUser | null>(null);
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [roleTitle, setRoleTitle] = useState('مهندس صيانة');
  const [password, setPassword] = useState('');
  const [permissions, setPermissions] = useState<PermissionKey[]>([
    'view_orders',
    'update_order_status',
  ]);
  const [active, setActive] = useState(true);
  const [saving, setSaving] = useState(false);

  const authHeaders = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${authToken}`,
  };

  const openCreate = () => {
    setEditingStaff(null);
    setName('');
    setUsername('');
    setRoleTitle('مهندس صيانة');
    setPassword('');
    setPermissions(['view_orders', 'update_order_status']);
    setActive(true);
    setModalOpen(true);
  };

  const openEdit = (staff: StaffUser) => {
    setEditingStaff(staff);
    setName(staff.name);
    setUsername(staff.username);
    setRoleTitle(staff.roleTitle);
    setPassword('');
    setPermissions(staff.permissions);
    setActive(staff.active);
    setModalOpen(true);
  };

  const togglePermission = (key: PermissionKey) => {
    setPermissions((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    onError('');
    setSaving(true);
    try {
      const payload = editingStaff
        ? {
            name: name.trim(),
            username: username.trim(),
            roleTitle: roleTitle.trim(),
            permissions,
            active,
            newPassword: password || undefined,
          }
        : {
            name: name.trim(),
            username: username.trim(),
            roleTitle: roleTitle.trim(),
            password,
            permissions,
            active,
          };

      const url = editingStaff ? `/api/staff/${editingStaff.id}` : '/api/staff';
      const method = editingStaff ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: authHeaders,
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError(data.error || 'تعذر حفظ حساب الموظف.');
        return;
      }

      const saved = data as StaffUser;
      if (editingStaff) {
        onStaffChange(staffUsers.map((u) => (u.id === saved.id ? saved : u)));
        onSuccess(`تم تحديث بيانات وصلاحيات "${saved.name}" بنجاح.`);
      } else {
        onStaffChange([saved, ...staffUsers]);
        onSuccess(`تم إنشاء حساب "${saved.name}" بصلاحياته المحددة.`);
      }
      setModalOpen(false);
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (staff: StaffUser) => {
    onError('');
    try {
      const res = await fetch(`/api/staff/${staff.id}`, {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify({ active: !staff.active }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError(data.error || 'تعذر تغيير حالة الحساب.');
        return;
      }
      const updated = data as StaffUser;
      onStaffChange(staffUsers.map((u) => (u.id === updated.id ? updated : u)));
      onSuccess(
        updated.active
          ? `تم تفعيل حساب "${updated.name}".`
          : `تم إيقاف دخول "${updated.name}" مؤقتاً.`
      );
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    }
  };

  const handleDelete = async (staff: StaffUser) => {
    onError('');
    try {
      const res = await fetch(`/api/staff/${staff.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError('تعذر حذف حساب الموظف.');
        return;
      }
      onStaffChange(staffUsers.filter((u) => u.id !== staff.id));
      onSuccess(`تم حذف حساب "${staff.name}".`);
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    }
  };

  const permissionLabel = (key: PermissionKey): string =>
    PERMISSION_OPTIONS.find((p) => p.key === key)?.label || key;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            حسابات العمال والموظفين والصلاحيات
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            أنشئ حسابات للمهندسين والموظفين بصلاحيات محددة، وتابع آخر دخول لهم والطلبات التي قاموا بتحديثها.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة موظف / عامل جديد</span>
        </button>
      </div>

      {staffUsers.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-3">
          <UserPlus className="w-8 h-8 text-slate-400 mx-auto" />
          <div className="space-y-1">
            <p className="text-sm font-semibold text-slate-800">
              لا توجد حسابات موظفين مسجلة حالياً
            </p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              أضف حساباً لفني الصيانة أو موظف المتابعة وحدد صلاحياته (مثل متابعة الطلبات وتحديث
              حالتها فقط)، ويمكنه تسجيل الدخول من رابط «دخول الموظفين» أسفل الصفحة.
            </p>
          </div>
          <button
            type="button"
            onClick={openCreate}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة أول موظف</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {staffUsers.map((staff) => {
            const updatedOrdersCount = orders.filter(
              (o) => o.lastUpdatedBy === staff.name
            ).length;

            return (
              <div
                key={staff.id}
                className={`bg-white border rounded-xl p-5 flex flex-col justify-between gap-4 ${
                  staff.active ? 'border-slate-200' : 'border-slate-200 bg-slate-50/70 opacity-80'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-1">
                        <span
                          className={`font-semibold ${
                            staff.active ? 'text-emerald-700' : 'text-red-700'
                          }`}
                        >
                          {staff.active ? 'حساب نشط' : 'حساب موقوف'}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{staff.roleTitle}</span>
                        <span aria-hidden="true">·</span>
                        <span dir="ltr" className="font-mono-nums text-slate-600">
                          {staff.username}
                        </span>
                      </div>
                      <h3 className="font-display text-base font-bold text-slate-900">
                        {staff.name}
                      </h3>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleActive(staff)}
                        aria-label={staff.active ? 'إيقاف الحساب' : 'تفعيل الحساب'}
                        title={staff.active ? 'إيقاف الحساب مؤقتاً' : 'إعادة تفعيل الحساب'}
                        className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer"
                      >
                        {staff.active ? (
                          <UserX className="w-4 h-4" />
                        ) : (
                          <UserCheck className="w-4 h-4 text-emerald-700" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => openEdit(staff)}
                        aria-label={`تعديل صلاحيات ${staff.name}`}
                        className="p-2 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(staff)}
                        aria-label={`حذف ${staff.name}`}
                        className="p-2 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Assigned Permissions Summary */}
                  <div className="border-t border-slate-100 pt-3">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-1.5">
                      <Shield className="w-3.5 h-3.5 text-blue-700" />
                      <span>الصلاحيات المحددة ({staff.permissions.length}):</span>
                    </div>
                    {staff.permissions.length > 0 ? (
                      <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-slate-600">
                        {staff.permissions.map((perm, idx) => (
                          <span key={perm}>
                            {idx > 0 && <span className="text-slate-300 me-2">·</span>}
                            {permissionLabel(perm)}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-amber-700">
                        لا توجد صلاحيات مفعلة لهذا الحساب حالياً.
                      </p>
                    )}
                  </div>
                </div>

                {/* Worker Activity Tracking Footer */}
                <div className="border-t border-slate-100 pt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 tabular-nums">
                  <span>
                    الطلبات المحدثة بواسطته:{' '}
                    <strong className="text-slate-900">{updatedOrdersCount}</strong>
                  </span>
                  <span>
                    {staff.lastLoginAt
                      ? `آخر دخول: ${formatArabicDate(staff.lastLoginAt)}`
                      : 'لم يسجل الدخول بعد'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create / Edit Staff Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 shadow-xl my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingStaff ? 'تعديل حساب وصلاحيات الموظف' : 'إضافة موظف / عامل جديد'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الاسم الكامل
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: م. كريم حسن"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    المسمى الوظيفي
                  </label>
                  <input
                    type="text"
                    required
                    value={roleTitle}
                    onChange={(e) => setRoleTitle(e.target.value)}
                    placeholder="مثال: فني صيانة هاردوير"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    اسم المستخدم للدخول
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    required
                    minLength={3}
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="karim"
                    className="w-full text-start font-mono-nums px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {editingStaff ? 'كلمة مرور جديدة (اختياري)' : 'كلمة المرور'}
                  </label>
                  <input
                    type="password"
                    dir="ltr"
                    required={!editingStaff}
                    minLength={4}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={editingStaff ? 'اتركه فارغاً للإبقاء على الحالية' : '••••••'}
                    className="w-full text-start px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
              </div>

              {/* Granular Permissions Picker */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5">
                    <CheckSquare className="w-3.5 h-3.5 text-blue-700" />
                    <span>تحديد الصلاحيات المسموحة لهذا الحساب</span>
                  </span>
                  <div className="flex items-center gap-2 text-[11px]">
                    <button
                      type="button"
                      onClick={() =>
                        setPermissions(PERMISSION_OPTIONS.map((p) => p.key))
                      }
                      className="text-blue-700 hover:underline cursor-pointer"
                    >
                      تحديد الكل
                    </button>
                    <span className="text-slate-300">|</span>
                    <button
                      type="button"
                      onClick={() => setPermissions([])}
                      className="text-slate-500 hover:underline cursor-pointer"
                    >
                      إلغاء الكل
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-2 max-h-56 overflow-y-auto p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  {PERMISSION_OPTIONS.map((opt) => {
                    const checked = permissions.includes(opt.key);
                    return (
                      <label
                        key={opt.key}
                        className={`flex items-start gap-2.5 p-2 rounded-lg border cursor-pointer transition-colors ${
                          checked
                            ? 'bg-white border-blue-200'
                            : 'bg-transparent border-transparent hover:bg-white/60'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => togglePermission(opt.key)}
                          className="w-4 h-4 mt-0.5 accent-blue-700 shrink-0"
                        />
                        <div className="text-xs">
                          <div className="font-semibold text-slate-900">{opt.label}</div>
                          <div className="text-slate-500 mt-0.5">{opt.description}</div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={active}
                  onChange={(e) => setActive(e.target.checked)}
                  className="w-4 h-4 accent-blue-700"
                />
                <span className="text-xs font-semibold text-slate-800">
                  تفعيل الحساب والسماح بتسجيل الدخول
                </span>
              </label>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {saving ? 'جاري الحفظ...' : 'حفظ الموظف'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
