import { ChangeEvent, FormEvent, useEffect, useRef, useState } from 'react';
import { Globe, Phone, Plus, RotateCcw, Save, Trash2, Upload } from 'lucide-react';
import type { SiteSettings, SocialPlatform } from '../types';
import {
  DEFAULT_SITE_SETTINGS,
  OFFER_IMAGE_PRESETS,
  SOCIAL_PLATFORM_OPTIONS,
} from '../utils/format';
import { ResilientImage } from './ResilientImage';
import { SocialBrandIcon } from './SocialBrandIcon';

interface SiteSettingsManagerTabProps {
  authToken: string;
  siteSettings: SiteSettings;
  onSiteSettingsChange: (settings: SiteSettings) => void;
  onAuthError: () => void;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

export function SiteSettingsManagerTab({
  authToken,
  siteSettings,
  onSiteSettingsChange,
  onAuthError,
  onSuccess,
  onError,
}: SiteSettingsManagerTabProps) {
  const [draft, setDraft] = useState<SiteSettings>(() =>
    JSON.parse(JSON.stringify(siteSettings)) as SiteSettings
  );
  const [saving, setSaving] = useState(false);
  const [uploadingField, setUploadingField] = useState<'hero' | 'logo' | null>(null);
  const heroFileRef = useRef<HTMLInputElement | null>(null);
  const logoFileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setDraft(JSON.parse(JSON.stringify(siteSettings)) as SiteSettings);
  }, [siteSettings]);

  const authHeaders = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${authToken}`,
  };

  const handleImageUpload = async (
    e: ChangeEvent<HTMLInputElement>,
    target: 'hero' | 'logo'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    onError('');

    if (!file.type.startsWith('image/')) {
      onError('يرجى اختيار ملف صورة صالح (JPG, PNG, WEBP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      onError('الحد الأقصى لحجم الصورة هو 5 ميجابايت.');
      return;
    }

    setUploadingField(target);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('read_error'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ dataUrl, filename: file.name }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError(data.error || 'تعذر رفع الصورة.');
        return;
      }
      if (target === 'hero') {
        setDraft((prev) => ({ ...prev, heroImageUrl: data.url as string }));
      } else {
        setDraft((prev) => ({ ...prev, logoUrl: data.url as string }));
      }
    } catch {
      onError('حدث خطأ أثناء رفع الصورة.');
    } finally {
      setUploadingField(null);
      if (heroFileRef.current) heroFileRef.current.value = '';
      if (logoFileRef.current) logoFileRef.current.value = '';
    }
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    onError('');
    setSaving(true);
    try {
      const res = await fetch('/api/site-settings', {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify(draft),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError(data.error || 'تعذر حفظ إعدادات الصفحة الرئيسية.');
        return;
      }
      const saved = data as SiteSettings;
      onSiteSettingsChange(saved);
      onSuccess('تم حفظ نصوص وصور الصفحة الرئيسية وأرقام التواصل وصفحات السوشيال ميديا بنجاح.');
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    } finally {
      setSaving(false);
    }
  };

  const addPhone = () => {
    setDraft((prev) => ({
      ...prev,
      contactPhones: [
        ...prev.contactPhones,
        {
          id: `ph-${Date.now().toString(36)}`,
          label: 'رقم تواصل إضافي',
          number: '',
        },
      ],
    }));
  };

  const removePhone = (id: string) => {
    setDraft((prev) => ({
      ...prev,
      contactPhones: prev.contactPhones.filter((p) => p.id !== id),
    }));
  };

  const addSocialLink = (platform: SocialPlatform = 'facebook') => {
    const opt = SOCIAL_PLATFORM_OPTIONS.find((o) => o.value === platform);
    setDraft((prev) => ({
      ...prev,
      socialLinks: [
        ...prev.socialLinks,
        {
          id: `soc-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`,
          platform,
          label: opt ? opt.label.split(' ')[0] : platform,
          url: '',
        },
      ],
    }));
  };

  const removeSocialLink = (id: string) => {
    setDraft((prev) => ({
      ...prev,
      socialLinks: prev.socialLinks.filter((s) => s.id !== id),
    }));
  };

  const updateHighlight = (index: number, field: 'title' | 'subtitle', val: string) => {
    setDraft((prev) => ({
      ...prev,
      heroHighlights: prev.heroHighlights.map((item, idx) =>
        idx === index ? { ...item, [field]: val } : item
      ),
    }));
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            التحكم الكامل في الصفحة الرئيسية وأرقام التواصل والصفحات
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            عدّل جميع النصوص والصور في الصفحة الرئيسية، وأضف أرقام تواصل جديدة أو روابط فيسبوك
            ويوتيوب وإنستجرام وتيك توك لتظهر في أسفل الصفحة.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={() =>
              setDraft(JSON.parse(JSON.stringify(DEFAULT_SITE_SETTINGS)) as SiteSettings)
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة الافتراضي</span>
          </button>
          <button
            type="submit"
            disabled={saving || uploadingField !== null}
            className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saving ? 'جاري الحفظ...' : 'حفظ كافة التغييرات'}</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: Hero Text & Images */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          1. نصوص وصور الواجهة الرئيسية (Hero) والشعار
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                السطر التعريفي الصغير أعلى العنوان
              </label>
              <input
                type="text"
                value={draft.heroKicker}
                onChange={(e) => setDraft({ ...draft, heroKicker: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                العنوان الرئيسي الكبير للصفحة
              </label>
              <input
                type="text"
                required
                value={draft.heroTitle}
                onChange={(e) => setDraft({ ...draft, heroTitle: e.target.value })}
                className="w-full px-3 py-2 text-sm font-semibold border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                الفقرة الوصفية أسفل العنوان
              </label>
              <textarea
                rows={3}
                value={draft.heroSubtitle}
                onChange={(e) => setDraft({ ...draft, heroSubtitle: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  نص الزر الرئيسي
                </label>
                <input
                  type="text"
                  required
                  value={draft.heroPrimaryCta}
                  onChange={(e) => setDraft({ ...draft, heroPrimaryCta: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  نص الزر الثانوي
                </label>
                <input
                  type="text"
                  value={draft.heroSecondaryCta}
                  onChange={(e) => setDraft({ ...draft, heroSecondaryCta: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>
            </div>
          </div>

          {/* Images Control */}
          <div className="lg:col-span-5 space-y-4">
            {/* Hero Main Photo */}
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-800">صورة الواجهة الرئيسية</span>
                <input
                  ref={heroFileRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  onChange={(e) => handleImageUpload(e, 'hero')}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={uploadingField !== null}
                  onClick={() => heroFileRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{uploadingField === 'hero' ? 'جاري الرفع...' : 'تغيير الصورة'}</span>
                </button>
              </div>
              <div className="aspect-[16/9] rounded-lg overflow-hidden border border-slate-200 bg-white">
                <ResilientImage
                  src={draft.heroImageUrl}
                  alt="معاينة صورة الواجهة"
                  className="w-full h-full object-cover"
                />
              </div>
              <select
                aria-label="اختيار صورة جاهزة للواجهة"
                value={
                  OFFER_IMAGE_PRESETS.some((p) => p.url === draft.heroImageUrl)
                    ? draft.heroImageUrl
                    : ''
                }
                onChange={(e) => {
                  if (e.target.value) setDraft({ ...draft, heroImageUrl: e.target.value });
                }}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
              >
                <option value="">أو اختر صورة من الأستوديو...</option>
                {OFFER_IMAGE_PRESETS.map((preset) => (
                  <option key={preset.label} value={preset.url}>
                    {preset.label}
                  </option>
                ))}
              </select>
              <input
                type="text"
                dir="ltr"
                value={draft.heroImageUrl}
                onChange={(e) => setDraft({ ...draft, heroImageUrl: e.target.value })}
                placeholder="رابط الصورة المباشر..."
                className="w-full text-start px-2.5 py-1.5 text-xs font-mono-nums bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
              />
            </div>

            {/* Logo Photo */}
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-800">صورة شعار المكان (Logo)</span>
                <input
                  ref={logoFileRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  onChange={(e) => handleImageUpload(e, 'logo')}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={uploadingField !== null}
                  onClick={() => logoFileRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{uploadingField === 'logo' ? 'جاري الرفع...' : 'رفع شعار جديد'}</span>
                </button>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-12 px-3 rounded-lg border border-slate-200 bg-white flex items-center justify-center shrink-0">
                  <ResilientImage
                    src={draft.logoUrl}
                    alt="شعار المكان"
                    className="h-9 w-auto object-contain"
                  />
                </div>
                <input
                  type="text"
                  dir="ltr"
                  value={draft.logoUrl}
                  onChange={(e) => setDraft({ ...draft, logoUrl: e.target.value })}
                  className="flex-1 text-start px-2.5 py-1.5 text-xs font-mono-nums bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 4 Highlight Cards */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          <h4 className="text-xs font-bold text-slate-800">
            شريط المميزات الأربعة أسفل الواجهة الرئيسية
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {draft.heroHighlights.map((item, idx) => (
              <div key={idx} className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                <input
                  type="text"
                  value={item.title}
                  onChange={(e) => updateHighlight(idx, 'title', e.target.value)}
                  placeholder={`عنوان الميزة ${idx + 1}`}
                  className="w-full px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                />
                <input
                  type="text"
                  value={item.subtitle}
                  onChange={(e) => updateHighlight(idx, 'subtitle', e.target.value)}
                  placeholder={`وصف الميزة ${idx + 1}`}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 2: Services, Booking & Footer Texts */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <h3 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
          2. نصوص قسم الخدمات ونموذج الحجز والفوتر
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              عنوان قسم خدمات الصيانة
            </label>
            <input
              type="text"
              value={draft.servicesTitle}
              onChange={(e) => setDraft({ ...draft, servicesTitle: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              الوصف التعريفي لقسم الخدمات
            </label>
            <input
              type="text"
              value={draft.servicesSubtitle}
              onChange={(e) => setDraft({ ...draft, servicesSubtitle: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              الوسم أعلى نموذج الحجز
            </label>
            <input
              type="text"
              value={draft.bookingKicker}
              onChange={(e) => setDraft({ ...draft, bookingKicker: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              عنوان نموذج حجز الزيارة
            </label>
            <input
              type="text"
              value={draft.bookingTitle}
              onChange={(e) => setDraft({ ...draft, bookingTitle: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              الفقرة التعريفية داخل بطاقة حجز الزيارة
            </label>
            <textarea
              rows={2}
              value={draft.bookingSubtitle}
              onChange={(e) => setDraft({ ...draft, bookingSubtitle: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              ميزة الحجز 1 (العنوان)
            </label>
            <input
              type="text"
              value={draft.bookingFeature1Title}
              onChange={(e) => setDraft({ ...draft, bookingFeature1Title: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              ميزة الحجز 1 (الوصف)
            </label>
            <input
              type="text"
              value={draft.bookingFeature1Desc}
              onChange={(e) => setDraft({ ...draft, bookingFeature1Desc: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              ميزة الحجز 2 (العنوان)
            </label>
            <input
              type="text"
              value={draft.bookingFeature2Title}
              onChange={(e) => setDraft({ ...draft, bookingFeature2Title: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              ميزة الحجز 2 (الوصف)
            </label>
            <input
              type="text"
              value={draft.bookingFeature2Desc}
              onChange={(e) => setDraft({ ...draft, bookingFeature2Desc: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              عنوان قسم أرقام التواصل في نموذج الحجز
            </label>
            <input
              type="text"
              value={draft.bookingDirectPhoneTitle}
              onChange={(e) => setDraft({ ...draft, bookingDirectPhoneTitle: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              الوصف أسفل الشعار في الفوتر
            </label>
            <input
              type="text"
              value={draft.footerDescription}
              onChange={(e) => setDraft({ ...draft, footerDescription: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
            />
          </div>
        </div>
      </section>

      {/* SECTION 3: Dynamic Contact Phone Numbers */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-blue-700" />
            <h3 className="font-display text-base font-bold text-slate-900">
              3. أرقام التواصل والهاتف ({draft.contactPhones.length})
            </h3>
          </div>
          <button
            type="button"
            onClick={addPhone}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>إضافة رقم هاتف جديد</span>
          </button>
        </div>

        <div className="space-y-2.5">
          {draft.contactPhones.length === 0 ? (
            <p className="text-xs text-slate-500">
              لا توجد أرقام مضافة حالياً. اضغط على &quot;إضافة رقم هاتف جديد&quot;.
            </p>
          ) : (
            draft.contactPhones.map((phoneItem, idx) => (
              <div
                key={phoneItem.id}
                className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center p-3 rounded-lg bg-slate-50 border border-slate-200"
              >
                <div className="sm:col-span-5">
                  <input
                    type="text"
                    value={phoneItem.label}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contactPhones: prev.contactPhones.map((p, i) =>
                          i === idx ? { ...p, label: e.target.value } : p
                        ),
                      }))
                    }
                    placeholder="التسمية (مثال: خدمة العملاء، مبيعات الشركات)"
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div className="sm:col-span-6">
                  <input
                    type="tel"
                    dir="ltr"
                    required
                    value={phoneItem.number}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        contactPhones: prev.contactPhones.map((p, i) =>
                          i === idx ? { ...p, number: e.target.value } : p
                        ),
                      }))
                    }
                    placeholder="01009116199"
                    className="w-full text-end px-3 py-2 text-xs font-mono-nums bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div className="sm:col-span-1 flex justify-end">
                  <button
                    type="button"
                    onClick={() => removePhone(phoneItem.id)}
                    aria-label="حذف رقم الهاتف"
                    className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-md cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* SECTION 4: Social Media Pages (Facebook, YouTube, Instagram, TikTok, ...) */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-700" />
              <h3 className="font-display text-base font-bold text-slate-900">
                4. صفحات ومنصات التواصل الاجتماعي أسفل الصفحة ({draft.socialLinks.length})
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              أضف صفحاتك على فيسبوك، يوتيوب، إنستجرام، وتيك توك لتظهر بشعاراتها الرسمية في ذيل الموقع.
            </p>
          </div>
          <button
            type="button"
            onClick={() => addSocialLink('facebook')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors self-start sm:self-auto cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>إضافة صفحة تواصل</span>
          </button>
        </div>

        {/* Quick add buttons for popular platforms */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-500">إضافة سريعة:</span>
          {(['facebook', 'youtube', 'instagram', 'tiktok', 'whatsapp'] as SocialPlatform[]).map(
            (plat) => {
              const info = SOCIAL_PLATFORM_OPTIONS.find((o) => o.value === plat);
              return (
                <button
                  key={plat}
                  type="button"
                  onClick={() => addSocialLink(plat)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
                >
                  <SocialBrandIcon platform={plat} className="w-3.5 h-3.5 text-slate-800" />
                  <span>+ {info ? info.label.split(' ')[0] : plat}</span>
                </button>
              );
            }
          )}
        </div>

        <div className="space-y-2.5">
          {draft.socialLinks.length === 0 ? (
            <div className="p-6 rounded-lg bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
              لم تتم إضافة روابط صفحات تواصل اجتماعي بعد. استخدم الأزرار أعلاه لإضافة فيسبوك أو يوتيوب أو إنستجرام أو تيك توك.
            </div>
          ) : (
            draft.socialLinks.map((soc, idx) => {
              const opt = SOCIAL_PLATFORM_OPTIONS.find((o) => o.value === soc.platform);
              return (
                <div
                  key={soc.id}
                  className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center p-3 rounded-lg bg-slate-50 border border-slate-200"
                >
                  <div className="sm:col-span-3 flex items-center gap-2">
                    <span className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0">
                      <SocialBrandIcon platform={soc.platform} className="w-4 h-4" />
                    </span>
                    <select
                      aria-label="المنصة"
                      value={soc.platform}
                      onChange={(e) => {
                        const nextPlat = e.target.value as SocialPlatform;
                        const nextInfo = SOCIAL_PLATFORM_OPTIONS.find(
                          (o) => o.value === nextPlat
                        );
                        setDraft((prev) => ({
                          ...prev,
                          socialLinks: prev.socialLinks.map((s, i) =>
                            i === idx
                              ? {
                                  ...s,
                                  platform: nextPlat,
                                  label: nextInfo ? nextInfo.label.split(' ')[0] : nextPlat,
                                }
                              : s
                          ),
                        }));
                      }}
                      className="flex-1 px-2.5 py-2 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                    >
                      {SOCIAL_PLATFORM_OPTIONS.map((o) => (
                        <option key={o.value} value={o.value}>
                          {o.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-3">
                    <input
                      type="text"
                      value={soc.label}
                      onChange={(e) =>
                        setDraft((prev) => ({
                          ...prev,
                          socialLinks: prev.socialLinks.map((s, i) =>
                            i === idx ? { ...s, label: e.target.value } : s
                          ),
                        }))
                      }
                      placeholder="اسم الصفحة الظاهر"
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div className="sm:col-span-5">
                    <input
                      type="url"
                      dir="ltr"
                      required
                      value={soc.url}
                      onChange={(e) =>
                        setDraft((prev) => ({
                          ...prev,
                          socialLinks: prev.socialLinks.map((s, i) =>
                            i === idx ? { ...s, url: e.target.value } : s
                          ),
                        }))
                      }
                      placeholder={opt?.placeholder || 'https://...'}
                      className="w-full text-start px-3 py-2 text-xs font-mono-nums bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div className="sm:col-span-1 flex justify-end">
                    <button
                      type="button"
                      onClick={() => removeSocialLink(soc.id)}
                      aria-label="حذف الصفحة"
                      className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-md cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </section>

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={saving || uploadingField !== null}
          className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'جاري الحفظ...' : 'حفظ كافة التعديلات على الموقع'}</span>
        </button>
      </div>
    </form>
  );
}
