import { ChangeEvent, FormEvent, useRef, useState } from 'react';
import { Edit3, Laptop, Plus, Trash2, Upload, X } from 'lucide-react';
import type {
  ComputerDevice,
  DeviceCategory,
  DeviceCondition,
  DeviceSpecs,
} from '../types';
import { DEVICE_IMAGE_PRESETS, formatEGP } from '../utils/format';
import { ResilientImage } from './ResilientImage';

interface DevicesManagerTabProps {
  authToken: string;
  devices: ComputerDevice[];
  onDevicesChange: (devices: ComputerDevice[]) => void;
  onAuthError: () => void;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

const DEVICE_CATEGORIES: DeviceCategory[] = ['لاب توب', 'كمبيوتر PC', 'شاشات كمبيوتر'];
const DEVICE_CONDITIONS: DeviceCondition[] = ['جديد', 'استيراد بحالة الزيرو', 'كسر زيرو'];

function defaultImageForCategory(cat: DeviceCategory): string {
  if (cat === 'كمبيوتر PC') return '/src/assets/images/device_desktop_pc_1794871560266.jpg';
  if (cat === 'شاشات كمبيوتر') return '/src/assets/images/device_pc_monitor_1794871559355.jpg';
  return '/src/assets/images/device_laptop_pro_1794871559585.jpg';
}

function emptySpecs(): DeviceSpecs {
  return {
    processor: '',
    ram: '',
    storage: '',
    gpu: '',
    display: '',
    batteryOrPower: '',
    ports: '',
    warranty: 'ضمان 6 أشهر شامل الفحص',
  };
}

export function DevicesManagerTab({
  authToken,
  devices,
  onDevicesChange,
  onAuthError,
  onSuccess,
  onError,
}: DevicesManagerTabProps) {
  const [filterCategory, setFilterCategory] = useState<'الكل' | DeviceCategory>('الكل');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingDevice, setEditingDevice] = useState<ComputerDevice | null>(null);

  const [name, setName] = useState('');
  const [brand, setBrand] = useState('Dell');
  const [category, setCategory] = useState<DeviceCategory>('لاب توب');
  const [condition, setCondition] = useState<DeviceCondition>('استيراد بحالة الزيرو');
  const [price, setPrice] = useState('18500');
  const [stock, setStock] = useState('3');
  const [imageUrl, setImageUrl] = useState(DEVICE_IMAGE_PRESETS[0].url);
  const [description, setDescription] = useState('');
  const [specs, setSpecs] = useState<DeviceSpecs>(emptySpecs());

  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const authHeaders = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${authToken}`,
  };

  const filteredDevices =
    filterCategory === 'الكل'
      ? devices
      : devices.filter((d) => d.category === filterCategory);

  const openCreate = (presetCategory: DeviceCategory = 'لاب توب') => {
    setEditingDevice(null);
    setName('');
    setBrand(presetCategory === 'كمبيوتر PC' ? 'ASh Custom' : 'Dell');
    setCategory(presetCategory);
    setCondition(presetCategory === 'كمبيوتر PC' ? 'جديد' : 'استيراد بحالة الزيرو');
    setPrice(presetCategory === 'شاشات كمبيوتر' ? '12000' : '22000');
    setStock('3');
    setImageUrl(defaultImageForCategory(presetCategory));
    setDescription('');
    setSpecs(emptySpecs());
    setUploadError('');
    setModalOpen(true);
  };

  const openEdit = (dev: ComputerDevice) => {
    setEditingDevice(dev);
    setName(dev.name);
    setBrand(dev.brand);
    setCategory(dev.category);
    setCondition(dev.condition);
    setPrice(String(dev.price));
    setStock(String(dev.stock));
    setImageUrl(dev.imageUrl);
    setDescription(dev.description);
    setSpecs({ ...dev.specs });
    setUploadError('');
    setModalOpen(true);
  };

  const handleCategoryChange = (nextCategory: DeviceCategory) => {
    const prevDefault = defaultImageForCategory(category);
    setCategory(nextCategory);
    if (!editingDevice && (imageUrl === prevDefault || !imageUrl)) {
      setImageUrl(defaultImageForCategory(nextCategory));
    }
  };

  const handleImageFileSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError('');

    if (!file.type.startsWith('image/')) {
      setUploadError('يرجى اختيار ملف صورة صالح (JPG, PNG, WEBP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('الحد الأقصى لحجم الصورة هو 5 ميجابايت.');
      return;
    }

    setUploading(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('read_error'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ dataUrl, filename: file.name }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        setUploadError(data.error || 'تعذر رفع الصورة.');
        return;
      }
      setImageUrl(data.url as string);
    } catch {
      setUploadError('حدث خطأ أثناء رفع الصورة.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    onError('');
    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        brand: brand.trim() || 'Dell',
        category,
        condition,
        price: Number(price),
        stock: Number(stock),
        imageUrl: imageUrl.trim() || defaultImageForCategory(category),
        description: description.trim(),
        specs: {
          processor: specs.processor.trim(),
          ram: specs.ram.trim(),
          storage: specs.storage.trim(),
          gpu: specs.gpu.trim(),
          display: specs.display.trim(),
          batteryOrPower: specs.batteryOrPower.trim(),
          ports: specs.ports.trim(),
          warranty: specs.warranty.trim(),
        },
      };

      const url = editingDevice ? `/api/devices/${editingDevice.id}` : '/api/devices';
      const method = editingDevice ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: authHeaders,
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError(data.error || 'تعذر حفظ بيانات الجهاز.');
        return;
      }
      const saved = data as ComputerDevice;
      if (editingDevice) {
        onDevicesChange(devices.map((d) => (d.id === saved.id ? saved : d)));
        onSuccess(`تم تحديث مواصفات وسعر "${saved.name}" بنجاح.`);
      } else {
        onDevicesChange([saved, ...devices]);
        onSuccess(`تمت إضافة "${saved.name}" إلى متجر الأجهزة بنجاح.`);
      }
      setModalOpen(false);
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (dev: ComputerDevice) => {
    onError('');
    try {
      const res = await fetch(`/api/devices/${dev.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError('تعذر حذف الجهاز.');
        return;
      }
      onDevicesChange(devices.filter((d) => d.id !== dev.id));
      onSuccess(`تم حذف "${dev.name}" من متجر الأجهزة.`);
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    }
  };

  const isMonitor = category === 'شاشات كمبيوتر';

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            إدارة متجر اللاب توب والكمبيوتر (PC) والشاشات
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            أضف أو عدّل الأجهزة المعروضة للبيع مع تحديد كافة المواصفات الفنية والحالة والسعر.
          </p>
        </div>

        <button
          type="button"
          onClick={() => openCreate(filterCategory === 'الكل' ? 'لاب توب' : filterCategory)}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors self-start sm:self-auto cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة جهاز / شاشة جديدة</span>
        </button>
      </div>

      {/* Category Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 self-start w-fit">
        {(['الكل', ...DEVICE_CATEGORIES] as const).map((cat) => {
          const count =
            cat === 'الكل'
              ? devices.length
              : devices.filter((d) => d.category === cat).length;
          return (
            <button
              key={cat}
              type="button"
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                filterCategory === cat
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat} ({count})
            </button>
          );
        })}
      </div>

      {filteredDevices.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-3">
          <Laptop className="w-8 h-8 text-slate-400 mx-auto" />
          <p className="text-sm text-slate-600">لا توجد أجهزة مضافة في هذا التصنيف حالياً.</p>
          <button
            type="button"
            onClick={() => openCreate(filterCategory === 'الكل' ? 'لاب توب' : filterCategory)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة جهاز الآن</span>
          </button>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4 text-start">الجهاز والمواصفات</th>
                  <th className="py-3 px-4 text-start">الفئة والحالة</th>
                  <th className="py-3 px-4 text-start">السعر</th>
                  <th className="py-3 px-4 text-start">المخزون</th>
                  <th className="py-3 px-4 text-end">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredDevices.map((dev) => (
                  <tr key={dev.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-14 h-10 rounded-md overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                          <ResilientImage
                            src={dev.imageUrl}
                            alt={dev.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900">
                            {dev.name}{' '}
                            <span className="text-xs font-normal text-slate-500">
                              ({dev.brand})
                            </span>
                          </div>
                          <div className="text-xs text-slate-500 line-clamp-1 max-w-md mt-0.5">
                            {[dev.specs.processor, dev.specs.ram, dev.specs.storage, dev.specs.gpu]
                              .filter(Boolean)
                              .join(' · ')}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{dev.category}</div>
                      <div className="text-slate-500 mt-0.5">{dev.condition}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900 whitespace-nowrap tabular-nums">
                      {formatEGP(dev.price)}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap tabular-nums text-xs">
                      <span
                        className={
                          dev.stock > 0 ? 'text-emerald-700 font-medium' : 'text-red-700 font-semibold'
                        }
                      >
                        {dev.stock} قطعة
                      </span>
                    </td>
                    <td className="py-3 px-4 text-end whitespace-nowrap">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openEdit(dev)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-blue-700 bg-slate-100 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>تعديل</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(dev)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 bg-red-50/40 rounded-md transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>حذف</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Device Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl border border-slate-200 w-full max-w-2xl p-6 space-y-5 shadow-xl my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingDevice ? 'تعديل بيانات ومواصفات الجهاز' : 'إضافة جهاز جديد للمتجر'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-5">
              {/* Basic Info */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    قسم الجهاز
                  </label>
                  <select
                    value={category}
                    onChange={(e) => handleCategoryChange(e.target.value as DeviceCategory)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  >
                    {DEVICE_CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الماركة (Brand)
                  </label>
                  <input
                    type="text"
                    required
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    placeholder="Dell, HP, Lenovo, Asus..."
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    حالة الجهاز
                  </label>
                  <select
                    value={condition}
                    onChange={(e) => setCondition(e.target.value as DeviceCondition)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  >
                    {DEVICE_CONDITIONS.map((cond) => (
                      <option key={cond} value={cond}>
                        {cond}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-6">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    اسم وموديل الجهاز
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={
                      isMonitor
                        ? 'مثال: شاشة Dell UltraSharp U2722D 27 بوصة'
                        : 'مثال: Dell Precision 5560 Core i7'
                    }
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    السعر (ج.م)
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono-nums border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الكمية بالمخزون
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono-nums border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
              </div>

              {/* Image Upload + Preset Picker */}
              <div className="space-y-2.5 p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold text-slate-700">صورة الجهاز</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    onChange={handleImageFileSelect}
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={uploading}
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploading ? 'جاري رفع الصورة...' : 'رفع صورة الجهاز'}</span>
                  </button>
                </div>

                {uploadError && <p className="text-xs text-red-700">{uploadError}</p>}

                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <div className="w-32 h-24 rounded-lg overflow-hidden border border-slate-200 bg-white shrink-0">
                    <ResilientImage
                      src={imageUrl}
                      alt={name || 'معاينة صورة الجهاز'}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 w-full space-y-2">
                    <select
                      aria-label="اختيار صورة جاهزة"
                      value={
                        DEVICE_IMAGE_PRESETS.some((p) => p.url === imageUrl) ? imageUrl : ''
                      }
                      onChange={(e) => {
                        if (e.target.value) setImageUrl(e.target.value);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                    >
                      <option value="">أو اختر صورة جاهزة من الأستوديو...</option>
                      {DEVICE_IMAGE_PRESETS.map((preset) => (
                        <option key={preset.label} value={preset.url}>
                          {preset.label}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      dir="ltr"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      placeholder="رابط الصورة المباشر..."
                      className="w-full text-start px-2.5 py-1.5 text-xs font-mono-nums bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                    />
                  </div>
                </div>
              </div>

              {/* Detailed Hardware Specifications */}
              <div className="space-y-3 border-t border-slate-200 pt-4">
                <h4 className="font-display text-sm font-bold text-slate-900">
                  المواصفات التفصيلية للجهاز
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isMonitor ? 'نوع البانل وتدرج الألوان' : 'المعالج (Processor)'}
                    </label>
                    <input
                      type="text"
                      value={specs.processor}
                      onChange={(e) => setSpecs({ ...specs, processor: e.target.value })}
                      placeholder={
                        isMonitor
                          ? 'مثال: IPS · 100% sRGB'
                          : 'مثال: Intel Core i7-12700H 14-Core'
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isMonitor ? 'معدل التحديث وزمن الاستجابة' : 'الذاكرة العشوائية (RAM)'}
                    </label>
                    <input
                      type="text"
                      value={specs.ram}
                      onChange={(e) => setSpecs({ ...specs, ram: e.target.value })}
                      placeholder={
                        isMonitor ? 'مثال: 144Hz · 1ms' : 'مثال: 16GB DDR4 3200MHz'
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isMonitor ? 'دقة العرض (Resolution)' : 'التخزين (SSD / HDD)'}
                    </label>
                    <input
                      type="text"
                      value={specs.storage}
                      onChange={(e) => setSpecs({ ...specs, storage: e.target.value })}
                      placeholder={
                        isMonitor
                          ? 'مثال: QHD 2560 × 1440'
                          : 'مثال: 512GB NVMe M.2 SSD'
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isMonitor ? 'السطوع والتباين' : 'كارت الشاشة (GPU)'}
                    </label>
                    <input
                      type="text"
                      value={specs.gpu}
                      onChange={(e) => setSpecs({ ...specs, gpu: e.target.value })}
                      placeholder={
                        isMonitor
                          ? 'مثال: 400 nits · HDR400'
                          : 'مثال: NVIDIA RTX 3060 6GB'
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isMonitor ? 'المقاس والحامل' : 'مواصفات الشاشة (Display)'}
                    </label>
                    <input
                      type="text"
                      value={specs.display}
                      onChange={(e) => setSpecs({ ...specs, display: e.target.value })}
                      placeholder={
                        isMonitor
                          ? 'مثال: 27 بوصة بدون حواف + حامل متحرك'
                          : 'مثال: 15.6" FHD IPS 144Hz'
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {category === 'لاب توب'
                        ? 'البطارية والشاحن'
                        : isMonitor
                          ? 'استهلاك الطاقة والكابلات'
                          : 'الباور سبلاي والتبريد'}
                    </label>
                    <input
                      type="text"
                      value={specs.batteryOrPower}
                      onChange={(e) => setSpecs({ ...specs, batteryOrPower: e.target.value })}
                      placeholder={
                        category === 'لاب توب'
                          ? 'مثال: بطارية ممتازة + شاحن أصلي 130W'
                          : isMonitor
                            ? 'مثال: 30W + كابل DisplayPort والباور'
                            : 'مثال: باور 750W 80+ Bronze + تبريد مائي'
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      المنافذ والاتصال (Ports)
                    </label>
                    <input
                      type="text"
                      value={specs.ports}
                      onChange={(e) => setSpecs({ ...specs, ports: e.target.value })}
                      placeholder="مثال: Thunderbolt 4 · HDMI · USB 3.2 · LAN"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      الضمان
                    </label>
                    <input
                      type="text"
                      value={specs.warranty}
                      onChange={(e) => setSpecs({ ...specs, warranty: e.target.value })}
                      placeholder="مثال: ضمان 6 أشهر"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  وصف ومميزات الجهاز
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="اكتب نبذة عن حالة الجهاز واستخداماته المناسبة..."
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving || uploading}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {saving ? 'جاري الحفظ...' : editingDevice ? 'حفظ التعديلات' : 'إضافة الجهاز'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
