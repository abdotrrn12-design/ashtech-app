import { ChangeEvent, FormEvent, useRef, useState } from 'react';
import {
  Edit3,
  Eye,
  EyeOff,
  ImagePlus,
  Plus,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import type { OfferLinkTarget, PromotionalOffer } from '../types';
import { formatArabicDate, OFFER_IMAGE_PRESETS } from '../utils/format';
import { ResilientImage } from './ResilientImage';

interface OffersManagerTabProps {
  authToken: string;
  offers: PromotionalOffer[];
  onOffersChange: (offers: PromotionalOffer[]) => void;
  onAuthError: () => void;
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

function linkTargetLabel(target: OfferLinkTarget): string {
  switch (target) {
    case 'booking':
      return 'توجيه لنموذج حجز الصيانة';
    case 'store':
      return 'توجيه لمتجر الإكسسوارات';
    case 'none':
      return 'صورة عرض فقط';
  }
}

export function OffersManagerTab({
  authToken,
  offers,
  onOffersChange,
  onAuthError,
  onSuccess,
  onError,
}: OffersManagerTabProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingOffer, setEditingOffer] = useState<PromotionalOffer | null>(null);
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [imageUrl, setImageUrl] = useState(OFFER_IMAGE_PRESETS[0].url);
  const [linkTarget, setLinkTarget] = useState<OfferLinkTarget>('booking');
  const [active, setActive] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const authHeaders = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${authToken}`,
  };

  const openCreate = () => {
    setEditingOffer(null);
    setTitle('');
    setSubtitle('');
    setImageUrl(OFFER_IMAGE_PRESETS[0].url);
    setLinkTarget('booking');
    setActive(true);
    setUploadError('');
    setModalOpen(true);
  };

  const openEdit = (offer: PromotionalOffer) => {
    setEditingOffer(offer);
    setTitle(offer.title);
    setSubtitle(offer.subtitle || '');
    setImageUrl(offer.imageUrl);
    setLinkTarget(offer.linkTarget);
    setActive(offer.active);
    setUploadError('');
    setModalOpen(true);
  };

  const handleImageFileSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError('');

    if (!file.type.startsWith('image/')) {
      setUploadError('يرجى اختيار ملف صورة صالح (JPG, PNG, WEBP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('الحد الأقصى لحجم الصورة هو 5 ميجابايت.');
      return;
    }

    setUploading(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('read_error'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ dataUrl, filename: file.name }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        setUploadError(data.error || 'تعذر رفع صورة العرض.');
        return;
      }
      setImageUrl(data.url as string);
    } catch {
      setUploadError('حدث خطأ أثناء رفع الصورة.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    onError('');
    if (!imageUrl.trim()) {
      onError('يرجى رفع أو تحديد صورة للعرض.');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: title.trim() || 'عرض خاص من ASh tech',
        subtitle: subtitle.trim(),
        imageUrl: imageUrl.trim(),
        linkTarget,
        active,
      };
      const url = editingOffer ? `/api/offers/${editingOffer.id}` : '/api/offers';
      const method = editingOffer ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: authHeaders,
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError(data.error || 'تعذر حفظ العرض.');
        return;
      }
      const saved = data as PromotionalOffer;
      if (editingOffer) {
        onOffersChange(offers.map((o) => (o.id === saved.id ? saved : o)));
        onSuccess('تم تحديث صورة وتفاصيل العرض المتحرك بنجاح.');
      } else {
        onOffersChange([saved, ...offers]);
        onSuccess('تمت إضافة العرض الجديد إلى شريط الإعلانات بالصفحة الرئيسية.');
      }
      setModalOpen(false);
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (offer: PromotionalOffer) => {
    onError('');
    try {
      const res = await fetch(`/api/offers/${offer.id}`, {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify({ active: !offer.active }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError(data.error || 'تعذر تحديث حالة العرض.');
        return;
      }
      const updated = data as PromotionalOffer;
      onOffersChange(offers.map((o) => (o.id === updated.id ? updated : o)));
      onSuccess(updated.active ? 'تم تفعيل العرض في الصفحة الرئيسية.' : 'تم إخفاء العرض مؤقتاً.');
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    }
  };

  const handleDelete = async (id: string) => {
    onError('');
    try {
      const res = await fetch(`/api/offers/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (!res.ok) {
        if (res.status === 401) onAuthError();
        onError('تعذر حذف العرض.');
        return;
      }
      onOffersChange(offers.filter((o) => o.id !== id));
      onSuccess('تم حذف العرض بنجاح.');
    } catch {
      onError('خطأ في الاتصال بالخادم.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            إعلانات وعروض الصفحة الرئيسية المتحركة
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            ارفع صور العروض الجديدة أو عدل الإعلانات الحالية لتظهر تلقائياً في الشريط المتحرك بالصفحة الرئيسية.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة صورة عرض جديد</span>
        </button>
      </div>

      {offers.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-3">
          <ImagePlus className="w-8 h-8 text-slate-400 mx-auto" />
          <p className="text-sm text-slate-600">لا توجد صور عروض مضافة حالياً.</p>
          <button
            type="button"
            onClick={openCreate}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة أول عرض</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {offers.map((offer) => (
            <div
              key={offer.id}
              className={`bg-white border rounded-xl overflow-hidden flex flex-col ${
                offer.active ? 'border-slate-200' : 'border-slate-200 opacity-75'
              }`}
            >
              <div className="aspect-[16/7] bg-slate-100 relative overflow-hidden">
                <ResilientImage
                  src={offer.imageUrl}
                  alt={offer.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/80 via-slate-950/35 to-transparent p-4 text-white">
                  <div className="font-display text-sm font-bold line-clamp-1">{offer.title}</div>
                  {offer.subtitle && (
                    <div className="text-xs text-slate-200 line-clamp-1 mt-0.5">
                      {offer.subtitle}
                    </div>
                  )}
                </div>
              </div>

              <div className="p-4 flex items-center justify-between gap-3 bg-white">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span
                      className={`font-semibold ${
                        offer.active ? 'text-emerald-700' : 'text-slate-500'
                      }`}
                    >
                      {offer.active ? 'مفعل في الرئيسية' : 'مخفي مؤقتاً'}
                    </span>
                    <span aria-hidden="true" className="text-slate-300">
                      ·
                    </span>
                    <span className="text-slate-600">{linkTargetLabel(offer.linkTarget)}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 tabular-nums">
                    أُضيف في: {formatArabicDate(offer.createdAt)}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleToggleActive(offer)}
                    aria-label={offer.active ? 'إخفاء العرض' : 'تفعيل العرض'}
                    title={offer.active ? 'إخفاء العرض' : 'تفعيل العرض'}
                    className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer"
                  >
                    {offer.active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => openEdit(offer)}
                    aria-label={`تعديل ${offer.title}`}
                    className="p-2 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(offer.id)}
                    aria-label={`حذف ${offer.title}`}
                    className="p-2 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Offer Add/Edit Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 shadow-xl my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingOffer ? 'تعديل صورة وتفاصيل العرض' : 'إضافة عرض جديد للصفحة الرئيسية'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              {/* Offer Image Upload + Preview */}
              <div className="space-y-2.5 p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold text-slate-700">
                    صورة العرض الإعلاني
                  </span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    onChange={handleImageFileSelect}
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={uploading}
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploading ? 'جاري رفع الصورة...' : 'رفع صورة من جهازك'}</span>
                  </button>
                </div>

                {uploadError && <p className="text-xs text-red-700">{uploadError}</p>}

                <div className="aspect-[16/7] w-full rounded-lg overflow-hidden border border-slate-200 bg-white">
                  <ResilientImage
                    src={imageUrl}
                    alt={title || 'معاينة صورة العرض'}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select
                    aria-label="اختيار صورة جاهزة للعرض"
                    value={
                      OFFER_IMAGE_PRESETS.some((p) => p.url === imageUrl) ? imageUrl : ''
                    }
                    onChange={(e) => {
                      if (e.target.value) setImageUrl(e.target.value);
                    }}
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                  >
                    <option value="">أو اختر صورة جاهزة...</option>
                    {OFFER_IMAGE_PRESETS.map((preset) => (
                      <option key={preset.label} value={preset.url}>
                        {preset.label}
                      </option>
                    ))}
                  </select>

                  <input
                    type="text"
                    dir="ltr"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="أو الصق رابط الصورة مباشرة..."
                    className="w-full text-start px-2.5 py-1.5 text-xs font-mono-nums bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  عنوان العرض (يظهر فوق الصورة)
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: خصم 20% على تنظيف اللاب توب وتغيير المعجون الحراري"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  تفاصيل العرض (اختياري)
                </label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="مثال: ساري حتى نهاية الشهر لجميع الأجهزة والشركات"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    إجراء عند النقر على العرض
                  </label>
                  <select
                    value={linkTarget}
                    onChange={(e) => setLinkTarget(e.target.value as OfferLinkTarget)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  >
                    <option value="booking">الانتقال لحجز الصيانة</option>
                    <option value="store">الانتقال لمتجر الإكسسوارات</option>
                    <option value="none">عرض بدون زر انتقال</option>
                  </select>
                </div>

                <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={active}
                    onChange={(e) => setActive(e.target.checked)}
                    className="w-4 h-4 accent-blue-700"
                  />
                  <span className="text-xs font-semibold text-slate-800">
                    إظهار العرض في الرئيسية الآن
                  </span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving || uploading}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {saving ? 'جاري الحفظ...' : 'حفظ العرض'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
