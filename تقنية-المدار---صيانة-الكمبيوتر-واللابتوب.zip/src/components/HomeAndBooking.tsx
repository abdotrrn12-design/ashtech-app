import { useState, useEffect, FormEvent } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  PackageCheck,
  Phone,
  Plus,
  ShieldCheck,
  Wrench,
  X,
} from 'lucide-react';
import type {
  CartItem,
  ClientSegment,
  CustomerOrder,
  MaintenanceService,
  PromotionalOffer,
  ServiceCategory,
  SiteSettings,
} from '../types';
import { formatEGP } from '../utils/format';
import { ResilientImage } from './ResilientImage';

interface HomeAndBookingProps {
  siteSettings: SiteSettings;
  offers: PromotionalOffer[];
  services: MaintenanceService[];
  loadingServices: boolean;
  cart: CartItem[];
  attachCartToBooking: boolean;
  onToggleAttachCart: (attach: boolean) => void;
  onOrderCreated: (order: CustomerOrder, clearedCart: boolean) => void;
  onGoToStore: () => void;
  onTrackOrder: (orderNumber: string) => void;
}

const SERVICE_CATEGORIES: Array<'الكل' | ServiceCategory> = [
  'الكل',
  'تبريد وتنظيف',
  'هاردوير',
  'سوفت وير',
  'شركات',
];

const TIME_SLOTS = [
  'صباحاً (10:00 ص - 2:00 م)',
  'عصراً (2:00 م - 6:00 م)',
  'مساءً (6:00 م - 10:00 م)',
];

const DEVICE_TYPES = [
  'لاب توب (Laptop)',
  'كمبيوتر مكتبي (Desktop PC)',
  'محطة عمل هندسية (Workstation)',
  'أجهزة وشبكة شركة (متعدد)',
];

export function HomeAndBooking({
  siteSettings,
  offers,
  services,
  loadingServices,
  cart,
  attachCartToBooking,
  onToggleAttachCart,
  onOrderCreated,
  onGoToStore,
  onTrackOrder,
}: HomeAndBookingProps) {
  const [activeOfferIdx, setActiveOfferIdx] = useState(0);
  const [offerPaused, setOfferPaused] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<'الكل' | ServiceCategory>('الكل');
  const [clientSegment, setClientSegment] = useState<ClientSegment>('أفراد / منازل');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [deviceType, setDeviceType] = useState(DEVICE_TYPES[0]);
  const [selectedServiceIds, setSelectedServiceIds] = useState<string[]>([]);
  const [problemDescription, setProblemDescription] = useState('');
  const [preferredDate, setPreferredDate] = useState(() => {
    const tomorrow = new Date(Date.now() + 86400000);
    return tomorrow.toISOString().split('T')[0];
  });
  const [preferredTimeSlot, setPreferredTimeSlot] = useState(TIME_SLOTS[0]);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [confirmedOrder, setConfirmedOrder] = useState<CustomerOrder | null>(null);

  useEffect(() => {
    if (services.length === 0) return;
    setSelectedServiceIds((prev) => {
      const valid = prev.filter((id) => services.some((s) => s.id === id));
      if (valid.length > 0) return valid;
      return [services[0].id];
    });
  }, [services]);

  useEffect(() => {
    if (offers.length === 0) {
      setActiveOfferIdx(0);
      return;
    }
    if (activeOfferIdx >= offers.length) {
      setActiveOfferIdx(0);
    }
  }, [offers.length, activeOfferIdx]);

  useEffect(() => {
    if (offers.length <= 1 || offerPaused) return;
    const timer = window.setInterval(() => {
      setActiveOfferIdx((prev) => (prev + 1) % offers.length);
    }, 4500);
    return () => window.clearInterval(timer);
  }, [offers.length, offerPaused]);

  const filteredServices =
    selectedCategory === 'الكل'
      ? services
      : services.filter((s) => s.category === selectedCategory);

  const selectedServices = selectedServiceIds
    .map((id) => services.find((s) => s.id === id))
    .filter((s): s is MaintenanceService => Boolean(s));
  const unselectedServices = services.filter((s) => !selectedServiceIds.includes(s.id));
  const servicesStartingTotal = selectedServices.reduce((sum, s) => sum + s.startingPrice, 0);

  const cartSubtotal = cart.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const estimatedOrderTotal =
    servicesStartingTotal + (attachCartToBooking && cart.length > 0 ? cartSubtotal : 0);

  const handleSelectServiceForBooking = (serviceId: string) => {
    setSelectedServiceIds((prev) => (prev.includes(serviceId) ? prev : [...prev, serviceId]));
    setConfirmedOrder(null);
    const bookingEl = document.getElementById('booking-section');
    if (bookingEl) {
      bookingEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleSubmitBooking = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');

    const cleanPhone = phone.replace(/\s+/g, '');
    if (customerName.trim().length < 2) {
      setFormError('يرجى إدخال اسم العميل أو الشركة بشكل صحيح.');
      return;
    }
    if (!/^01[0125][0-9]{8}$/.test(cleanPhone) && cleanPhone.length < 8) {
      setFormError('يرجى إدخال رقم هاتف مصري صحيح للتواصل.');
      return;
    }
    if (address.trim().length < 5) {
      setFormError('يرجى كتابة العنوان بالتفصيل لتحديد موعد الزيارة.');
      return;
    }
    if (selectedServiceIds.length === 0) {
      setFormError('يرجى اختيار خدمة صيانة واحدة على الأقل.');
      return;
    }
    if (!problemDescription.trim()) {
      setFormError('يرجى كتابة وصف مختصر للمشكلة أو الصيانة المطلوبة.');
      return;
    }

    const shouldAttachCart = attachCartToBooking && cart.length > 0;

    setSubmitting(true);
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientSegment,
          customerName: customerName.trim(),
          phone: cleanPhone,
          address: address.trim(),
          deviceType,
          serviceId: selectedServiceIds[0] || undefined,
          serviceIds: selectedServiceIds,
          problemDescription: problemDescription.trim(),
          preferredDate,
          preferredTimeSlot,
          items: shouldAttachCart
            ? cart.map((c) => ({ productId: c.product.id, quantity: c.quantity }))
            : [],
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        setFormError(data.error || 'تعذر إرسال الطلب، يرجى المحاولة مرة أخرى.');
        return;
      }

      setConfirmedOrder(data as CustomerOrder);
      onOrderCreated(data as CustomerOrder, shouldAttachCart);
      setCustomerName('');
      setPhone('');
      setAddress('');
      setProblemDescription('');
    } catch {
      setFormError('حدث خطأ في الاتصال بالخادم. يرجى المحاولة مرة أخرى.');
    } finally {
      setSubmitting(false);
    }
  };

  const currentOffer = offers.length > 0 ? offers[activeOfferIdx % offers.length] : null;

  const handleOfferCta = (offer: PromotionalOffer) => {
    if (offer.linkTarget === 'store') {
      onGoToStore();
    } else if (offer.linkTarget === 'booking') {
      const bookingEl = document.getElementById('booking-section');
      if (bookingEl) {
        bookingEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  return (
    <div className="space-y-16 pb-20">
      {/* Animated Promotional Offers Carousel */}
      {currentOffer && (
        <section
          aria-label="عروض وإعلانات ASh tech"
          className="bg-slate-950 border-b border-slate-800"
          onMouseEnter={() => setOfferPaused(true)}
          onMouseLeave={() => setOfferPaused(false)}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-5">
            <div className="relative h-52 sm:h-68 lg:h-80 rounded-xl overflow-hidden border border-slate-800 bg-slate-900">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentOffer.id}
                  initial={{ opacity: 0, x: -24 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 24 }}
                  transition={{ duration: 0.45, ease: 'easeOut' }}
                  className="absolute inset-0"
                >
                  <ResilientImage
                    src={currentOffer.imageUrl}
                    alt={currentOffer.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/35 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                    <div className="max-w-2xl text-white">
                      <p className="text-[11px] font-semibold text-blue-300 mb-1">
                        عروض وخدمات ASh tech
                      </p>
                      <h2 className="font-display text-lg sm:text-2xl font-bold leading-snug">
                        {currentOffer.title}
                      </h2>
                      {currentOffer.subtitle && (
                        <p className="text-xs sm:text-sm text-slate-200 mt-1 line-clamp-2">
                          {currentOffer.subtitle}
                        </p>
                      )}
                    </div>

                    {currentOffer.linkTarget !== 'none' && (
                      <button
                        type="button"
                        onClick={() => handleOfferCta(currentOffer)}
                        className="inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap self-start sm:self-end shrink-0 cursor-pointer"
                      >
                        <span>
                          {currentOffer.linkTarget === 'store'
                            ? 'تصفح عروض المتجر'
                            : 'احجز العرض الآن'}
                        </span>
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </motion.div>
              </AnimatePresence>

              {offers.length > 1 && (
                <>
                  <button
                    type="button"
                    aria-label="العرض السابق"
                    onClick={() =>
                      setActiveOfferIdx(
                        (prev) => (prev - 1 + offers.length) % offers.length
                      )
                    }
                    className="absolute start-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-slate-950/60 hover:bg-slate-950/85 text-white border border-white/15 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                  <button
                    type="button"
                    aria-label="العرض التالي"
                    onClick={() =>
                      setActiveOfferIdx((prev) => (prev + 1) % offers.length)
                    }
                    className="absolute end-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-slate-950/60 hover:bg-slate-950/85 text-white border border-white/15 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>

                  <div className="absolute top-3.5 end-4 flex items-center gap-1.5">
                    {offers.map((o, idx) => (
                      <button
                        key={o.id}
                        type="button"
                        aria-label={`عرض ${idx + 1}: ${o.title}`}
                        onClick={() => setActiveOfferIdx(idx)}
                        className={`h-1.5 rounded-full transition-all cursor-pointer ${
                          idx === activeOfferIdx % offers.length
                            ? 'w-7 bg-white'
                            : 'w-2.5 bg-white/40 hover:bg-white/70'
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Hero Section: 2-Column Balanced Split */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-12 lg:pt-14 lg:pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center">
              {siteSettings.heroKicker && (
                <p className="text-xs font-semibold text-blue-700 mb-3">
                  {siteSettings.heroKicker}
                </p>
              )}
              <h1
                className="font-display font-extrabold text-slate-900 leading-[1.2] mb-5"
                style={{
                  fontSize: 'clamp(2rem, 3.6vw, 3.25rem)',
                  textWrap: 'balance',
                }}
              >
                {siteSettings.heroTitle}
              </h1>
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed mb-8 max-w-xl">
                {siteSettings.heroSubtitle}
              </p>

              <div className="flex flex-wrap items-center gap-4">
                <a
                  href="#booking-section"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  <span>{siteSettings.heroPrimaryCta}</span>
                  <ArrowLeft className="w-4 h-4" />
                </a>
                {siteSettings.heroSecondaryCta && (
                  <button
                    type="button"
                    onClick={onGoToStore}
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>{siteSettings.heroSecondaryCta}</span>
                  </button>
                )}
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="h-72 sm:h-96 lg:h-full min-h-[340px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                <ResilientImage
                  src={siteSettings.heroImageUrl}
                  alt={siteSettings.heroTitle}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Full-Width 4-Column Trust & SLA Strip Below Hero */}
          <div className="mt-10 pt-8 border-t border-slate-200 grid grid-cols-2 lg:grid-cols-4 gap-6">
            {siteSettings.heroHighlights.map((highlight, idx) => (
              <div key={idx}>
                <div className="font-display text-xl font-bold text-slate-900 tabular-nums">
                  {highlight.title}
                </div>
                <p className="text-sm text-slate-600 mt-1">{highlight.subtitle}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Maintenance Services Section */}
      <section
        id="services-section"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24"
      >
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">
              {siteSettings.servicesTitle}
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-2 max-w-2xl">
              {siteSettings.servicesSubtitle}
            </p>
          </div>

          {/* Interactive Filter Controls */}
          <div
            role="tablist"
            aria-label="تصنيف خدمات الصيانة"
            className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 self-start"
          >
            {SERVICE_CATEGORIES.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={selectedCategory === category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCategory === category
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {loadingServices ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="h-60 rounded-xl bg-white border border-slate-200 p-6 animate-pulse"
              />
            ))}
          </div>
        ) : filteredServices.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
            <p className="text-slate-600 text-sm">
              لا توجد خدمات متاحة ضمن هذا التصنيف حالياً.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service, idx) => {
              const numLabel = String(idx + 1).padStart(2, '0');
              const isSelected = selectedServiceIds.includes(service.id);
              return (
                <article
                  key={service.id}
                  className={`flex flex-col justify-between bg-white rounded-xl border p-6 transition-colors ${
                    isSelected
                      ? 'border-blue-700 ring-1 ring-blue-700/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-3 text-xs text-slate-500 mb-3">
                      <span className="font-mono-nums font-semibold text-blue-700">
                        {numLabel}.
                      </span>
                      <div className="flex items-center gap-2 truncate">
                        <span>{service.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{service.estimatedDuration}</span>
                      </div>
                    </div>

                    <h3 className="font-display text-lg font-bold text-slate-900 leading-snug mb-2.5">
                      {service.title}
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed mb-5">
                      {service.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-4">
                    <div>
                      <span className="block text-xs text-slate-500">يبدأ من</span>
                      <span className="font-display text-lg font-bold text-slate-900 tabular-nums">
                        {formatEGP(service.startingPrice)}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSelectServiceForBooking(service.id)}
                      className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        isSelected
                          ? 'bg-blue-700 text-white'
                          : 'bg-slate-900 text-white hover:bg-blue-700'
                      }`}
                    >
                      {isSelected ? 'مختارة للحجز' : 'حجز هذه الخدمة'}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Maintenance Visit Booking Form */}
      <section
        id="booking-section"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24"
      >
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Summary / Guidelines Column */}
            <div className="lg:col-span-4 bg-slate-900 text-white p-8 lg:p-10 flex flex-col justify-between">
              <div>
                <div className="inline-flex items-center gap-2 text-xs font-medium text-blue-300 mb-4">
                  <Wrench className="w-4 h-4" />
                  <span>{siteSettings.bookingKicker}</span>
                </div>
                <h2 className="font-display text-2xl font-bold leading-snug mb-4">
                  {siteSettings.bookingTitle}
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed mb-8">
                  {siteSettings.bookingSubtitle}
                </p>

                <div className="space-y-4 border-t border-slate-800 pt-6 text-sm">
                  <div className="flex items-start gap-3">
                    <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-white">
                        {siteSettings.bookingFeature1Title}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {siteSettings.bookingFeature1Desc}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-white">
                        {siteSettings.bookingFeature2Title}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {siteSettings.bookingFeature2Desc}
                      </p>
                    </div>
                  </div>
                  {siteSettings.contactPhones.length > 0 && (
                    <div className="flex items-start gap-3">
                      <Phone className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <div className="font-semibold text-white">
                          {siteSettings.bookingDirectPhoneTitle}
                        </div>
                        <div className="flex flex-col gap-1">
                          {siteSettings.contactPhones.map((ph) => (
                            <div key={ph.id} className="flex items-center gap-2 text-xs">
                              {ph.label && (
                                <span className="text-slate-400">{ph.label}:</span>
                              )}
                              <a
                                href={`tel:${ph.number}`}
                                dir="ltr"
                                className="font-mono-nums text-blue-300 hover:text-white transition-colors"
                              >
                                {ph.number}
                              </a>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {selectedServices.length > 0 && (
                <div className="mt-8 pt-6 border-t border-slate-800">
                  <div className="text-xs text-slate-400 mb-1">التكلفة المبدئية المقدرة</div>
                  <div className="font-display text-2xl font-bold text-white tabular-nums">
                    {formatEGP(estimatedOrderTotal)}
                  </div>
                  <ul className="text-xs text-slate-300 mt-2 space-y-1">
                    {selectedServices.map((srv) => (
                      <li key={srv.id} className="flex items-center justify-between gap-2">
                        <span>· {srv.title}</span>
                        <span className="font-mono-nums text-slate-400">
                          {formatEGP(srv.startingPrice)}
                        </span>
                      </li>
                    ))}
                    {attachCartToBooking && cart.length > 0 && (
                      <li className="text-blue-300 pt-1">
                        + {cart.length} منتج من سلة المشتريات ({formatEGP(cartSubtotal)})
                      </li>
                    )}
                  </ul>
                </div>
              )}
            </div>

            {/* Interactive Booking Form */}
            <div className="lg:col-span-8 p-6 sm:p-8 lg:p-10">
              {confirmedOrder ? (
                <div className="py-6 space-y-6">
                  <div className="flex items-start gap-4">
                    <CheckCircle2 className="w-8 h-8 text-emerald-700 shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-display text-xl font-bold text-slate-900">
                        تم استلام طلب الصيانة بنجاح
                      </h3>
                      <p className="text-sm text-slate-600 mt-1">
                        رقم الطلب:{' '}
                        <span className="font-mono-nums font-bold text-slate-900">
                          {confirmedOrder.orderNumber}
                        </span>{' '}
                        · سنتواصل معك عبر الهاتف لتأكيد الموعد.
                      </p>
                    </div>
                  </div>

                  <div className="border-t border-b border-slate-200 py-5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-500 block text-xs">العميل / الشركة</span>
                      <span className="font-semibold text-slate-900">
                        {confirmedOrder.customerName}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs">رقم الهاتف</span>
                      <span className="font-mono-nums font-semibold text-slate-900">
                        {confirmedOrder.phone}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs mb-1">
                        الخدمات المطلوبة
                      </span>
                      {confirmedOrder.serviceTitles && confirmedOrder.serviceTitles.length > 1 ? (
                        <ul className="space-y-0.5 font-semibold text-slate-900">
                          {confirmedOrder.serviceTitles.map((title, idx) => (
                            <li key={idx}>· {title}</li>
                          ))}
                        </ul>
                      ) : (
                        <span className="font-semibold text-slate-900">
                          {confirmedOrder.serviceTitle}
                        </span>
                      )}
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs">الموعد المفضل</span>
                      <span className="font-semibold text-slate-900 tabular-nums">
                        {confirmedOrder.preferredDate} · {confirmedOrder.preferredTimeSlot}
                      </span>
                    </div>
                    {confirmedOrder.items.length > 0 && (
                      <div className="sm:col-span-2">
                        <span className="text-slate-500 block text-xs mb-1">
                          الإكسسوارات المدمجة مع الزيارة
                        </span>
                        <ul className="space-y-1 text-slate-800">
                          {confirmedOrder.items.map((item) => (
                            <li key={item.productId} className="tabular-nums">
                              {item.productName} × {item.quantity} (
                              {formatEGP(item.unitPrice * item.quantity)})
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onTrackOrder(confirmedOrder.orderNumber)}
                      className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
                    >
                      متابعة حالة الطلب ({confirmedOrder.status})
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmedOrder(null)}
                      className="px-5 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      تسجيل طلب صيانة جديد
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmitBooking} className="space-y-5" noValidate>
                  {/* Client Segment Toggle */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-2">
                      نوع العميل
                    </label>
                    <div className="inline-flex p-1 bg-slate-100 rounded-lg border border-slate-200">
                      {(['أفراد / منازل', 'شركات / مؤسسات'] as ClientSegment[]).map((seg) => (
                        <button
                          key={seg}
                          type="button"
                          onClick={() => setClientSegment(seg)}
                          className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                            clientSegment === seg
                              ? 'bg-white text-slate-900 shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          {seg}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="booking-name"
                        className="block text-sm font-medium text-slate-800 mb-1.5"
                      >
                        {clientSegment === 'شركات / مؤسسات'
                          ? 'اسم الشركة والمسؤول'
                          : 'الاسم بالكامل'}
                      </label>
                      <input
                        id="booking-name"
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder={
                          clientSegment === 'شركات / مؤسسات'
                            ? 'مثال: شركة الرواد للتجارة - أ. كريم'
                            : 'مثال: محمد علي حسن'
                        }
                        className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="booking-phone"
                        className="block text-sm font-medium text-slate-800 mb-1.5"
                      >
                        رقم الهاتف
                      </label>
                      <input
                        id="booking-phone"
                        type="tel"
                        dir="ltr"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="01012345678"
                        className="w-full text-end px-3.5 py-2.5 text-sm font-mono-nums bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="booking-address"
                      className="block text-sm font-medium text-slate-800 mb-1.5"
                    >
                      العنوان بالتفصيل
                    </label>
                    <input
                      id="booking-address"
                      type="text"
                      required
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="المحافظة، الحي، اسم الشارع، رقم العقار والدور"
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="booking-device"
                        className="block text-sm font-medium text-slate-800 mb-1.5"
                      >
                        نوع الجهاز
                      </label>
                      <select
                        id="booking-device"
                        value={deviceType}
                        onChange={(e) => setDeviceType(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                      >
                        {DEVICE_TYPES.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <div className="flex items-center justify-between mb-1.5">
                        <label
                          htmlFor="booking-service-0"
                          className="block text-sm font-medium text-slate-800"
                        >
                          الخدمة المطلوبة (يمكنك اختيار أكثر من خدمة في نفس الطلب)
                        </label>
                        {selectedServiceIds.length > 0 && (
                          <span className="text-xs font-semibold text-blue-700 tabular-nums">
                            {selectedServiceIds.length} خدمة مختارة
                          </span>
                        )}
                      </div>

                      <div className="space-y-2.5">
                        {selectedServiceIds.map((srvId, idx) => {
                          const availableForSlot = services.filter(
                            (s) => s.id === srvId || !selectedServiceIds.includes(s.id)
                          );
                          return (
                            <div key={`${srvId}-${idx}`} className="flex items-center gap-2">
                              <select
                                id={idx === 0 ? 'booking-service-0' : `booking-service-${idx}`}
                                aria-label={`الخدمة رقم ${idx + 1}`}
                                value={srvId}
                                onChange={(e) => {
                                  const nextId = e.target.value;
                                  setSelectedServiceIds((prev) =>
                                    prev.map((id, i) => (i === idx ? nextId : id))
                                  );
                                }}
                                className="flex-1 px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                              >
                                {availableForSlot.map((srv) => (
                                  <option key={srv.id} value={srv.id}>
                                    {srv.title} ({formatEGP(srv.startingPrice)})
                                  </option>
                                ))}
                              </select>

                              {selectedServiceIds.length > 1 && (
                                <button
                                  type="button"
                                  aria-label={`إزالة الخدمة رقم ${idx + 1}`}
                                  onClick={() =>
                                    setSelectedServiceIds((prev) =>
                                      prev.filter((_, i) => i !== idx)
                                    )
                                  }
                                  className="p-2.5 text-slate-500 hover:text-red-700 bg-slate-100 hover:bg-red-50 rounded-lg transition-colors cursor-pointer shrink-0"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          );
                        })}

                        {/* Illuminated Next Service Selector when a service is chosen */}
                        {selectedServiceIds.length > 0 && unselectedServices.length > 0 && (
                          <div className="p-3 rounded-lg border-2 border-blue-500 bg-blue-50/75 ring-4 ring-blue-500/15 transition-all">
                            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-800 mb-1.5">
                              <Plus className="w-3.5 h-3.5" />
                              <span>
                                تم تفعيل خانة إضافية: اختر خدمة أخرى لإضافتها إلى نفس الطلب
                                (اختياري)
                              </span>
                            </div>
                            <select
                              aria-label="إضافة خدمة صيانة أخرى"
                              value=""
                              onChange={(e) => {
                                const nextId = e.target.value;
                                if (!nextId) return;
                                setSelectedServiceIds((prev) =>
                                  prev.includes(nextId) ? prev : [...prev, nextId]
                                );
                              }}
                              className="w-full px-3.5 py-2 text-sm bg-white border border-blue-400 rounded-md text-slate-900 font-medium focus:outline-none focus:border-blue-700"
                            >
                              <option value="">+ اختر خدمة إضافية لإضافتها للطلب...</option>
                              {unselectedServices.map((srv) => (
                                <option key={srv.id} value={srv.id}>
                                  {srv.title} ({formatEGP(srv.startingPrice)})
                                </option>
                              ))}
                            </select>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="booking-date"
                        className="block text-sm font-medium text-slate-800 mb-1.5"
                      >
                        التاريخ المناسب للزيارة
                      </label>
                      <input
                        id="booking-date"
                        type="date"
                        value={preferredDate}
                        onChange={(e) => setPreferredDate(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm font-mono-nums bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="booking-slot"
                        className="block text-sm font-medium text-slate-800 mb-1.5"
                      >
                        الفترة الزمنية المناسبة
                      </label>
                      <select
                        id="booking-slot"
                        value={preferredTimeSlot}
                        onChange={(e) => setPreferredTimeSlot(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                      >
                        {TIME_SLOTS.map((slot) => (
                          <option key={slot} value={slot}>
                            {slot}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="booking-problem"
                      className="block text-sm font-medium text-slate-800 mb-1.5"
                    >
                      وصف المشكلة وموديل الجهاز
                    </label>
                    <textarea
                      id="booking-problem"
                      rows={3}
                      required
                      value={problemDescription}
                      onChange={(e) => setProblemDescription(e.target.value)}
                      placeholder="اذكر موديل الجهاز (مثال: Dell XPS 15) وتفاصيل العطل أو الترقية المطلوبة..."
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                    />
                  </div>

                  {/* Merge Cart Items Option */}
                  {cart.length > 0 && (
                    <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-3">
                      <input
                        id="attach-cart-checkbox"
                        type="checkbox"
                        checked={attachCartToBooking}
                        onChange={(e) => onToggleAttachCart(e.target.checked)}
                        className="mt-1 h-4 w-4 rounded border-slate-300 text-blue-700 focus:ring-blue-700 cursor-pointer"
                      />
                      <label
                        htmlFor="attach-cart-checkbox"
                        className="text-sm text-slate-800 cursor-pointer flex-1"
                      >
                        <span className="font-semibold inline-flex items-center gap-1.5">
                          <PackageCheck className="w-4 h-4 text-blue-700" />
                          <span>
                            دمج منتجات سلة المشتريات ({cart.reduce((s, i) => s + i.quantity, 0)}{' '}
                            منتج · {formatEGP(cartSubtotal)}) مع زيارة الصيانة
                          </span>
                        </span>
                        <span className="block text-xs text-slate-500 mt-1">
                          سيحضر الفني الإكسسوارات المطلوبة معه في نفس الزيارة بدون رسوم توصيل
                          إضافية.
                        </span>
                      </label>
                    </div>
                  )}

                  {formError && (
                    <div
                      role="alert"
                      className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800"
                    >
                      {formError}
                    </div>
                  )}

                  <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
                    <span className="text-xs text-slate-500">
                      الدفع عند الاستلام أو بعد إتمام الصيانة والتجربة
                    </span>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="px-6 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      {submitting ? 'جاري إرسال الطلب...' : 'تأكيد وإرسال طلب الصيانة'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
