import { useState } from 'react';
import { createPortal } from 'react-dom';
import { Download, Printer, X } from 'lucide-react';
import type { CustomerOrder, SiteSettings } from '../types';
import {
  buildOrderWhatsAppMessage,
  buildWhatsAppUrl,
  DEFAULT_LOGO_URL,
  formatArabicDate,
  formatEGP,
  resolveAssetUrl,
} from '../utils/format';
import { downloadOrderInvoicePdf } from '../utils/invoicePdf';
import { SocialBrandIcon } from './SocialBrandIcon';

interface OrderInvoiceModalProps {
  order: CustomerOrder;
  siteSettings: SiteSettings;
  onClose: () => void;
}

function orderTypeArabic(type: CustomerOrder['orderType']): string {
  switch (type) {
    case 'maintenance':
      return 'حجز زيارة صيانة';
    case 'store':
      return 'طلب منتجات من المتجر';
    case 'combined':
      return 'صيانة + منتجات متجر';
  }
}

export function OrderInvoiceModal({
  order,
  siteSettings,
  onClose,
}: OrderInvoiceModalProps) {
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  const serviceTitles =
    order.serviceTitles && order.serviceTitles.length > 0
      ? order.serviceTitles
      : order.serviceTitle
        ? [order.serviceTitle]
        : [];
  const servicesSubtotal =
    order.serviceStartingPrice ?? Math.max(0, order.estimatedTotal - order.productsTotal);

  const whatsappHref = buildWhatsAppUrl(order.phone, buildOrderWhatsAppMessage(order));

  const handleDownloadPdf = async () => {
    setDownloadingPdf(true);
    try {
      await downloadOrderInvoicePdf(order, siteSettings);
    } finally {
      setDownloadingPdf(false);
    }
  };

  return createPortal(
    <div
      id="printable-invoice-root"
      role="dialog"
      aria-modal="true"
      aria-label={`فاتورة الطلب ${order.orderNumber}`}
      className="fixed inset-0 z-50 flex flex-col items-center justify-start bg-slate-900/65 p-3 sm:p-6 overflow-y-auto"
    >
      {/* Top Action Toolbar (Hidden when printing) */}
      <div className="print:hidden w-full max-w-3xl bg-slate-900 text-white rounded-t-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-slate-700 sticky top-0 z-10">
        <div className="text-sm font-bold">
          معاينة الفاتورة الرسمية ·{' '}
          <span className="font-mono-nums text-blue-300">{order.orderNumber}</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={downloadingPdf}
            onClick={handleDownloadPdf}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{downloadingPdf ? 'جاري التجهيز...' : 'تحميل ملف PDF'}</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة الفاتورة</span>
          </button>

          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
          >
            <SocialBrandIcon platform="whatsapp" className="w-4 h-4" />
            <span>إرسال واتساب للعميل</span>
          </a>

          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق الفاتورة"
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Printable A4 Sheet */}
      <div
        id="printable-invoice-sheet"
        className="w-full max-w-3xl bg-white text-slate-900 rounded-b-xl border border-slate-200 shadow-2xl p-6 sm:p-10 space-y-6"
      >
        {/* Top Accent & Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b-2 border-blue-700 pb-6">
          <div className="flex items-center gap-3.5">
            <img
              src={resolveAssetUrl(siteSettings.logoUrl || DEFAULT_LOGO_URL)}
              alt="شعار ASh tech"
              className="h-14 w-auto object-contain"
            />
            <div>
              <div dir="ltr" className="font-display text-2xl font-extrabold text-slate-900 text-end">
                ASh tech
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                للصيانة الهندسية وأجهزة اللاب توب والكمبيوتر والإكسسوارات
              </p>
            </div>
          </div>

          <div className="text-start sm:text-end">
            <div className="text-xs font-bold text-blue-700 mb-1">فاتورة ومستند طلب</div>
            <div className="font-mono-nums text-xl font-extrabold text-slate-900">
              #{order.orderNumber}
            </div>
            <div className="text-xs text-slate-500 mt-1 tabular-nums">
              {formatArabicDate(order.createdAt)}
            </div>
          </div>
        </div>

        {/* Customer & Order Meta Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-sm">
            <div className="text-xs font-bold text-blue-700 mb-2">بيانات العميل</div>
            <div className="font-bold text-slate-900 text-base">{order.customerName}</div>
            <div className="text-xs text-slate-700">
              رقم الهاتف:{' '}
              <span dir="ltr" className="font-mono-nums font-semibold">
                {order.phone}
              </span>
            </div>
            <div className="text-xs text-slate-700">الفئة: {order.clientSegment}</div>
            <div className="text-xs text-slate-600 leading-relaxed">العنوان: {order.address}</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-sm">
            <div className="text-xs font-bold text-blue-700 mb-2">ملخص حالة الطلب</div>
            <div className="text-xs text-slate-700">
              نوع الطلب: <span className="font-semibold text-slate-900">{orderTypeArabic(order.orderType)}</span>
            </div>
            <div className="text-xs text-slate-700">
              الحالة الحالية: <span className="font-bold text-blue-700">{order.status}</span>
            </div>
            {order.deviceType && (
              <div className="text-xs text-slate-700">الجهاز: {order.deviceType}</div>
            )}
            {order.preferredDate && (
              <div className="text-xs text-slate-700 tabular-nums">
                الموعد المفضل: {order.preferredDate} · {order.preferredTimeSlot}
              </div>
            )}
          </div>
        </div>

        {/* Line Items Table */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-start border-collapse text-sm">
            <thead>
              <tr className="bg-slate-900 text-white text-xs font-bold">
                <th className="py-3 px-4 text-start">البند (الخدمة / المنتج)</th>
                <th className="py-3 px-4 text-center w-20">الكمية</th>
                <th className="py-3 px-4 text-center w-32">سعر الوحدة</th>
                <th className="py-3 px-4 text-end w-32">الإجمالي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {serviceTitles.length > 0 && (
                <tr>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900">خدمات الصيانة المطلوبة</div>
                    <ul className="text-xs text-slate-600 mt-1 space-y-0.5">
                      {serviceTitles.map((t, i) => (
                        <li key={i}>· {t}</li>
                      ))}
                    </ul>
                  </td>
                  <td className="py-3.5 px-4 text-center tabular-nums">
                    {serviceTitles.length}
                  </td>
                  <td className="py-3.5 px-4 text-center tabular-nums">
                    {formatEGP(servicesSubtotal)}
                  </td>
                  <td className="py-3.5 px-4 text-end font-bold tabular-nums">
                    {formatEGP(servicesSubtotal)}
                  </td>
                </tr>
              )}

              {order.items.map((item) => (
                <tr key={item.productId}>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">
                    {item.productName}
                  </td>
                  <td className="py-3.5 px-4 text-center tabular-nums">{item.quantity}</td>
                  <td className="py-3.5 px-4 text-center tabular-nums">
                    {formatEGP(item.unitPrice)}
                  </td>
                  <td className="py-3.5 px-4 text-end font-bold tabular-nums">
                    {formatEGP(item.unitPrice * item.quantity)}
                  </td>
                </tr>
              ))}

              {serviceTitles.length === 0 && order.items.length === 0 && (
                <tr>
                  <td className="py-3.5 px-4 text-slate-700">
                    {order.problemDescription || 'خدمة فحص وصيانة'}
                  </td>
                  <td className="py-3.5 px-4 text-center tabular-nums">1</td>
                  <td className="py-3.5 px-4 text-center tabular-nums">
                    {formatEGP(order.estimatedTotal)}
                  </td>
                  <td className="py-3.5 px-4 text-end font-bold tabular-nums">
                    {formatEGP(order.estimatedTotal)}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Notes & Totals */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-start">
          <div className="sm:col-span-7">
            {(order.technicianNotes || order.problemDescription) && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                <div className="font-bold text-slate-900">ملاحظات الصيانة / الطلب:</div>
                {order.problemDescription && (
                  <p className="text-slate-600">{order.problemDescription}</p>
                )}
                {order.technicianNotes && (
                  <p className="text-slate-800 font-medium">{order.technicianNotes}</p>
                )}
              </div>
            )}
          </div>

          <div className="sm:col-span-5 p-4 rounded-xl bg-blue-50/70 border border-blue-200 space-y-2 text-sm">
            {servicesSubtotal > 0 && (
              <div className="flex items-center justify-between text-xs text-slate-700">
                <span>تكلفة الصيانة المبدئية</span>
                <span className="font-semibold tabular-nums">{formatEGP(servicesSubtotal)}</span>
              </div>
            )}
            {order.productsTotal > 0 && (
              <div className="flex items-center justify-between text-xs text-slate-700">
                <span>إجمالي المنتجات والأجهزة</span>
                <span className="font-semibold tabular-nums">{formatEGP(order.productsTotal)}</span>
              </div>
            )}
            <div className="pt-2 border-t border-blue-200 flex items-center justify-between">
              <span className="font-bold text-slate-900">الإجمالي المقدر</span>
              <span className="font-display text-xl font-extrabold text-blue-800 tabular-nums">
                {formatEGP(order.estimatedTotal)}
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-5 border-t border-slate-200 text-center space-y-1 text-xs text-slate-500">
          <div className="font-semibold text-slate-800">
            ASh tech · خدمة العملاء:{' '}
            {siteSettings.contactPhones.length > 0
              ? siteSettings.contactPhones.map((p) => p.number).join(' · ')
              : '01009116199'}
          </div>
          <p>
            يرجى الاحتفاظ بهذه الفاتورة لضمان حقك في المتابعة والصيانة والاستبدال.
          </p>
        </div>
      </div>
    </div>,
    document.body
  );
}
