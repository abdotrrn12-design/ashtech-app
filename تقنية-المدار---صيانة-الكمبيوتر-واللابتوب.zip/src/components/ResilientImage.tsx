import { useEffect, useState } from 'react';
import { Monitor } from 'lucide-react';
import { resolveAssetUrl } from '../utils/format';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
}

export function ResilientImage({
  src,
  alt,
  className = '',
  fallbackLabel,
}: ResilientImageProps) {
  const resolvedSrc = resolveAssetUrl(src);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [resolvedSrc]);

  if (hasError || !resolvedSrc) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-slate-100 text-slate-400 p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Monitor className="w-10 h-10 mb-2 text-slate-400" strokeWidth={1.5} />
        <span className="text-xs font-medium text-slate-500 max-w-[180px] truncate">
          {fallbackLabel || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={resolvedSrc}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
