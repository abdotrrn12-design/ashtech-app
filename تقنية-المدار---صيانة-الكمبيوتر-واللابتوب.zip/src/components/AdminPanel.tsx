import { ChangeEvent, FormEvent, useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Download,
  Edit3,
  FileText,
  KeyRound,
  Lock,
  LogOut,
  Mail,
  Phone,
  Plus,
  Search,
  Trash2,
  Upload,
  Users,
  X,
} from 'lucide-react';
import type {
  AuthUser,
  ComputerDevice,
  CustomerOrder,
  MaintenanceService,
  OrderStatus,
  PermissionKey,
  ProductCategory,
  PromotionalOffer,
  ServiceCategory,
  SiteSettings,
  StaffUser,
  StoreProduct,
} from '../types';
import {
  buildOrderWhatsAppMessage,
  buildWhatsAppUrl,
  formatArabicDate,
  formatEGP,
  PRODUCT_IMAGE_PRESETS,
} from '../utils/format';
import { DevicesManagerTab } from './DevicesManagerTab';
import { OffersManagerTab } from './OffersManagerTab';
import { OrderInvoiceModal } from './OrderInvoiceModal';
import { ResilientImage } from './ResilientImage';
import { SiteSettingsManagerTab } from './SiteSettingsManagerTab';
import { SocialBrandIcon } from './SocialBrandIcon';
import { StaffManagerTab } from './StaffManagerTab';

interface AdminPanelProps {
  portalMode: 'admin' | 'staff';
  adminToken: string | null;
  authUser: AuthUser | null;
  onLoginSuccess: (token: string, user: AuthUser) => void;
  onLogout: () => void;
  onEmailUpdated: (email: string) => void;
  services: MaintenanceService[];
  products: StoreProduct[];
  devices: ComputerDevice[];
  orders: CustomerOrder[];
  offers: PromotionalOffer[];
  siteSettings: SiteSettings;
  staffUsers: StaffUser[];
  loadingOrders: boolean;
  onServicesChange: (services: MaintenanceService[]) => void;
  onProductsChange: (products: StoreProduct[]) => void;
  onDevicesChange: (devices: ComputerDevice[]) => void;
  onOrdersChange: (orders: CustomerOrder[]) => void;
  onOffersChange: (offers: PromotionalOffer[]) => void;
  onSiteSettingsChange: (settings: SiteSettings) => void;
  onStaffChange: (staffUsers: StaffUser[]) => void;
}

type AdminTab =
  | 'orders'
  | 'services'
  | 'products'
  | 'devices'
  | 'offers'
  | 'siteSettings'
  | 'staff';

const ORDER_STATUSES: OrderStatus[] = [
  'قيد الانتظار',
  'جاري التحضير',
  'جاري التوصيل',
  'جاري الصيانة',
  'تم الانتهاء',
  'ملغي',
];
const SERVICE_CATEGORIES: ServiceCategory[] = [
  'تبريد وتنظيف',
  'هاردوير',
  'سوفت وير',
  'شركات',
];
const PRODUCT_CATEGORIES: ProductCategory[] = [
  'ماوس وكيبورد',
  'قواعد تبريد',
  'شنط لاب توب',
  'شواحن',
  'فلاشات وتخزين',
];

function statusStyle(status: OrderStatus): string {
  switch (status) {
    case 'قيد الانتظار':
      return 'text-amber-800 bg-amber-50 border-amber-200';
    case 'جاري التحضير':
      return 'text-indigo-800 bg-indigo-50 border-indigo-200';
    case 'جاري التوصيل':
      return 'text-cyan-800 bg-cyan-50 border-cyan-200';
    case 'جاري الصيانة':
      return 'text-blue-700 bg-blue-50 border-blue-200';
    case 'تم الانتهاء':
      return 'text-emerald-800 bg-emerald-50 border-emerald-200';
    case 'ملغي':
      return 'text-red-800 bg-red-50 border-red-200';
  }
}

function orderTypeLabel(type: CustomerOrder['orderType']): string {
  switch (type) {
    case 'maintenance':
      return 'حجز صيانة';
    case 'store':
      return 'طلب متجر';
    case 'combined':
      return 'صيانة + إكسسوارات';
  }
}

export function AdminPanel({
  portalMode,
  adminToken,
  authUser,
  onLoginSuccess,
  onLogout,
  onEmailUpdated,
  services,
  products,
  devices,
  orders,
  offers,
  siteSettings,
  staffUsers,
  loadingOrders,
  onServicesChange,
  onProductsChange,
  onDevicesChange,
  onOrdersChange,
  onOffersChange,
  onSiteSettingsChange,
  onStaffChange,
}: AdminPanelProps) {
  // Login & Password Recovery State
  const [authMode, setAuthMode] = useState<'login' | 'forgot' | 'reset'>('login');
  const [loginEmail, setLoginEmail] = useState('');
  const [staffUsername, setStaffUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loggingIn, setLoggingIn] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryCode, setRecoveryCode] = useState('');
  const [recoveryNewPassword, setRecoveryNewPassword] = useState('');
  const [recoverySuccess, setRecoverySuccess] = useState('');
  const [recoveryLoading, setRecoveryLoading] = useState(false);

  // Dashboard State
  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [statusFilter, setStatusFilter] = useState<'الكل' | OrderStatus>('الكل');
  const [orderSearch, setOrderSearch] = useState('');
  const [noteDrafts, setNoteDrafts] = useState<Record<string, string>>({});
  const [invoiceOrder, setInvoiceOrder] = useState<CustomerOrder | null>(null);
  const [actionError, setActionError] = useState('');
  const [actionSuccess, setActionSuccess] = useState('');

  // Credentials Modal State
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingCredentials, setSavingCredentials] = useState(false);

  // Service Form Modal State
  const [serviceModalOpen, setServiceModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<MaintenanceService | null>(null);
  const [srvTitle, setSrvTitle] = useState('');
  const [srvCategory, setSrvCategory] = useState<ServiceCategory>('هاردوير');
  const [srvPrice, setSrvPrice] = useState('350');
  const [srvDuration, setSrvDuration] = useState('60 دقيقة');
  const [srvWarranty, setSrvWarranty] = useState('ضمان 3 أشهر');
  const [srvDesc, setSrvDesc] = useState('');
  const [savingService, setSavingService] = useState(false);

  // Product Form Modal State
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<StoreProduct | null>(null);
  const [prdName, setPrdName] = useState('');
  const [prdCategory, setPrdCategory] = useState<ProductCategory>('ماوس وكيبورد');
  const [prdPrice, setPrdPrice] = useState('450');
  const [prdStock, setPrdStock] = useState('10');
  const [prdDesc, setPrdDesc] = useState('');
  const [prdImage, setPrdImage] = useState(PRODUCT_IMAGE_PRESETS[0].url);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [savingProduct, setSavingProduct] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const isOwner = authUser?.role === 'owner';
  const hasPerm = (perm: PermissionKey) =>
    Boolean(isOwner || authUser?.permissions.includes(perm));

  const allowedTabs: AdminTab[] = [];
  if (hasPerm('view_orders') || hasPerm('update_order_status')) allowedTabs.push('orders');
  if (hasPerm('manage_services')) allowedTabs.push('services');
  if (hasPerm('manage_products')) allowedTabs.push('products');
  if (hasPerm('manage_devices')) allowedTabs.push('devices');
  if (hasPerm('manage_offers')) allowedTabs.push('offers');
  if (hasPerm('manage_site_settings')) allowedTabs.push('siteSettings');
  if (isOwner) allowedTabs.push('staff');

  useEffect(() => {
    setLoginError('');
    setRecoverySuccess('');
    setAuthMode('login');
  }, [portalMode]);

  useEffect(() => {
    if (allowedTabs.length > 0 && !allowedTabs.includes(activeTab)) {
      setActiveTab(allowedTabs[0]);
    }
  }, [authUser?.id, authUser?.permissions.join(',')]);

  const notifySuccess = (message: string) => {
    setActionSuccess(message);
    window.setTimeout(() => {
      setActionSuccess((curr) => (curr === message ? '' : curr));
    }, 3500);
  };

  const handleLoginSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoggingIn(true);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: loginEmail.trim(),
          password: loginPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || 'بيانات الدخول غير صحيحة.');
        return;
      }
      setLoginPassword('');
      onLoginSuccess(data.token as string, data.user as AuthUser);
    } catch {
      setLoginError('تعذر الاتصال بالخادم.');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleStaffLoginSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoggingIn(true);
    try {
      const res = await fetch('/api/staff/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: staffUsername.trim(),
          password: loginPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || 'اسم المستخدم أو كلمة المرور غير صحيحة.');
        return;
      }
      setLoginPassword('');
      onLoginSuccess(data.token as string, data.user as AuthUser);
    } catch {
      setLoginError('تعذر الاتصال بالخادم.');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setRecoverySuccess('');
    setRecoveryLoading(true);
    try {
      const res = await fetch('/api/admin/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: recoveryEmail.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || 'تعذر إرسال رمز الاستعادة.');
        return;
      }
      setRecoverySuccess(
        data.message ||
          'إذا كان البريد الإلكتروني مسجلاً، تم إرسال رمز الاستعادة. أدخل الرمز وكلمة المرور الجديدة.'
      );
      setAuthMode('reset');
    } catch {
      setLoginError('تعذر الاتصال بالخادم.');
    } finally {
      setRecoveryLoading(false);
    }
  };

  const handleResetPasswordSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setRecoverySuccess('');
    setRecoveryLoading(true);
    try {
      const res = await fetch('/api/admin/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: recoveryEmail.trim(),
          code: recoveryCode.trim(),
          newPassword: recoveryNewPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || 'تعذر إعادة تعيين كلمة المرور.');
        return;
      }
      setLoginEmail(recoveryEmail.trim());
      setLoginPassword('');
      setRecoveryCode('');
      setRecoveryNewPassword('');
      setRecoverySuccess(
        data.message || 'تم تحديث كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.'
      );
      setAuthMode('login');
    } catch {
      setLoginError('تعذر الاتصال بالخادم.');
    } finally {
      setRecoveryLoading(false);
    }
  };

  // Protected Login Gate (Admin Owner OR Staff Worker)
  if (!adminToken || !authUser) {
    if (portalMode === 'staff') {
      return (
        <div className="max-w-md mx-auto px-4 py-16 sm:py-24">
          <div className="bg-white border border-slate-200 rounded-xl p-8 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h1 className="font-display text-xl font-bold text-slate-900">
                  بوابة دخول الموظفين والعمال
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  مخصصة لفريق الصيانة والمتابعة حسب الصلاحيات المحددة من الإدارة
                </p>
              </div>
            </div>

            <form onSubmit={handleStaffLoginSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="staff-login-username"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  اسم المستخدم
                </label>
                <input
                  id="staff-login-username"
                  type="text"
                  dir="ltr"
                  required
                  autoComplete="username"
                  value={staffUsername}
                  onChange={(e) => setStaffUsername(e.target.value)}
                  placeholder="username"
                  className="w-full text-start px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              <div>
                <label
                  htmlFor="staff-login-password"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  كلمة المرور
                </label>
                <input
                  id="staff-login-password"
                  type="password"
                  dir="ltr"
                  required
                  autoComplete="current-password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full text-start px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              {loginError && (
                <div
                  role="alert"
                  className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800"
                >
                  {loginError}
                </div>
              )}

              <button
                type="submit"
                disabled={loggingIn}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                {loggingIn ? 'جاري التحقق...' : 'دخول الموظف'}
              </button>

              <p className="text-[11px] text-slate-500 text-center leading-relaxed">
                للحصول على حساب أو تعديل صلاحياتك، يرجى التواصل مع صاحب الشركة.
              </p>
            </form>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-md mx-auto px-4 py-16 sm:py-24">
        <div className="bg-white border border-slate-200 rounded-xl p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0">
              {authMode === 'login' ? (
                <Lock className="w-5 h-5" />
              ) : (
                <Mail className="w-5 h-5" />
              )}
            </div>
            <div>
              <h1 className="font-display text-xl font-bold text-slate-900">
                {authMode === 'login'
                  ? 'دخول لوحة التحكم (الإدارة)'
                  : 'استعادة كلمة السر للإدارة'}
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                {authMode === 'login'
                  ? 'مخصصة لصاحب الشركة فقط لإدارة الخدمات والمنتجات والطلبات'
                  : authMode === 'forgot'
                    ? 'أدخل البريد الإلكتروني للإدارة لإرسال رمز التحقق'
                    : 'أدخل رمز التحقق المرسل لبريدك الإلكتروني وكلمة السر الجديدة'}
              </p>
            </div>
          </div>

          {recoverySuccess && (
            <div
              role="status"
              className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-start gap-2"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{recoverySuccess}</span>
            </div>
          )}

          {authMode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="admin-login-email"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  البريد الإلكتروني للإدارة
                </label>
                <input
                  id="admin-login-email"
                  type="email"
                  dir="ltr"
                  required
                  autoComplete="username"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full text-start px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label
                    htmlFor="admin-login-password"
                    className="block text-sm font-medium text-slate-800"
                  >
                    كلمة المرور
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setLoginError('');
                      setRecoverySuccess('');
                      if (loginEmail.trim()) setRecoveryEmail(loginEmail.trim());
                      setAuthMode('forgot');
                    }}
                    className="text-xs font-medium text-blue-700 hover:text-blue-800 cursor-pointer"
                  >
                    نسيت كلمة السر؟
                  </button>
                </div>
                <input
                  id="admin-login-password"
                  type="password"
                  dir="ltr"
                  required
                  autoComplete="current-password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full text-start px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              {loginError && (
                <div
                  role="alert"
                  className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800"
                >
                  {loginError}
                </div>
              )}

              <button
                type="submit"
                disabled={loggingIn}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-slate-900 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                {loggingIn ? 'جاري التحقق...' : 'تسجيل الدخول'}
              </button>

              <button
                type="button"
                onClick={() => {
                  setLoginError('');
                  setRecoverySuccess('');
                  if (loginEmail.trim()) setRecoveryEmail(loginEmail.trim());
                  setAuthMode('forgot');
                }}
                className="w-full py-2 px-3 text-xs font-medium text-slate-600 hover:text-blue-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
              >
                استعادة كلمة السر عن طريق البريد الإلكتروني
              </button>
            </form>
          )}

          {authMode === 'forgot' && (
            <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="admin-recovery-email"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  البريد الإلكتروني لاستعادة كلمة السر
                </label>
                <input
                  id="admin-recovery-email"
                  type="email"
                  dir="ltr"
                  required
                  autoComplete="email"
                  value={recoveryEmail}
                  onChange={(e) => setRecoveryEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full text-start px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              {loginError && (
                <div
                  role="alert"
                  className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800"
                >
                  {loginError}
                </div>
              )}

              <button
                type="submit"
                disabled={recoveryLoading}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                {recoveryLoading ? 'جاري الإرسال...' : 'إرسال رمز الاستعادة'}
              </button>

              <div className="flex items-center justify-between pt-1 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setLoginError('');
                    setAuthMode('login');
                  }}
                  className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>العودة لتسجيل الدخول</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLoginError('');
                    setAuthMode('reset');
                  }}
                  className="text-blue-700 hover:text-blue-800 font-medium cursor-pointer"
                >
                  لدي رمز تحقق بالفعل
                </button>
              </div>
            </form>
          )}

          {authMode === 'reset' && (
            <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="admin-reset-email"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  البريد الإلكتروني
                </label>
                <input
                  id="admin-reset-email"
                  type="email"
                  dir="ltr"
                  required
                  value={recoveryEmail}
                  onChange={(e) => setRecoveryEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full text-start px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              <div>
                <label
                  htmlFor="admin-reset-code"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  رمز التحقق (6 أرقام)
                </label>
                <input
                  id="admin-reset-code"
                  type="text"
                  inputMode="numeric"
                  dir="ltr"
                  required
                  maxLength={6}
                  value={recoveryCode}
                  onChange={(e) => setRecoveryCode(e.target.value)}
                  placeholder="123456"
                  className="w-full text-start font-mono-nums px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              <div>
                <label
                  htmlFor="admin-reset-new-password"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  كلمة السر الجديدة (6 أحرف على الأقل)
                </label>
                <input
                  id="admin-reset-new-password"
                  type="password"
                  dir="ltr"
                  required
                  minLength={6}
                  autoComplete="new-password"
                  value={recoveryNewPassword}
                  onChange={(e) => setRecoveryNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full text-start px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
                />
              </div>

              {loginError && (
                <div
                  role="alert"
                  className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800"
                >
                  {loginError}
                </div>
              )}

              <button
                type="submit"
                disabled={recoveryLoading}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-slate-900 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                {recoveryLoading ? 'جاري التحديث...' : 'تعيين كلمة السر الجديدة'}
              </button>

              <div className="flex items-center justify-between pt-1 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setLoginError('');
                    setAuthMode('login');
                  }}
                  className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>العودة لتسجيل الدخول</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLoginError('');
                    setAuthMode('forgot');
                  }}
                  className="text-blue-700 hover:text-blue-800 font-medium cursor-pointer"
                >
                  إعادة إرسال الرمز
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  const authHeaders = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${adminToken}`,
  };

  const newOrdersCount = orders.filter((o) => o.status === 'قيد الانتظار').length;

  const filteredOrders = orders.filter((order) => {
    const matchesStatus = statusFilter === 'الكل' || order.status === statusFilter;
    const q = orderSearch.trim().toLowerCase();
    const matchesQuery =
      !q ||
      order.customerName.toLowerCase().includes(q) ||
      order.phone.includes(q) ||
      order.orderNumber.toLowerCase().includes(q);
    return matchesStatus && matchesQuery;
  });

  // Order Handlers
  const handleStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    setActionError('');
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PATCH',
        headers: authHeaders,
        body: JSON.stringify({ status: newStatus }),
      });
      if (!res.ok) {
        if (res.status === 401) onLogout();
        setActionError('تعذر تحديث حالة الطلب.');
        return;
      }
      const updated = (await res.json()) as CustomerOrder;
      onOrdersChange(orders.map((o) => (o.id === orderId ? updated : o)));
      notifySuccess(`تم تحديث حالة الطلب (${updated.orderNumber}) إلى "${newStatus}".`);
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    }
  };

  const handleSaveTechnicianNote = async (orderId: string) => {
    setActionError('');
    const noteValue = noteDrafts[orderId] ?? '';
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PATCH',
        headers: authHeaders,
        body: JSON.stringify({ technicianNotes: noteValue }),
      });
      if (!res.ok) {
        if (res.status === 401) onLogout();
        setActionError('تعذر حفظ ملاحظة الصيانة.');
        return;
      }
      const updated = (await res.json()) as CustomerOrder;
      onOrdersChange(orders.map((o) => (o.id === orderId ? updated : o)));
      notifySuccess(`تم حفظ ملاحظات الصيانة للطلب (${updated.orderNumber}).`);
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    setActionError('');
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (!res.ok) {
        if (res.status === 401) onLogout();
        setActionError('تعذر حذف الطلب.');
        return;
      }
      onOrdersChange(orders.filter((o) => o.id !== orderId));
      notifySuccess('تم حذف الطلب بنجاح.');
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    }
  };

  // Account Credentials Update
  const openAccountSettings = () => {
    setNewEmail(authUser.identifier || '');
    setCurrentPassword('');
    setNewPassword('');
    setActionError('');
    setAccountModalOpen(true);
  };

  const handleUpdateCredentials = async (e: FormEvent) => {
    e.preventDefault();
    setActionError('');
    setSavingCredentials(true);
    try {
      const res = await fetch('/api/admin/credentials', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({
          currentPassword,
          newEmail: newEmail.trim(),
          newPassword: newPassword || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setActionError(data.error || 'تعذر تحديث بيانات الحساب.');
        return;
      }
      onEmailUpdated(data.email as string);
      setAccountModalOpen(false);
      notifySuccess('تم تحديث بيانات حساب الإدارة بنجاح.');
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    } finally {
      setSavingCredentials(false);
    }
  };

  // Service Modal Helpers
  const openCreateService = () => {
    setEditingService(null);
    setSrvTitle('');
    setSrvCategory('هاردوير');
    setSrvPrice('350');
    setSrvDuration('60 دقيقة');
    setSrvWarranty('ضمان 3 أشهر');
    setSrvDesc('');
    setServiceModalOpen(true);
  };

  const openEditService = (srv: MaintenanceService) => {
    setEditingService(srv);
    setSrvTitle(srv.title);
    setSrvCategory(srv.category);
    setSrvPrice(String(srv.startingPrice));
    setSrvDuration(srv.estimatedDuration);
    setSrvWarranty(srv.warranty);
    setSrvDesc(srv.description);
    setServiceModalOpen(true);
  };

  const handleSaveService = async (e: FormEvent) => {
    e.preventDefault();
    setActionError('');
    setSavingService(true);
    try {
      const payload = {
        title: srvTitle.trim(),
        category: srvCategory,
        startingPrice: Number(srvPrice),
        estimatedDuration: srvDuration.trim(),
        warranty: srvWarranty.trim(),
        description: srvDesc.trim(),
      };
      const url = editingService
        ? `/api/services/${editingService.id}`
        : '/api/services';
      const method = editingService ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: authHeaders,
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        if (res.status === 401) onLogout();
        const err = await res.json();
        setActionError(err.error || 'تعذر حفظ الخدمة.');
        return;
      }
      const saved = (await res.json()) as MaintenanceService;
      if (editingService) {
        onServicesChange(services.map((s) => (s.id === saved.id ? saved : s)));
        notifySuccess('تم تعديل خدمة الصيانة وتحديث السعر بنجاح.');
      } else {
        onServicesChange([...services, saved]);
        notifySuccess('تمت إضافة خدمة الصيانة الجديدة بنجاح.');
      }
      setServiceModalOpen(false);
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    } finally {
      setSavingService(false);
    }
  };

  const handleDeleteService = async (id: string) => {
    setActionError('');
    try {
      const res = await fetch(`/api/services/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (!res.ok) {
        if (res.status === 401) onLogout();
        setActionError('تعذر حذف الخدمة.');
        return;
      }
      onServicesChange(services.filter((s) => s.id !== id));
      notifySuccess('تم حذف خدمة الصيانة.');
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    }
  };

  // Product Modal & Image Upload Helpers
  const openCreateProduct = () => {
    setEditingProduct(null);
    setPrdName('');
    setPrdCategory('');
    setPrdPrice('450');
    setPrdStock('10');
    setPrdDesc('');
    setPrdImage(PRODUCT_IMAGE_PRESETS[0].url);
    setUploadError('');
    setProductModalOpen(true);
  };

  const openEditProduct = (prd: StoreProduct) => {
    setEditingProduct(prd);
    setPrdName(prd.name);
    setPrdCategory(prd.category);
    setPrdPrice(String(prd.price));
    setPrdStock(String(prd.stock));
    setPrdDesc(prd.description);
    setPrdImage(prd.imageUrl);
    setUploadError('');
    setProductModalOpen(true);
  };

  const handleImageFileSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError('');

    if (!file.type.startsWith('image/')) {
      setUploadError('يرجى اختيار ملف صورة صالح (JPG, PNG, WEBP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('الحد الأقصى لحجم الصورة هو 5 ميجابايت.');
      return;
    }

    setUploadingImage(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('read_error'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ dataUrl, filename: file.name }),
      });
      const data = await res.json();
      if (!res.ok) {
        setUploadError(data.error || 'تعذر رفع الصورة.');
        return;
      }
      setPrdImage(data.url as string);
    } catch {
      setUploadError('حدث خطأ أثناء رفع الصورة.');
    } finally {
      setUploadingImage(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSaveProduct = async (e: FormEvent) => {
    e.preventDefault();
    setActionError('');
    setSavingProduct(true);
    try {
      const payload = {
        name: prdName.trim(),
        category: prdCategory.trim(),
        price: Number(prdPrice),
        stock: Number(prdStock),
        description: prdDesc.trim(),
        imageUrl: prdImage.trim(),
      };
      const url = editingProduct
        ? `/api/products/${editingProduct.id}`
        : '/api/products';
      const method = editingProduct ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: authHeaders,
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        if (res.status === 401) onLogout();
        const err = await res.json();
        setActionError(err.error || 'تعذر حفظ المنتج.');
        return;
      }
      const saved = (await res.json()) as StoreProduct;
      if (editingProduct) {
        onProductsChange(products.map((p) => (p.id === saved.id ? saved : p)));
        notifySuccess('تم تعديل بيانات وسعر المنتج بنجاح.');
      } else {
        onProductsChange([...products, saved]);
        notifySuccess('تمت إضافة المنتج الجديد إلى المتجر بنجاح.');
      }
      setProductModalOpen(false);
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    } finally {
      setSavingProduct(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    setActionError('');
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (!res.ok) {
        if (res.status === 401) onLogout();
        setActionError('تعذر حذف المنتج.');
        return;
      }
      onProductsChange(products.filter((p) => p.id !== id));
      notifySuccess('تم حذف المنتج من المتجر.');
    } catch {
      setActionError('خطأ في الاتصال بالخادم.');
    }
  };

  const handleDownloadSingleHtml = async () => {
    setActionError('');
    try {
      const res = await fetch('/api/export-single-html', {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (!res.ok) {
        setActionError('تعذر تحميل ملف HTML الموحد.');
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'index.html';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      notifySuccess('تم تحميل ملف HTML الواحد (index.html) بنجاح.');
    } catch {
      setActionError('حدث خطأ أثناء تحميل الملف.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-20 space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <p className="text-xs font-semibold text-blue-700 mb-1.5">
            {isOwner
              ? `حساب الإدارة (صاحب الشركة) · ${authUser.identifier}`
              : `حساب موظف (${authUser.roleTitle || 'فريق العمل'}) · ${authUser.name}`}
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">
            {isOwner ? 'لوحة تحكم الإدارة' : 'لوحة متابعة فريق العمل'}
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            {isOwner
              ? 'متابعة الطلبات، إدارة الخدمات والمنتجات والعروض المتحركة، وتحديد صلاحيات الموظفين.'
              : 'الأقسام المفعلة لحسابك وفق الصلاحيات الممنوحة من إدارة الشركة.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Sub-Navigation Tabs (Permission-Scoped) */}
          {allowedTabs.length > 0 && (
            <div
              role="tablist"
              aria-label="أقسام لوحة التحكم"
              className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200"
            >
              {allowedTabs.includes('orders') && (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'orders'}
                  onClick={() => setActiveTab('orders')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'orders'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  الطلبات ({orders.length})
                </button>
              )}
              {allowedTabs.includes('services') && (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'services'}
                  onClick={() => setActiveTab('services')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'services'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  الخدمات ({services.length})
                </button>
              )}
              {allowedTabs.includes('products') && (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'products'}
                  onClick={() => setActiveTab('products')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'products'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  الإكسسوارات ({products.length})
                </button>
              )}
              {allowedTabs.includes('devices') && (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'devices'}
                  onClick={() => setActiveTab('devices')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'devices'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  الأجهزة واللاب توب ({devices.length})
                </button>
              )}
              {allowedTabs.includes('offers') && (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'offers'}
                  onClick={() => setActiveTab('offers')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'offers'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  العروض المتحركة ({offers.length})
                </button>
              )}
              {allowedTabs.includes('siteSettings') && (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'siteSettings'}
                  onClick={() => setActiveTab('siteSettings')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'siteSettings'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  محتوى الرئيسية والتواصل
                </button>
              )}
              {allowedTabs.includes('staff') && (
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'staff'}
                  onClick={() => setActiveTab('staff')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'staff'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  الموظفين والعمال ({staffUsers.length})
                </button>
              )}
            </div>
          )}

          {isOwner && !window.__ASHTECH_STANDALONE__ && (
            <button
              type="button"
              onClick={handleDownloadSingleHtml}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 hover:bg-blue-100 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل ملف HTML واحد</span>
            </button>
          )}

          {isOwner && (
            <button
              type="button"
              onClick={openAccountSettings}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>إعدادات الحساب</span>
            </button>
          )}

          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-red-700 bg-white border border-red-200 hover:bg-red-50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>خروج</span>
          </button>
        </div>
      </div>

      {/* Empty Permissions Guard */}
      {allowedTabs.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-2">
          <p className="font-display text-base font-bold text-slate-900">
            لا توجد صلاحيات مفعلة لحسابك حالياً
          </p>
          <p className="text-xs text-slate-600">
            تواصل مع صاحب الشركة لتفعيل الصلاحيات المطلوبة لحسابك.
          </p>
        </div>
      )}

      {/* 4-Column Summary Metrics */}
      {allowedTabs.length > 0 && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {hasPerm('view_orders') || hasPerm('update_order_status') ? (
            <>
              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <div className="text-xs text-slate-500 mb-1">إجمالي الطلبات</div>
                <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
                  {orders.length}
                </div>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <div className="text-xs text-slate-500 mb-1">طلبات قيد الانتظار</div>
                <div className="font-display text-2xl font-bold text-blue-700 tabular-nums">
                  {newOrdersCount}
                </div>
              </div>
            </>
          ) : null}
          {hasPerm('manage_services') && (
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="text-xs text-slate-500 mb-1">خدمات الصيانة النشطة</div>
              <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
                {services.length}
              </div>
            </div>
          )}
          {hasPerm('manage_products') && (
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="text-xs text-slate-500 mb-1">منتجات الإكسسوارات</div>
              <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
                {products.length}
              </div>
            </div>
          )}
          {hasPerm('manage_devices') && (
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="text-xs text-slate-500 mb-1">أجهزة اللاب توب و PC والشاشات</div>
              <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
                {devices.length}
              </div>
            </div>
          )}
          {hasPerm('manage_offers') && (
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="text-xs text-slate-500 mb-1">إعلانات العروض المتحركة</div>
              <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
                {offers.filter((o) => o.active).length}
              </div>
            </div>
          )}
          {isOwner && (
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="text-xs text-slate-500 mb-1">حسابات الموظفين النشطة</div>
              <div className="font-display text-2xl font-bold text-slate-900 tabular-nums">
                {staffUsers.filter((s) => s.active).length}
              </div>
            </div>
          )}
        </div>
      )}

      {actionSuccess && (
        <div
          role="status"
          className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-800 flex items-center justify-between"
        >
          <span className="inline-flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{actionSuccess}</span>
          </span>
          <button
            type="button"
            onClick={() => setActionSuccess('')}
            className="text-emerald-700 hover:text-emerald-900 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {actionError && (
        <div
          role="alert"
          className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800 flex items-center justify-between"
        >
          <span>{actionError}</span>
          <button
            type="button"
            onClick={() => setActionError('')}
            className="text-red-700 hover:text-red-900 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* TAB 1: ORDERS */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 self-start">
              {(['الكل', ...ORDER_STATUSES] as const).map((status) => (
                <button
                  key={status}
                  type="button"
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    statusFilter === status
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                placeholder="بحث برقم الطلب، الاسم، أو الهاتف..."
                className="w-full ps-9 pe-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
              />
            </div>
          </div>

          {loadingOrders ? (
            <div className="h-48 rounded-xl bg-white border border-slate-200 animate-pulse" />
          ) : filteredOrders.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-sm text-slate-600">
              لا توجد طلبات مطابقة للتصفية الحالية.
            </div>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map((order) => (
                <article
                  key={order.id}
                  className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
                    <div>
                      <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 mb-1">
                        <span className="font-mono-nums font-bold text-slate-900 text-sm">
                          {order.orderNumber}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{orderTypeLabel(order.orderType)}</span>
                        <span aria-hidden="true">·</span>
                        <span>{order.clientSegment}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{formatArabicDate(order.createdAt)}</span>
                      </div>
                      <h3 className="font-display text-lg font-bold text-slate-900">
                        {order.customerName}
                      </h3>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center gap-2">
                        <label
                          htmlFor={`order-status-${order.id}`}
                          className="text-xs font-semibold text-slate-600 whitespace-nowrap"
                        >
                          حالة الطلب:
                        </label>
                        {hasPerm('update_order_status') ? (
                          <select
                            id={`order-status-${order.id}`}
                            aria-label={`حالة الطلب ${order.orderNumber}`}
                            value={order.status}
                            onChange={(e) =>
                              handleStatusChange(order.id, e.target.value as OrderStatus)
                            }
                            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border cursor-pointer focus:outline-none ${statusStyle(
                              order.status
                            )}`}
                          >
                            {ORDER_STATUSES.map((st) => (
                              <option key={st} value={st} className="bg-white text-slate-900">
                                {st}
                              </option>
                            ))}
                          </select>
                        ) : (
                          <span
                            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border ${statusStyle(
                              order.status
                            )}`}
                          >
                            {order.status}
                          </span>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => setInvoiceOrder(order)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>فاتورة PDF / طباعة</span>
                      </button>

                      {hasPerm('delete_orders') && (
                        <button
                          type="button"
                          onClick={() => handleDeleteOrder(order.id)}
                          aria-label={`حذف الطلب ${order.orderNumber}`}
                          className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="block text-xs text-slate-500 mb-1">بيانات التواصل</span>
                      <div className="flex flex-wrap items-center gap-2">
                        <a
                          href={buildWhatsAppUrl(order.phone, buildOrderWhatsAppMessage(order))}
                          target="_blank"
                          rel="noopener noreferrer"
                          title="مراسلة العميل عبر واتساب"
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md transition-colors"
                        >
                          <SocialBrandIcon platform="whatsapp" className="w-3.5 h-3.5 text-emerald-700" />
                          <span dir="ltr" className="font-mono-nums">
                            {order.phone}
                          </span>
                          <span>· واتساب</span>
                        </a>
                        <a
                          href={`tel:${order.phone}`}
                          aria-label={`اتصال هاتفي بالرقم ${order.phone}`}
                          title="اتصال هاتفي"
                          className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-md transition-colors"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </a>
                      </div>
                      <div className="text-slate-600 text-xs mt-1.5 leading-relaxed">
                        {order.address}
                      </div>
                    </div>

                    <div>
                      <span className="block text-xs text-slate-500 mb-0.5">
                        تفاصيل الصيانة والموعد
                      </span>
                      {order.serviceTitle ? (
                        <>
                          {order.serviceTitles && order.serviceTitles.length > 1 ? (
                            <ul className="space-y-0.5 font-semibold text-slate-900">
                              {order.serviceTitles.map((srvTitle, idx) => (
                                <li key={idx}>· {srvTitle}</li>
                              ))}
                            </ul>
                          ) : (
                            <div className="font-semibold text-slate-900">
                              {order.serviceTitle}
                            </div>
                          )}
                          <div className="text-xs text-slate-600 mt-1">
                            الجهاز: {order.deviceType || 'غير محدد'}
                          </div>
                          {order.preferredDate && (
                            <div className="text-xs text-slate-600 mt-0.5 tabular-nums">
                              الموعد: {order.preferredDate} · {order.preferredTimeSlot}
                            </div>
                          )}
                          {order.problemDescription && (
                            <p className="text-xs text-slate-700 mt-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                              {order.problemDescription}
                            </p>
                          )}
                        </>
                      ) : (
                        <div className="text-xs text-slate-500">
                          طلب توصيل إكسسوارات متجر فقط
                        </div>
                      )}
                    </div>

                    <div className="flex flex-col justify-between">
                      <div>
                        <span className="block text-xs text-slate-500 mb-1">
                          المنتجات المرفقة والإجمالي
                        </span>
                        {order.items.length > 0 ? (
                          <ul className="space-y-1 text-xs text-slate-700 mb-2">
                            {order.items.map((line) => (
                              <li key={line.productId} className="tabular-nums">
                                {line.productName} × {line.quantity} (
                                {formatEGP(line.unitPrice * line.quantity)})
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <span className="text-xs text-slate-500 block mb-2">
                            لا توجد إكسسوارات مرفقة
                          </span>
                        )}
                      </div>
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-xs text-slate-500">الإجمالي المقدر</span>
                        <span className="font-display text-base font-bold text-slate-900 tabular-nums">
                          {formatEGP(order.estimatedTotal)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Technician Note & Worker Tracking */}
                  <div className="pt-3 border-t border-slate-100 space-y-2.5">
                    {hasPerm('update_order_status') ? (
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
                        <label
                          htmlFor={`order-note-${order.id}`}
                          className="text-xs font-semibold text-slate-600 whitespace-nowrap"
                        >
                          ملاحظات تظهر للعميل:
                        </label>
                        <input
                          id={`order-note-${order.id}`}
                          type="text"
                          value={
                            noteDrafts[order.id] !== undefined
                              ? noteDrafts[order.id]
                              : order.technicianNotes || ''
                          }
                          onChange={(e) =>
                            setNoteDrafts((prev) => ({ ...prev, [order.id]: e.target.value }))
                          }
                          placeholder="مثال: جاري فحص دائرة الشحن وسيتم التواصل فور الانتهاء..."
                          className="flex-1 px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white focus:border-blue-700"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveTechnicianNote(order.id)}
                          className="px-3.5 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto cursor-pointer"
                        >
                          حفظ الملاحظة
                        </button>
                      </div>
                    ) : (
                      order.technicianNotes && (
                        <div className="text-xs text-slate-600">
                          <span className="font-semibold text-slate-700">ملاحظة الصيانة: </span>
                          {order.technicianNotes}
                        </div>
                      )
                    )}

                    {order.lastUpdatedBy && (
                      <div className="text-[11px] text-slate-500">
                        آخر تحديث بواسطة:{' '}
                        <span className="font-semibold text-slate-700">{order.lastUpdatedBy}</span>
                      </div>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SERVICES MANAGEMENT */}
      {activeTab === 'services' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-slate-900">
              قائمة خدمات الصيانة والأسعار المبدئية
            </h2>
            <button
              type="button"
              onClick={openCreateService}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة خدمة صيانة</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-start border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4 text-start">الخدمة</th>
                    <th className="py-3 px-4 text-start">التصنيف</th>
                    <th className="py-3 px-4 text-start">المدة المتوقعة</th>
                    <th className="py-3 px-4 text-start">السعر المبدئي</th>
                    <th className="py-3 px-4 text-end">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {services.map((srv) => (
                    <tr key={srv.id} className="hover:bg-slate-50/70">
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{srv.title}</div>
                        <div className="text-xs text-slate-500 mt-0.5 line-clamp-1 max-w-md">
                          {srv.description}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                        {srv.category}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap tabular-nums">
                        {srv.estimatedDuration}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-900 whitespace-nowrap tabular-nums">
                        {formatEGP(srv.startingPrice)}
                      </td>
                      <td className="py-3.5 px-4 text-end whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => openEditService(srv)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-blue-700 bg-slate-100 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>تعديل</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteService(srv.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 bg-red-50/40 rounded-md transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>حذف</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PRODUCTS MANAGEMENT */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-slate-900">
              منتجات متجر الإكسسوارات
            </h2>
            <button
              type="button"
              onClick={openCreateProduct}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة منتج جديد</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-start border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4 text-start">المنتج</th>
                    <th className="py-3 px-4 text-start">التصنيف</th>
                    <th className="py-3 px-4 text-start">السعر</th>
                    <th className="py-3 px-4 text-start">المخزون</th>
                    <th className="py-3 px-4 text-end">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {products.map((prd) => (
                    <tr key={prd.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-9 rounded-md overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                            <ResilientImage
                              src={prd.imageUrl}
                              alt={prd.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900">{prd.name}</div>
                            <div className="text-xs text-slate-500 line-clamp-1 max-w-sm">
                              {prd.description}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                        {prd.category}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900 whitespace-nowrap tabular-nums">
                        {formatEGP(prd.price)}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap tabular-nums">
                        <span
                          className={
                            prd.stock > 0 ? 'text-emerald-700' : 'text-red-700 font-semibold'
                          }
                        >
                          {prd.stock} قطعة
                        </span>
                      </td>
                      <td className="py-3 px-4 text-end whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => openEditProduct(prd)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-blue-700 bg-slate-100 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>تعديل</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteProduct(prd.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 bg-red-50/40 rounded-md transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>حذف</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: DEVICES STORE MANAGEMENT (LAPTOPS, DESKTOP PCS, MONITORS) */}
      {activeTab === 'devices' && hasPerm('manage_devices') && (
        <DevicesManagerTab
          authToken={adminToken}
          devices={devices}
          onDevicesChange={onDevicesChange}
          onAuthError={onLogout}
          onSuccess={notifySuccess}
          onError={setActionError}
        />
      )}

      {/* TAB 5: PROMOTIONAL OFFERS MANAGEMENT */}
      {activeTab === 'offers' && hasPerm('manage_offers') && (
        <OffersManagerTab
          authToken={adminToken}
          offers={offers}
          onOffersChange={onOffersChange}
          onAuthError={onLogout}
          onSuccess={notifySuccess}
          onError={setActionError}
        />
      )}

      {/* TAB 6: HOME CONTENT, CONTACTS & SOCIAL PAGES MANAGEMENT */}
      {activeTab === 'siteSettings' && hasPerm('manage_site_settings') && (
        <SiteSettingsManagerTab
          authToken={adminToken}
          siteSettings={siteSettings}
          onSiteSettingsChange={onSiteSettingsChange}
          onAuthError={onLogout}
          onSuccess={notifySuccess}
          onError={setActionError}
        />
      )}

      {/* TAB 7: STAFF & WORKER PERMISSIONS MANAGEMENT (OWNER ONLY) */}
      {activeTab === 'staff' && isOwner && (
        <StaffManagerTab
          authToken={adminToken}
          staffUsers={staffUsers}
          orders={orders}
          onStaffChange={onStaffChange}
          onAuthError={onLogout}
          onSuccess={notifySuccess}
          onError={setActionError}
        />
      )}

      {/* Order Printable & PDF Invoice Modal */}
      {invoiceOrder && (
        <OrderInvoiceModal
          order={invoiceOrder}
          siteSettings={siteSettings}
          onClose={() => setInvoiceOrder(null)}
        />
      )}

      {/* Account Settings Modal */}
      {accountModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl border border-slate-200 w-full max-w-md p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-display text-lg font-bold text-slate-900">
                تغيير بيانات حساب الإدارة
              </h3>
              <button
                type="button"
                onClick={() => setAccountModalOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateCredentials} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  البريد الإلكتروني الجديد
                </label>
                <input
                  type="email"
                  dir="ltr"
                  required
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="w-full text-start px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  كلمة المرور الجديدة (اتركها فارغة للإبقاء على الحالية)
                </label>
                <input
                  type="password"
                  dir="ltr"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="6 أحرف على الأقل"
                  className="w-full text-start px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  كلمة المرور الحالية (مطلوبة للتأكيد)
                </label>
                <input
                  type="password"
                  dir="ltr"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full text-start px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAccountModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={savingCredentials}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                >
                  {savingCredentials ? 'جاري الحفظ...' : 'حفظ التغييرات'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Service Modal */}
      {serviceModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingService ? 'تعديل خدمة الصيانة' : 'إضافة خدمة صيانة جديدة'}
              </h3>
              <button
                type="button"
                onClick={() => setServiceModalOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveService} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  اسم الخدمة
                </label>
                <input
                  type="text"
                  required
                  value={srvTitle}
                  onChange={(e) => setSrvTitle(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    التصنيف
                  </label>
                  <select
                    value={srvCategory}
                    onChange={(e) => setSrvCategory(e.target.value as ServiceCategory)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  >
                    {SERVICE_CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    السعر المبدئي (ج.م)
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={srvPrice}
                    onChange={(e) => setSrvPrice(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono-nums border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    المدة المتوقعة
                  </label>
                  <input
                    type="text"
                    value={srvDuration}
                    onChange={(e) => setSrvDuration(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الضمان
                  </label>
                  <input
                    type="text"
                    value={srvWarranty}
                    onChange={(e) => setSrvWarranty(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  وصف الخدمة
                </label>
                <textarea
                  rows={3}
                  required
                  value={srvDesc}
                  onChange={(e) => setSrvDesc(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setServiceModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={savingService}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                >
                  {savingService ? 'جاري الحفظ...' : 'حفظ الخدمة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Product Modal with Image Upload Button */}
      {productModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 shadow-xl my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingProduct ? 'تعديل منتج المتجر' : 'إضافة منتج جديد للمتجر'}
              </h3>
              <button
                type="button"
                onClick={() => setProductModalOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  اسم المنتج
                </label>
                <input
                  type="text"
                  required
                  value={prdName}
                  onChange={(e) => setPrdName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label
                    htmlFor="product-category-input"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    الصنف
                  </label>
                  <input
                    id="product-category-input"
                    type="text"
                    required
                    list="product-category-suggestions"
                    value={prdCategory}
                    onChange={(e) => setPrdCategory(e.target.value)}
                    placeholder="اكتب الصنف (مثلاً: ماوس، شواحن، كابلات)"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                  <datalist id="product-category-suggestions">
                    {Array.from(
                      new Set([
                        ...PRODUCT_CATEGORIES,
                        ...products.map((p) => p.category).filter(Boolean),
                      ])
                    ).map((c) => (
                      <option key={c} value={c} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    السعر (ج.م)
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={prdPrice}
                    onChange={(e) => setPrdPrice(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono-nums border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    الكمية بالمخزون
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={prdStock}
                    onChange={(e) => setPrdStock(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono-nums border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                </div>
              </div>

              {/* Product Image Upload + Preview */}
              <div className="space-y-2.5 p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold text-slate-700">صورة المنتج</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    onChange={handleImageFileSelect}
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={uploadingImage}
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>
                      {uploadingImage ? 'جاري رفع الصورة...' : 'إضافة صورة المنتج'}
                    </span>
                  </button>
                </div>

                {uploadError && (
                  <p className="text-xs text-red-700">{uploadError}</p>
                )}

                <div className="flex items-center gap-3">
                  <div className="w-24 h-18 rounded-lg overflow-hidden border border-slate-200 bg-white shrink-0">
                    <ResilientImage
                      src={prdImage}
                      alt={prdName || 'معاينة صورة المنتج'}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 space-y-2">
                    <select
                      aria-label="اختيار صورة جاهزة"
                      value={
                        PRODUCT_IMAGE_PRESETS.some((p) => p.url === prdImage)
                          ? prdImage
                          : ''
                      }
                      onChange={(e) => {
                        if (e.target.value) setPrdImage(e.target.value);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                    >
                      <option value="">أو اختر من الصور الجاهزة...</option>
                      {PRODUCT_IMAGE_PRESETS.map((preset) => (
                        <option key={preset.label} value={preset.url}>
                          {preset.label}
                        </option>
                      ))}
                    </select>

                    <input
                      type="text"
                      dir="ltr"
                      value={prdImage}
                      onChange={(e) => setPrdImage(e.target.value)}
                      placeholder="رابط الصورة أو مسارها"
                      className="w-full text-start px-2.5 py-1.5 text-xs font-mono-nums bg-white border border-slate-300 rounded-md focus:outline-none focus:border-blue-700"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  وصف المنتج
                </label>
                <textarea
                  rows={3}
                  required
                  value={prdDesc}
                  onChange={(e) => setPrdDesc(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setProductModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={savingProduct || uploadingImage}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg cursor-pointer"
                >
                  {savingProduct ? 'جاري الحفظ...' : 'حفظ المنتج'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
