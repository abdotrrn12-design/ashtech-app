import { useState } from 'react';
import { Check, Plus, Search, ShoppingBag } from 'lucide-react';
import type { CartItem, ProductCategory, StoreProduct } from '../types';
import { formatEGP } from '../utils/format';
import { ResilientImage } from './ResilientImage';

interface AccessoriesStoreProps {
  products: StoreProduct[];
  loading: boolean;
  cart: CartItem[];
  onAddToCart: (product: StoreProduct) => void;
  onOpenCart: () => void;
}

export function AccessoriesStore({
  products,
  loading,
  cart,
  onAddToCart,
  onOpenCart,
}: AccessoriesStoreProps) {
  const [selectedCategory, setSelectedCategory] = useState<'الكل' | ProductCategory>('الكل');
  const [searchQuery, setSearchQuery] = useState('');
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);

  const availableCategories: Array<'الكل' | ProductCategory> = [
    'الكل',
    ...Array.from(new Set(products.map((p) => p.category).filter(Boolean))),
  ];

  const filteredProducts = products.filter((product) => {
    const matchesCategory =
      selectedCategory === 'الكل' || product.category === selectedCategory;
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !q ||
      product.name.toLowerCase().includes(q) ||
      product.description.toLowerCase().includes(q) ||
      product.category.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  const handleAdd = (product: StoreProduct) => {
    onAddToCart(product);
    setRecentlyAddedId(product.id);
    window.setTimeout(() => {
      setRecentlyAddedId((curr) => (curr === product.id ? null : curr));
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-20 space-y-8">
      {/* Store Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-200 pb-6">
        <div>
          <p className="text-xs font-semibold text-blue-700 mb-2">
            توصيل مستقل أو مع زيارة المهندس
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">
            متجر إكسسوارات الكمبيوتر واللاب توب
          </h1>
          <p className="text-sm text-slate-600 mt-2 max-w-2xl">
            ملحقات أصلية منتقاة لرفع كفاءة العمل وحماية أجهزتك. يمكنك طلبها مباشرة أو دمجها مع
            طلب الصيانة.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenCart}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-900 bg-white border border-slate-300 hover:border-slate-400 rounded-lg transition-colors self-start cursor-pointer whitespace-nowrap"
        >
          <ShoppingBag className="w-4 h-4 text-blue-700" />
          <span>عرض سلة المشتريات</span>
          <span className="font-mono-nums text-xs text-slate-600">
            ({cart.reduce((s, i) => s + i.quantity, 0)})
          </span>
        </button>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div
          role="tablist"
          aria-label="تصنيفات الإكسسوارات"
          className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 self-start"
        >
          {availableCategories.map((category) => (
            <button
              key={category}
              type="button"
              role="tab"
              aria-selected={selectedCategory === category}
              onClick={() => setSelectedCategory(category)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedCategory === category
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="relative w-full lg:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن ماوس، كيبورد، شاحن..."
            aria-label="بحث في منتجات المتجر"
            className="w-full ps-9 pe-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
          />
        </div>
      </div>

      {/* Product Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className="h-96 rounded-xl bg-white border border-slate-200 animate-pulse"
            />
          ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <p className="text-slate-600 text-sm mb-4">
            لم يتم العثور على منتجات مطابقة لبحثك.
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('الكل');
              setSearchQuery('');
            }}
            className="px-4 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
          >
            إعادة تعيين الفلاتر
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const inCartQty =
              cart.find((item) => item.product.id === product.id)?.quantity ?? 0;
            const outOfStock = product.stock <= 0;
            const justAdded = recentlyAddedId === product.id;

            return (
              <article
                key={product.id}
                className="group flex flex-col bg-white border border-slate-200 rounded-xl overflow-hidden hover:-translate-y-0.5 transition-transform duration-150"
              >
                {/* 4:3 Studio Product Image */}
                <div className="aspect-[4/3] bg-slate-100 overflow-hidden border-b border-slate-100">
                  <ResilientImage
                    src={product.imageUrl}
                    alt={product.name}
                    fallbackLabel={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Product Body */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500 mb-2">
                      <span>{product.category}</span>
                      <span
                        className={`tabular-nums ${
                          outOfStock ? 'text-red-700 font-medium' : 'text-emerald-700'
                        }`}
                      >
                        {outOfStock ? 'غير متوفر حالياً' : `متاح (${product.stock})`}
                      </span>
                    </div>

                    <h2 className="font-display text-base font-bold text-slate-900 leading-snug mb-2">
                      {product.name}
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5">
                      {product.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                    <div>
                      <span className="font-display text-lg font-bold text-slate-900 tabular-nums">
                        {formatEGP(product.price)}
                      </span>
                      {inCartQty > 0 && (
                        <span className="block text-xs text-blue-700 tabular-nums">
                          في السلة: {inCartQty}
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      disabled={outOfStock}
                      onClick={() => handleAdd(product)}
                      className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                        justAdded
                          ? 'bg-emerald-700 text-white'
                          : 'bg-blue-700 hover:bg-blue-800 text-white'
                      }`}
                    >
                      {justAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>تمت الإضافة</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>أضف للسلة</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
