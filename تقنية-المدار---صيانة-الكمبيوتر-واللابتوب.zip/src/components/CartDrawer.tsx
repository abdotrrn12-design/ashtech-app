import { useState, FormEvent } from 'react';
import { CheckCircle2, Minus, Plus, ShoppingBag, Trash2, Wrench, X } from 'lucide-react';
import type { CartItem, ClientSegment, CustomerOrder } from '../types';
import { formatEGP } from '../utils/format';
import { ResilientImage } from './ResilientImage';

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQty: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onCombineWithBooking: () => void;
  onStandaloneOrderCreated: (order: CustomerOrder) => void;
  onTrackOrder: (orderNumber: string) => void;
}

export function CartDrawer({
  open,
  onClose,
  cart,
  onUpdateQty,
  onRemoveItem,
  onCombineWithBooking,
  onStandaloneOrderCreated,
  onTrackOrder,
}: CartDrawerProps) {
  const [checkoutMode, setCheckoutMode] = useState(false);
  const [clientSegment, setClientSegment] = useState<ClientSegment>('أفراد / منازل');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [confirmedOrder, setConfirmedOrder] = useState<CustomerOrder | null>(null);

  if (!open) return null;

  const subtotal = cart.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const handleClose = () => {
    setConfirmedOrder(null);
    setCheckoutMode(false);
    setError('');
    onClose();
  };

  const handleStandaloneCheckout = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanPhone = phone.replace(/\s+/g, '');
    if (customerName.trim().length < 2) {
      setError('يرجى إدخال الاسم أو اسم الشركة.');
      return;
    }
    if (cleanPhone.length < 8) {
      setError('يرجى إدخال رقم هاتف صحيح.');
      return;
    }
    if (address.trim().length < 5) {
      setError('يرجى إدخال عنوان التوصيل بالتفصيل.');
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientSegment,
          customerName: customerName.trim(),
          phone: cleanPhone,
          address: address.trim(),
          items: cart.map((c) => ({ productId: c.product.id, quantity: c.quantity })),
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || 'تعذر تأكيد الطلب.');
        return;
      }

      setConfirmedOrder(data as CustomerOrder);
      onStandaloneOrderCreated(data as CustomerOrder);
      setCustomerName('');
      setPhone('');
      setAddress('');
      setCheckoutMode(false);
    } catch {
      setError('تعذر الاتصال بالخادم.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/50 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="سلة المشتريات"
    >
      <div className="w-full max-w-md bg-white h-full flex flex-col border-s border-slate-200 shadow-xl">
        {/* Drawer Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-700" />
            <h2 className="font-display text-lg font-bold text-slate-900">
              سلة المشتريات
            </h2>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="إغلاق السلة"
            className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {confirmedOrder ? (
            <div className="py-8 space-y-5">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-7 h-7 text-emerald-700 shrink-0" />
                <div>
                  <h3 className="font-display text-lg font-bold text-slate-900">
                    تم تأكيد طلب الإكسسوارات
                  </h3>
                  <p className="text-sm text-slate-600 mt-1">
                    رقم الطلب:{' '}
                    <span className="font-mono-nums font-bold text-slate-900">
                      {confirmedOrder.orderNumber}
                    </span>
                  </p>
                </div>
              </div>
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 text-sm space-y-2.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">العميل:</span>
                  <span className="font-semibold text-slate-900">
                    {confirmedOrder.customerName}
                  </span>
                </div>
                {confirmedOrder.items.length > 0 && (
                  <div className="pt-2 border-t border-slate-200 space-y-1 text-xs">
                    <span className="text-slate-500 block">المنتجات المختارة:</span>
                    {confirmedOrder.items.map((item) => (
                      <div key={item.productId} className="flex justify-between text-slate-800">
                        <span>
                          {item.productName} × {item.quantity}
                        </span>
                        <span className="tabular-nums font-semibold">
                          {formatEGP(item.unitPrice * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t border-slate-200">
                  <span className="text-slate-500">الإجمالي:</span>
                  <span className="font-bold text-slate-900 tabular-nums">
                    {formatEGP(confirmedOrder.estimatedTotal)}
                  </span>
                </div>
                <p className="text-xs text-slate-500 pt-2 border-t border-slate-200">
                  سيتواصل معك مندوب التوصيل لتأكيد موعد التسليم. الدفع عند الاستلام.
                </p>
              </div>
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    const ordNum = confirmedOrder.orderNumber;
                    handleClose();
                    onTrackOrder(ordNum);
                  }}
                  className="w-full py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
                >
                  متابعة حالة الطلب ({confirmedOrder.status})
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="w-full py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  متابعة التصفح
                </button>
              </div>
            </div>
          ) : cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto" strokeWidth={1.5} />
              <p className="text-sm font-medium text-slate-700">سلة المشتريات فارغة حالياً</p>
              <p className="text-xs text-slate-500">
                يمكنك إضافة الإكسسوارات من المتجر وطلبها مباشرة أو مع زيارة الصيانة.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex gap-3.5 pb-4 border-b border-slate-100"
                >
                  <div className="w-20 h-16 rounded-lg overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                    <ResilientImage
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-semibold text-slate-900 leading-snug">
                        {item.product.name}
                      </h3>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.product.id)}
                        aria-label={`إزالة ${item.product.name}`}
                        className="text-slate-400 hover:text-red-700 p-1 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="inline-flex items-center border border-slate-200 rounded-lg">
                        <button
                          type="button"
                          onClick={() => onUpdateQty(item.product.id, -1)}
                          aria-label="إنقاص الكمية"
                          className="p-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2.5 text-xs font-semibold tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQty(item.product.id, 1)}
                          aria-label="زيادة الكمية"
                          className="p-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <span className="text-sm font-bold text-slate-900 tabular-nums">
                        {formatEGP(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Standalone Store Checkout Form */}
              {checkoutMode && (
                <form
                  onSubmit={handleStandaloneCheckout}
                  className="pt-4 space-y-3 border-t border-slate-200"
                >
                  <h3 className="font-display text-sm font-bold text-slate-900">
                    بيانات التوصيل (الدفع عند الاستلام)
                  </h3>
                  <div className="flex gap-2">
                    {(['أفراد / منازل', 'شركات / مؤسسات'] as ClientSegment[]).map((seg) => (
                      <button
                        key={seg}
                        type="button"
                        onClick={() => setClientSegment(seg)}
                        className={`flex-1 py-1.5 text-xs font-semibold rounded-md border cursor-pointer ${
                          clientSegment === seg
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-600 border-slate-300'
                        }`}
                      >
                        {seg}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="الاسم بالكامل أو اسم الشركة"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                  <input
                    type="tel"
                    dir="ltr"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01012345678"
                    className="w-full text-end px-3 py-2 text-sm font-mono-nums border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="العنوان بالتفصيل"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700"
                  />
                  {error && (
                    <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg p-2.5">
                      {error}
                    </p>
                  )}
                  <div className="flex gap-2 pt-1">
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-1 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                    >
                      {submitting ? 'جاري الإرسال...' : 'تأكيد الطلب'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setCheckoutMode(false)}
                      className="px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                    >
                      رجوع
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Drawer Footer Actions */}
        {cart.length > 0 && !confirmedOrder && !checkoutMode && (
          <div className="p-6 border-t border-slate-200 bg-slate-50 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600">إجمالي المنتجات</span>
              <span className="font-display text-lg font-bold text-slate-900 tabular-nums">
                {formatEGP(subtotal)}
              </span>
            </div>

            <button
              type="button"
              onClick={() => setCheckoutMode(true)}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
            >
              طلب الإكسسوارات فقط (توصيل مستقل)
            </button>

            <button
              type="button"
              onClick={() => {
                onCombineWithBooking();
                onClose();
              }}
              className="w-full py-2.5 px-4 text-sm font-semibold text-slate-800 bg-white border border-slate-300 hover:border-slate-400 rounded-lg transition-colors inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Wrench className="w-4 h-4 text-blue-700" />
              <span>دمج المنتجات مع زيارة الصيانة</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
