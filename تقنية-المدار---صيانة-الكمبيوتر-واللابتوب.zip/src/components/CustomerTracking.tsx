import { FormEvent, useEffect, useState } from 'react';
import { CheckCircle2, Clock, PackageCheck, Search, Truck, Wrench, XCircle } from 'lucide-react';
import type { OrderStatus, TrackedOrderSummary } from '../types';
import { formatArabicDate, formatEGP } from '../utils/format';

interface CustomerTrackingProps {
  initialQuery?: string;
}

function getProgressSteps(
  orderType: TrackedOrderSummary['orderType'],
  status: OrderStatus
): Array<{ key: OrderStatus; label: string }> {
  if (orderType === 'store') {
    return [
      { key: 'قيد الانتظار', label: 'قيد الانتظار' },
      { key: 'جاري التحضير', label: 'جاري التحضير' },
      { key: 'جاري التوصيل', label: 'جاري التوصيل' },
      { key: 'تم الانتهاء', label: 'تم التوصيل' },
    ];
  }
  if (status === 'جاري التحضير' || status === 'جاري التوصيل') {
    if (orderType === 'combined') {
      return [
        { key: 'قيد الانتظار', label: 'قيد الانتظار' },
        { key: 'جاري التحضير', label: 'جاري التحضير' },
        { key: 'جاري الصيانة', label: 'جاري الصيانة' },
        { key: 'جاري التوصيل', label: 'جاري التوصيل' },
        { key: 'تم الانتهاء', label: 'تم الانتهاء' },
      ];
    }
    return [
      { key: 'قيد الانتظار', label: 'قيد الانتظار' },
      { key: 'جاري التحضير', label: 'جاري التحضير' },
      { key: 'جاري التوصيل', label: 'جاري التوصيل' },
      { key: 'تم الانتهاء', label: 'تم الانتهاء' },
    ];
  }
  return [
    { key: 'قيد الانتظار', label: 'قيد الانتظار' },
    { key: 'جاري الصيانة', label: 'جاري الصيانة' },
    { key: 'تم الانتهاء', label: 'تم الانتهاء' },
  ];
}

function statusBadgeStyle(status: OrderStatus): string {
  switch (status) {
    case 'قيد الانتظار':
      return 'text-amber-800 bg-amber-50 border-amber-200';
    case 'جاري التحضير':
      return 'text-indigo-800 bg-indigo-50 border-indigo-200';
    case 'جاري التوصيل':
      return 'text-cyan-800 bg-cyan-50 border-cyan-200';
    case 'جاري الصيانة':
      return 'text-blue-800 bg-blue-50 border-blue-200';
    case 'تم الانتهاء':
      return 'text-emerald-800 bg-emerald-50 border-emerald-200';
    case 'ملغي':
      return 'text-red-800 bg-red-50 border-red-200';
  }
}

function StatusIcon({ status }: { status: OrderStatus }) {
  switch (status) {
    case 'قيد الانتظار':
      return <Clock className="w-4 h-4 text-amber-700 shrink-0" />;
    case 'جاري التحضير':
      return <PackageCheck className="w-4 h-4 text-indigo-700 shrink-0" />;
    case 'جاري التوصيل':
      return <Truck className="w-4 h-4 text-cyan-700 shrink-0" />;
    case 'جاري الصيانة':
      return <Wrench className="w-4 h-4 text-blue-700 shrink-0" />;
    case 'تم الانتهاء':
      return <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />;
    case 'ملغي':
      return <XCircle className="w-4 h-4 text-red-700 shrink-0" />;
  }
}

export function CustomerTracking({ initialQuery = '' }: CustomerTrackingProps) {
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<TrackedOrderSummary[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const runLookup = async (searchValue: string) => {
    const clean = searchValue.trim();
    if (!clean) {
      setError('يرجى إدخال رقم الطلب (مثال: ORD-2401) أو رقم الهاتف.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const res = await fetch(`/api/orders/track?query=${encodeURIComponent(clean)}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'تعذر البحث عن الطلب.');
        return;
      }
      setResults(data as TrackedOrderSummary[]);
    } catch {
      setError('حدث خطأ في الاتصال بالخادم.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery.trim()) {
      setQuery(initialQuery);
      runLookup(initialQuery);
    }
  }, [initialQuery]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    runLookup(query);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-20 space-y-8">
      <div className="border-b border-slate-200 pb-6">
        <p className="text-xs font-semibold text-blue-700 mb-1.5">ملف العميل ومتابعة الصيانة</p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">
          متابعة حالة الطلب وصيانة الجهاز
        </h1>
        <p className="text-sm text-slate-600 mt-2">
          أدخل رقم الهاتف المسجل أو رقم الطلب للاطلاع على الحالة الحالية للجهاز وملاحظات
          مهندس الصيانة.
        </p>
      </div>

      {/* Lookup Form */}
      <form
        onSubmit={handleSubmit}
        className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row gap-3"
      >
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="أدخل رقم الهاتف (مثال: 01012345678) أو رقم الطلب (ORD-2401)"
            aria-label="رقم الهاتف أو رقم الطلب"
            className="w-full ps-10 pe-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="px-6 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {loading ? 'جاري البحث...' : 'عرض حالة الطلب'}
        </button>
      </form>

      {error && (
        <div
          role="alert"
          className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800"
        >
          {error}
        </div>
      )}

      {results !== null && results.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-2">
          <p className="text-sm font-semibold text-slate-800">
            لم يتم العثور على طلبات مطابقة لـ &quot;{query}&quot;
          </p>
          <p className="text-xs text-slate-500">
            تأكد من كتابة رقم الهاتف أو رقم الطلب بشكل صحيح كما ورد في إيصال الحجز.
          </p>
        </div>
      )}

      {results && results.length > 0 && (
        <div className="space-y-5">
          {results.map((order) => {
            const steps = getProgressSteps(order.orderType, order.status);
            const activeStepIndex = steps.findIndex((s) => s.key === order.status);

            return (
              <article
                key={order.orderNumber}
                className="bg-white border border-slate-200 rounded-xl p-6 space-y-6"
              >
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-1">
                      <span className="font-mono-nums font-bold text-slate-900 text-sm">
                        {order.orderNumber}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        تاريخ التسجيل: {formatArabicDate(order.createdAt)}
                      </span>
                    </div>
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      {order.customerName}
                    </h2>
                  </div>

                  <div
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border text-xs font-bold ${statusBadgeStyle(
                      order.status
                    )}`}
                  >
                    <StatusIcon status={order.status} />
                    <span>حالة الطلب: {order.status}</span>
                  </div>
                </div>

                {/* Step Progress Bar (for non-cancelled orders) */}
                {order.status !== 'ملغي' && (
                  <div
                    className={`grid gap-3 ${
                      steps.length === 5
                        ? 'grid-cols-2 sm:grid-cols-5'
                        : steps.length === 4
                          ? 'grid-cols-2 sm:grid-cols-4'
                          : 'grid-cols-3'
                    }`}
                  >
                    {steps.map((step, index) => {
                      const reached = activeStepIndex >= index;
                      return (
                        <div key={step.key} className="space-y-2">
                          <div
                            className={`h-2 rounded-full transition-colors ${
                              reached ? 'bg-blue-700' : 'bg-slate-200'
                            }`}
                          />
                          <div
                            className={`text-xs font-semibold ${
                              reached ? 'text-slate-900' : 'text-slate-400'
                            }`}
                          >
                            {index + 1}. {step.label}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm pt-2 border-t border-slate-100">
                  <div>
                    <span className="block text-xs text-slate-500 mb-1">
                      الخدمات المطلوبة والجهاز
                    </span>
                    {order.serviceTitles && order.serviceTitles.length > 1 ? (
                      <ul className="space-y-1 font-semibold text-slate-900 list-disc list-inside">
                        {order.serviceTitles.map((title, idx) => (
                          <li key={idx}>{title}</li>
                        ))}
                      </ul>
                    ) : (
                      <div className="font-semibold text-slate-900">
                        {order.serviceTitle ||
                          (order.items.length > 0
                            ? 'طلب شراء منتجات من المتجر'
                            : 'طلب صيانة')}
                      </div>
                    )}
                    {order.deviceType && (
                      <div className="text-xs text-slate-600 mt-1">
                        الجهاز: {order.deviceType}
                      </div>
                    )}
                    {order.preferredDate && (
                      <div className="text-xs text-slate-600 mt-0.5 tabular-nums">
                        الموعد: {order.preferredDate} · {order.preferredTimeSlot}
                      </div>
                    )}
                  </div>

                  <div>
                    <span className="block text-xs text-slate-500 mb-1">
                      الإجمالي المقدر وآخر تحديث
                    </span>
                    <div className="font-display text-base font-bold text-slate-900 tabular-nums">
                      {formatEGP(order.estimatedTotal)}
                    </div>
                    {order.statusUpdatedAt && (
                      <div className="text-xs text-slate-500 mt-0.5 tabular-nums">
                        آخر تحديث: {formatArabicDate(order.statusUpdatedAt)}
                      </div>
                    )}
                  </div>
                </div>

                {/* Selected Products / Devices in Order Status */}
                {order.items && order.items.length > 0 && (
                  <div className="pt-3 border-t border-slate-100">
                    <span className="block text-xs font-semibold text-slate-700 mb-2">
                      المنتجات والأجهزة المختارة في الطلب ({order.items.length})
                    </span>
                    <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 overflow-hidden bg-slate-50/60">
                      {order.items.map((item) => (
                        <div
                          key={item.productId}
                          className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 text-xs"
                        >
                          <div className="font-semibold text-slate-900">
                            {item.productName}
                            <span className="text-slate-500 font-normal ms-2 tabular-nums">
                              × {item.quantity}
                            </span>
                          </div>
                          <div className="font-semibold text-slate-800 tabular-nums">
                            {formatEGP(item.unitPrice * item.quantity)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {order.technicianNotes && (
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700">
                    <span className="font-semibold text-slate-900 block mb-1">
                      ملاحظات فريق الصيانة:
                    </span>
                    {order.technicianNotes}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
