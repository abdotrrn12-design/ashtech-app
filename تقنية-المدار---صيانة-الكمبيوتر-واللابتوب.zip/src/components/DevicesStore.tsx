import { useState } from 'react';
import {
  BatteryCharging,
  Check,
  Cpu,
  HardDrive,
  Laptop,
  Monitor,
  Plus,
  Search,
  ShieldCheck,
  ShoppingBag,
  Usb,
  X,
} from 'lucide-react';
import type {
  CartItem,
  ComputerDevice,
  DeviceCategory,
  DeviceCondition,
  StoreProduct,
} from '../types';
import { formatEGP } from '../utils/format';
import { ResilientImage } from './ResilientImage';

interface DevicesStoreProps {
  devices: ComputerDevice[];
  loading: boolean;
  cart: CartItem[];
  onAddToCart: (product: StoreProduct) => void;
  onOpenCart: () => void;
}

const CATEGORY_TABS: Array<'الكل' | DeviceCategory> = [
  'الكل',
  'لاب توب',
  'كمبيوتر PC',
  'شاشات كمبيوتر',
];

const CONDITION_FILTERS: Array<'الكل' | DeviceCondition> = [
  'الكل',
  'جديد',
  'استيراد بحالة الزيرو',
  'كسر زيرو',
];

function specLabelsForCategory(category: DeviceCategory) {
  if (category === 'شاشات كمبيوتر') {
    return {
      processor: 'نوع البانل والألوان',
      ram: 'معدل التحديث والاستجابة',
      storage: 'دقة العرض',
      gpu: 'السطوع والتباين',
      display: 'المقاس والحامل',
      batteryOrPower: 'استهلاك الطاقة',
      ports: 'المنافذ والمداخل',
      warranty: 'الضمان',
    };
  }
  return {
    processor: 'المعالج (CPU)',
    ram: 'الذاكرة (RAM)',
    storage: 'التخزين (SSD/HDD)',
    gpu: 'كارت الشاشة (GPU)',
    display: 'الشاشة',
    batteryOrPower: category === 'لاب توب' ? 'البطارية والشاحن' : 'الباور والتبريد',
    ports: 'المنافذ والاتصال',
    warranty: 'الضمان',
  };
}

export function DevicesStore({
  devices,
  loading,
  cart,
  onAddToCart,
  onOpenCart,
}: DevicesStoreProps) {
  const [selectedCategory, setSelectedCategory] = useState<'الكل' | DeviceCategory>('الكل');
  const [selectedCondition, setSelectedCondition] = useState<'الكل' | DeviceCondition>('الكل');
  const [searchQuery, setSearchQuery] = useState('');
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);
  const [detailDevice, setDetailDevice] = useState<ComputerDevice | null>(null);

  const filteredDevices = devices.filter((device) => {
    const matchesCategory =
      selectedCategory === 'الكل' || device.category === selectedCategory;
    const matchesCondition =
      selectedCondition === 'الكل' || device.condition === selectedCondition;
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !q ||
      device.name.toLowerCase().includes(q) ||
      device.brand.toLowerCase().includes(q) ||
      device.category.toLowerCase().includes(q) ||
      device.description.toLowerCase().includes(q) ||
      device.specs.processor.toLowerCase().includes(q) ||
      device.specs.ram.toLowerCase().includes(q) ||
      device.specs.storage.toLowerCase().includes(q) ||
      device.specs.gpu.toLowerCase().includes(q);
    return matchesCategory && matchesCondition && matchesSearch;
  });

  const handleAdd = (device: ComputerDevice) => {
    onAddToCart(device);
    setRecentlyAddedId(device.id);
    window.setTimeout(() => {
      setRecentlyAddedId((curr) => (curr === device.id ? null : curr));
    }, 1200);
  };

  const countForCategory = (cat: 'الكل' | DeviceCategory) =>
    cat === 'الكل' ? devices.length : devices.filter((d) => d.category === cat).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-20 space-y-8">
      {/* Storefront Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-200 pb-6">
        <div>
          <p className="text-xs font-semibold text-blue-700 mb-2">
            فحص هندسي شامل قبل التسليم · ضمان معتمد من ASh tech
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">
            متجر اللاب توب وأجهزة الكمبيوتر والشاشات
          </h1>
          <p className="text-sm text-slate-600 mt-2 max-w-2xl leading-relaxed">
            تصفح أجهزة اللاب توب، تجميعات الكمبيوتر المكتبية (PC)، والشاشات الاحترافية مع عرض
            المواصفات الفنية الكاملة لكل جهاز وإمكانية الطلب المباشر.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenCart}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-900 bg-white border border-slate-300 hover:border-slate-400 rounded-lg transition-colors self-start cursor-pointer whitespace-nowrap shrink-0"
        >
          <ShoppingBag className="w-4 h-4 text-blue-700 shrink-0" />
          <span>عرض سلة المشتريات</span>
          <span className="font-mono-nums text-xs text-slate-600">
            ({cart.reduce((s, i) => s + i.quantity, 0)})
          </span>
        </button>
      </div>

      {/* Category Tabs, Condition Filter & Search */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div
          role="tablist"
          aria-label="تصنيفات الأجهزة"
          className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200 self-start"
        >
          {CATEGORY_TABS.map((category) => (
            <button
              key={category}
              type="button"
              role="tab"
              aria-selected={selectedCategory === category}
              onClick={() => setSelectedCategory(category)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedCategory === category
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {category} ({countForCategory(category)})
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
          <select
            aria-label="تصفية حسب الحالة"
            value={selectedCondition}
            onChange={(e) => setSelectedCondition(e.target.value as 'الكل' | DeviceCondition)}
            className="px-3 py-2 text-xs font-semibold bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 cursor-pointer"
          >
            {CONDITION_FILTERS.map((cond) => (
              <option key={cond} value={cond}>
                الحالة: {cond}
              </option>
            ))}
          </select>

          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالموديل، المعالج، كارت الشاشة..."
              aria-label="بحث في متجر الأجهزة"
              className="w-full ps-9 pe-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-700/15"
            />
          </div>
        </div>
      </div>

      {/* Devices Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="h-[520px] rounded-xl bg-white border border-slate-200 animate-pulse"
            />
          ))}
        </div>
      ) : filteredDevices.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <Laptop className="w-8 h-8 text-slate-400 mx-auto mb-3" />
          <p className="text-slate-600 text-sm mb-4">
            لم يتم العثور على أجهزة مطابقة لبحثك أو التصنيف المحدد.
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('الكل');
              setSelectedCondition('الكل');
              setSearchQuery('');
            }}
            className="px-4 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
          >
            إعادة تعيين الفلاتر
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDevices.map((device) => {
            const labels = specLabelsForCategory(device.category);
            const inCartQty =
              cart.find((item) => item.product.id === device.id)?.quantity ?? 0;
            const outOfStock = device.stock <= 0;
            const justAdded = recentlyAddedId === device.id;

            const highlightSpecs = [
              { label: labels.processor, value: device.specs.processor },
              { label: labels.ram, value: device.specs.ram },
              { label: labels.storage, value: device.specs.storage },
              { label: labels.gpu, value: device.specs.gpu },
              { label: labels.display, value: device.specs.display },
              { label: labels.warranty, value: device.specs.warranty },
            ].filter((s) => s.value);

            return (
              <article
                key={device.id}
                className="group flex flex-col bg-white border border-slate-200 rounded-xl overflow-hidden hover:-translate-y-0.5 transition-transform duration-150"
              >
                {/* 4:3 Studio Device Image */}
                <button
                  type="button"
                  onClick={() => setDetailDevice(device)}
                  className="aspect-[4/3] w-full bg-slate-100 overflow-hidden border-b border-slate-100 text-start cursor-pointer block"
                >
                  <ResilientImage
                    src={device.imageUrl}
                    alt={device.name}
                    fallbackLabel={device.name}
                    className="w-full h-full object-cover"
                  />
                </button>

                {/* Body */}
                <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                  <div className="space-y-3">
                    {/* Clean unboxed metadata */}
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                      <div className="flex items-center gap-1.5 truncate">
                        <span className="font-semibold text-slate-700">{device.brand}</span>
                        <span aria-hidden="true">·</span>
                        <span>{device.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{device.condition}</span>
                      </div>
                      <span
                        className={`tabular-nums shrink-0 ${
                          outOfStock ? 'text-red-700 font-semibold' : 'text-emerald-700 font-medium'
                        }`}
                      >
                        {outOfStock ? 'نفذت الكمية' : `متاح (${device.stock})`}
                      </span>
                    </div>

                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-900 leading-snug">
                        <button
                          type="button"
                          onClick={() => setDetailDevice(device)}
                          className="text-start hover:text-blue-700 transition-colors cursor-pointer"
                        >
                          {device.name}
                        </button>
                      </h2>
                      {device.description && (
                        <p className="text-xs text-slate-600 leading-relaxed mt-1 line-clamp-2">
                          {device.description}
                        </p>
                      )}
                    </div>

                    {/* Structured Detailed Specifications List */}
                    {highlightSpecs.length > 0 && (
                      <dl className="border-t border-slate-100 pt-3 space-y-1.5 text-xs">
                        {highlightSpecs.map((spec) => (
                          <div
                            key={spec.label}
                            className="flex items-baseline justify-between gap-3 py-0.5 border-b border-slate-100/70 last:border-b-0"
                          >
                            <dt className="text-slate-500 shrink-0">{spec.label}</dt>
                            <dd className="font-medium text-slate-800 text-end break-words">
                              {spec.value}
                            </dd>
                          </div>
                        ))}
                      </dl>
                    )}
                  </div>

                  {/* Price & Actions */}
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                    <div>
                      <span className="font-display text-lg font-bold text-slate-900 tabular-nums block">
                        {formatEGP(device.price)}
                      </span>
                      {inCartQty > 0 && (
                        <span className="block text-[11px] font-medium text-blue-700 tabular-nums">
                          في السلة: {inCartQty}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setDetailDevice(device)}
                        className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        التفاصيل
                      </button>

                      <button
                        type="button"
                        disabled={outOfStock}
                        onClick={() => handleAdd(device)}
                        className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                          justAdded
                            ? 'bg-emerald-700 text-white'
                            : 'bg-blue-700 hover:bg-blue-800 text-white'
                        }`}
                      >
                        {justAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>تمت الإضافة</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>أضف للسلة</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Full Specifications Modal */}
      {detailDevice && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/55 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-label={`مواصفات ${detailDevice.name}`}
          onClick={() => setDetailDevice(null)}
        >
          <div
            className="bg-white rounded-xl border border-slate-200 w-full max-w-3xl overflow-hidden shadow-xl my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-slate-700">{detailDevice.brand}</span>
                  <span aria-hidden="true">·</span>
                  <span>{detailDevice.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{detailDevice.condition}</span>
                </div>
                <h2 className="font-display text-xl font-bold text-slate-900 mt-0.5">
                  {detailDevice.name}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setDetailDevice(null)}
                aria-label="إغلاق النافذة"
                className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[78vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                <div className="md:col-span-5 aspect-[4/3] rounded-lg overflow-hidden bg-slate-100 border border-slate-200">
                  <ResilientImage
                    src={detailDevice.imageUrl}
                    alt={detailDevice.name}
                    fallbackLabel={detailDevice.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="md:col-span-7 space-y-4">
                  <div className="flex items-baseline justify-between gap-4 border-b border-slate-100 pb-3">
                    <div>
                      <span className="text-xs text-slate-500 block">السعر</span>
                      <span className="font-display text-2xl font-bold text-slate-900 tabular-nums">
                        {formatEGP(detailDevice.price)}
                      </span>
                    </div>
                    <span
                      className={`text-xs font-semibold tabular-nums ${
                        detailDevice.stock > 0 ? 'text-emerald-700' : 'text-red-700'
                      }`}
                    >
                      {detailDevice.stock > 0
                        ? `متاح بالمخزون (${detailDevice.stock} جهاز)`
                        : 'غير متوفر حالياً'}
                    </span>
                  </div>

                  {detailDevice.description && (
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {detailDevice.description}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      disabled={detailDevice.stock <= 0}
                      onClick={() => {
                        handleAdd(detailDevice);
                        setDetailDevice(null);
                      }}
                      className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <Plus className="w-4 h-4" />
                      <span>أضف للسلة</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDetailDevice(null);
                        onOpenCart();
                      }}
                      className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <ShoppingBag className="w-4 h-4 text-blue-700" />
                      <span>عرض السلة</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Complete Spec Sheet Table */}
              <div>
                <h3 className="font-display text-sm font-bold text-slate-900 mb-3">
                  المواصفات الفنية بالتفصيل
                </h3>
                {(() => {
                  const labels = specLabelsForCategory(detailDevice.category);
                  const rows = [
                    { icon: Cpu, label: labels.processor, value: detailDevice.specs.processor },
                    { icon: Cpu, label: labels.ram, value: detailDevice.specs.ram },
                    { icon: HardDrive, label: labels.storage, value: detailDevice.specs.storage },
                    { icon: Monitor, label: labels.gpu, value: detailDevice.specs.gpu },
                    { icon: Monitor, label: labels.display, value: detailDevice.specs.display },
                    {
                      icon: BatteryCharging,
                      label: labels.batteryOrPower,
                      value: detailDevice.specs.batteryOrPower,
                    },
                    { icon: Usb, label: labels.ports, value: detailDevice.specs.ports },
                    { icon: ShieldCheck, label: labels.warranty, value: detailDevice.specs.warranty },
                  ].filter((r) => r.value);

                  return (
                    <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 overflow-hidden">
                      {rows.map((row) => {
                        const Icon = row.icon;
                        return (
                          <div
                            key={row.label}
                            className="grid grid-cols-1 sm:grid-cols-12 gap-1 sm:gap-4 px-4 py-2.5 text-sm bg-white even:bg-slate-50/50"
                          >
                            <div className="sm:col-span-4 flex items-center gap-2 text-xs font-semibold text-slate-600">
                              <Icon className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                              <span>{row.label}</span>
                            </div>
                            <div className="sm:col-span-8 text-slate-900 font-medium break-words">
                              {row.value}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
