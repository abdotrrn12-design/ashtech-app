import { useState } from 'react';
import { Menu, ShoppingBag, X } from 'lucide-react';
import { DEFAULT_LOGO_URL, resolveAssetUrl } from '../utils/format';

export type ActiveView = 'home' | 'devices' | 'store' | 'tracking' | 'admin' | 'staff';

interface NavbarProps {
  activeView: ActiveView;
  onNavigate: (view: ActiveView, sectionId?: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  logoUrl?: string;
}

export function Navbar({
  activeView,
  onNavigate,
  cartCount,
  onOpenCart,
  logoUrl,
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (view: ActiveView, sectionId?: string) => {
    setMobileMenuOpen(false);
    onNavigate(view, sectionId);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Logo & Wordmark */}
        <button
          type="button"
          onClick={() => handleNavClick('home')}
          className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity cursor-pointer"
        >
          <img
            src={resolveAssetUrl(logoUrl || DEFAULT_LOGO_URL)}
            alt="شعار ASh tech"
            className="h-11 w-auto object-contain shrink-0"
          />
          <span
            dir="ltr"
            className="font-display text-xl font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            ASh tech
          </span>
        </button>

        {/* Zone 2: Single-line Public Navigation Links */}
        <nav
          aria-label="التنقل الرئيسي"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
        >
          <button
            type="button"
            onClick={() => handleNavClick('home', 'services-section')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeView === 'home'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            خدمات الصيانة
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('home', 'booking-section')}
            className="whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:text-slate-900 transition-colors cursor-pointer"
          >
            حجز زيارة
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('devices')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeView === 'devices'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            لاب توب و PC
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('store')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeView === 'store'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            متجر الإكسسوارات
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('tracking')}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeView === 'tracking'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            متابعة الطلب
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action (Shopping Cart) + Mobile Toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenCart}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
          >
            <ShoppingBag className="w-4 h-4 shrink-0" />
            <span>السلة</span>
            <span className="tabular-nums font-mono-nums text-xs bg-blue-900/50 px-1.5 py-0.5 rounded">
              {cartCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label={mobileMenuOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            className="md:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1">
          <button
            type="button"
            onClick={() => handleNavClick('home', 'services-section')}
            className="block w-full text-start px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            خدمات الصيانة
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('home', 'booking-section')}
            className="block w-full text-start px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            حجز زيارة صيانة
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('devices')}
            className="block w-full text-start px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            متجر اللاب توب و PC والشاشات
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('store')}
            className="block w-full text-start px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            متجر الإكسسوارات
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('tracking')}
            className="block w-full text-start px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            متابعة حالة الطلب
          </button>
        </div>
      )}
    </header>
  );
}
