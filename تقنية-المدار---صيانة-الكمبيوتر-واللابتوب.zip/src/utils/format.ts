export function resolveAssetUrl(url: string): string {
  if (typeof window === 'undefined') return url;
  const embedded = (window as { __ASHTECH_IMAGES__?: Record<string, string> })
    .__ASHTECH_IMAGES__;
  return (embedded && embedded[url]) || url;
}

export function formatEGP(amount: number): string {
  return `${new Intl.NumberFormat('ar-EG').format(amount)} ج.م`;
}

export function formatArabicDate(isoString: string): string {
  try {
    return new Intl.DateTimeFormat('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(isoString));
  } catch {
    return isoString;
  }
}

export function formatWhatsAppPhone(rawPhone: string): string {
  let digits = String(rawPhone || '').replace(/[^\d]/g, '');
  if (!digits) return '';
  if (digits.startsWith('00')) {
    digits = digits.slice(2);
  }
  if (digits.startsWith('01') && digits.length === 11) {
    return `2${digits}`;
  }
  if (digits.startsWith('0') && digits.length >= 9 && digits.length <= 11) {
    return `2${digits}`;
  }
  return digits;
}

export function buildWhatsAppUrl(rawPhone: string, message?: string): string {
  const waNumber = formatWhatsAppPhone(rawPhone);
  if (!waNumber) return '#';
  const base = `https://wa.me/${waNumber}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export function buildOrderWhatsAppMessage(order: import('../types').CustomerOrder): string {
  const lines: string[] = [
    `مرحباً أ/ ${order.customerName}، معكم فريق ASh tech.`,
    `رقم الطلب / الفاتورة: ${order.orderNumber}`,
    `الحالة الحالية للطلب: ${order.status}`,
  ];
  const serviceList =
    order.serviceTitles && order.serviceTitles.length > 0
      ? order.serviceTitles
      : order.serviceTitle
        ? [order.serviceTitle]
        : [];
  if (serviceList.length > 0) {
    lines.push(`الخدمات: ${serviceList.join(' + ')}`);
  }
  if (order.items.length > 0) {
    lines.push('المنتجات:');
    for (const item of order.items) {
      lines.push(
        `- ${item.productName} (الكمية: ${item.quantity}) = ${formatEGP(item.unitPrice * item.quantity)}`
      );
    }
  }
  lines.push(`الإجمالي المقدر: ${formatEGP(order.estimatedTotal)}`);
  if (order.technicianNotes) {
    lines.push(`ملاحظات: ${order.technicianNotes}`);
  }
  lines.push('شكراً لتعاملكم مع ASh tech.');
  return lines.join('\n');
}

export const PRODUCT_IMAGE_PRESETS: Array<{ label: string; url: string }> = [
  {
    label: 'ماوس لاسلكي احترافي',
    url: '/src/assets/images/product_wireless_mouse_1794841858426.jpg',
  },
  {
    label: 'كيبورد ميكانيكي',
    url: '/src/assets/images/product_mech_keyboard_1794841858998.jpg',
  },
  {
    label: 'قاعدة تبريد ألومنيوم',
    url: '/src/assets/images/product_cooling_pad_1794841859191.jpg',
  },
  {
    label: 'شنطة لاب توب',
    url: '/src/assets/images/product_laptop_bag_1794841859872.jpg',
  },
  {
    label: 'شاحن USB-C وفلاشة معدنية',
    url: '/src/assets/images/product_usb_charger_1794841859919.jpg',
  },
];

export const DEVICE_IMAGE_PRESETS: Array<{ label: string; url: string }> = [
  {
    label: 'لاب توب احترافي (Laptop)',
    url: '/src/assets/images/device_laptop_pro_1794871559585.jpg',
  },
  {
    label: 'كمبيوتر مكتبي / محطة عمل (PC)',
    url: '/src/assets/images/device_desktop_pc_1794871560266.jpg',
  },
  {
    label: 'شاشة كمبيوتر احترافية (Monitor)',
    url: '/src/assets/images/device_pc_monitor_1794871559355.jpg',
  },
];

export const OFFER_IMAGE_PRESETS: Array<{ label: string; url: string }> = [
  {
    label: 'معمل الصيانة الهندسي',
    url: '/src/assets/images/hero_repair_lab_1794841859240.jpg',
  },
  ...DEVICE_IMAGE_PRESETS,
  ...PRODUCT_IMAGE_PRESETS,
];

export const PERMISSION_OPTIONS: Array<{
  key: import('../types').PermissionKey;
  label: string;
  description: string;
}> = [
  {
    key: 'view_orders',
    label: 'عرض ومتابعة الطلبات',
    description: 'الاطلاع على طلبات الصيانة والمتجر وتفاصيل العملاء',
  },
  {
    key: 'update_order_status',
    label: 'تحديث حالة الطلب والملاحظات',
    description: 'تغيير حالة الصيانة وإضافة ملاحظات الفني للعميل',
  },
  {
    key: 'delete_orders',
    label: 'حذف الطلبات',
    description: 'إزالة الطلبات الملغاة أو المكررة من السجل',
  },
  {
    key: 'manage_services',
    label: 'إدارة خدمات الصيانة',
    description: 'إضافة وتعديل وحذف خدمات الصيانة وأسعارها',
  },
  {
    key: 'manage_products',
    label: 'إدارة منتجات الإكسسوارات',
    description: 'إضافة وتعديل وحذف منتجات الإكسسوارات وصورها',
  },
  {
    key: 'manage_devices',
    label: 'إدارة متجر الأجهزة (لاب توب / PC / شاشات)',
    description: 'إضافة وتعديل وحذف اللاب توب وأجهزة الكمبيوتر والشاشات ومواصفاتها',
  },
  {
    key: 'manage_offers',
    label: 'إدارة العروض المتحركة',
    description: 'رفع وتعديل صور العروض والإعلانات في الصفحة الرئيسية',
  },
  {
    key: 'manage_site_settings',
    label: 'إدارة نصوص الرئيسية والتواصل والصفحات',
    description: 'تعديل نصوص وصور الصفحة الرئيسية وأرقام الهاتف وروابط صفحات التواصل الاجتماعي',
  },
];

export const DEFAULT_LOGO_URL =
  '/assets/aistudio/file_000000007d188210a1641b4a37901e51_a002371b.png';

export const DEFAULT_SITE_SETTINGS: import('../types').SiteSettings = {
  heroKicker: 'خدمات هندسية ميدانية وداخل المركز · القاهرة والجيزة',
  heroTitle: 'صيانة هندسية دقيقة لأجهزة الكمبيوتر واللاب توب',
  heroSubtitle:
    'نقدم حلول الصيانة الشاملة للشركات والمنازل: معالجة الحرارة وتغيير المعجون الحراري، استبدال الشاشات والبطاريات الأصلية، وتثبيت أنظمة التشغيل وحل أعطال الهاردوير بضمان موثق.',
  heroPrimaryCta: 'احجز زيارة صيانة الآن',
  heroSecondaryCta: 'تصفح متجر الإكسسوارات',
  heroImageUrl: '/src/assets/images/hero_repair_lab_1794841859240.jpg',
  logoUrl: DEFAULT_LOGO_URL,
  heroHighlights: [
    {
      title: 'خلال 24 ساعة',
      subtitle: 'وصول الفني لمقر الشركة أو المنزل',
    },
    {
      title: 'ضمان حتى 6 أشهر',
      subtitle: 'على قطع الغيار وأعمال الصيانة',
    },
    {
      title: '+1,400 جهاز سنوياً',
      subtitle: 'صيانة دورية للشركات والمستخدمين',
    },
    {
      title: 'أسعار شفافة بالجنيه',
      subtitle: 'فحص مبدئي واضح قبل بدء الإصلاح',
    },
  ],
  servicesTitle: 'خدمات الصيانة والأسعار المبدئية',
  servicesSubtitle:
    'اختر الخدمة المناسبة لعطل جهازك لحجز موعد زيارة فوري. الأسعار تشمل الفحص والتنفيذ بالجنيه المصري.',
  bookingKicker: 'طلب زيارة مهندس صيانة',
  bookingTitle: 'نموذج حجز زيارة صيانة',
  bookingSubtitle:
    'سجل بياناتك والموعد المناسب وسيتواصل معك فريق الدعم الفني لتأكيد الزيارة وإرسال المهندس المختص إلى مقر شركتك أو منزلك.',
  bookingFeature1Title: 'فحص وتشخيص دقيق',
  bookingFeature1Desc: 'يتم إبلاغك بالتكلفة النهائية قبل استبدال أي قطعة غيار.',
  bookingFeature2Title: 'التزام تام بالمواعيد',
  bookingFeature2Desc: 'مواعيد مرنة للأفراد وعقود استجابة سريعة للشركات.',
  bookingDirectPhoneTitle: 'تواصل مباشر مع الشركة',
  footerDescription: 'صيانة الكمبيوتر واللاب توب وحلول البنية التحتية التقنية للشركات والمنازل',
  contactPhones: [
    {
      id: 'ph-main',
      label: 'خدمة العملاء',
      number: '01009116199',
    },
  ],
  socialLinks: [],
};

export const SOCIAL_PLATFORM_OPTIONS: Array<{
  value: import('../types').SocialPlatform;
  label: string;
  placeholder: string;
}> = [
  { value: 'facebook', label: 'فيسبوك (Facebook)', placeholder: 'https://facebook.com/ashtech' },
  { value: 'youtube', label: 'يوتيوب (YouTube)', placeholder: 'https://youtube.com/@ashtech' },
  { value: 'instagram', label: 'إنستجرام (Instagram)', placeholder: 'https://instagram.com/ashtech' },
  { value: 'tiktok', label: 'تيك توك (TikTok)', placeholder: 'https://tiktok.com/@ashtech' },
  { value: 'whatsapp', label: 'واتساب (WhatsApp)', placeholder: 'https://wa.me/201009116199' },
  { value: 'x', label: 'إكس / تويتر (X)', placeholder: 'https://x.com/ashtech' },
  { value: 'linkedin', label: 'لينكدإن (LinkedIn)', placeholder: 'https://linkedin.com/company/ashtech' },
];

