import type {
  AuthUser,
  ComputerDevice,
  ContactPhoneItem,
  CustomerOrder,
  DeviceCategory,
  DeviceCondition,
  DeviceSpecs,
  HeroHighlightItem,
  MaintenanceService,
  OfferLinkTarget,
  OrderCartLine,
  OrderStatus,
  PermissionKey,
  PromotionalOffer,
  SiteSettings,
  SocialPageLink,
  SocialPlatform,
  StaffUser,
  StoreProduct,
  TrackedOrderSummary,
  UserRole,
} from '../types';
import { DEFAULT_SITE_SETTINGS } from './format';

declare global {
  interface Window {
    __ASHTECH_STANDALONE__?: boolean;
  }
}

interface StandaloneAdminAccount {
  email: string;
  passwordSha256: string;
  recoveryCodeSha256?: string;
  recoveryExpiresAt?: string;
}

interface StandaloneStaffUser extends StaffUser {
  passwordSha256: string;
}

interface StandaloneSession {
  token: string;
  userId: string;
  role: UserRole;
  email: string;
  createdAt: string;
}

interface StandaloneDatabase {
  services: MaintenanceService[];
  products: StoreProduct[];
  devices: ComputerDevice[];
  orders: CustomerOrder[];
  offers: PromotionalOffer[];
  staffUsers: StandaloneStaffUser[];
  siteSettings: SiteSettings;
  admin: StandaloneAdminAccount;
  sessions: StandaloneSession[];
}

const STORAGE_KEY = 'ashtech_standalone_db_v1';

const ALL_PERMISSIONS: PermissionKey[] = [
  'view_orders',
  'update_order_status',
  'delete_orders',
  'manage_services',
  'manage_products',
  'manage_devices',
  'manage_offers',
  'manage_site_settings',
];

function sha256Hex(message: string): string {
  const utf8 = unescape(encodeURIComponent(message));
  const words: number[] = [];
  for (let i = 0; i < utf8.length; i++) {
    words[i >> 2] |= (utf8.charCodeAt(i) & 0xff) << (24 - (i % 4) * 8);
  }
  const bitLen = utf8.length * 8;
  words[bitLen >> 5] |= 0x80 << (24 - (bitLen % 32));
  words[(((bitLen + 64) >> 9) << 4) + 15] = bitLen;

  const K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ];
  const H = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ];
  const W = new Array<number>(64);
  const rotr = (n: number, x: number) => (x >>> n) | (x << (32 - n));

  for (let i = 0; i < words.length; i += 16) {
    let [a, b, c, d, e, f, g, h] = H;
    for (let t = 0; t < 64; t++) {
      if (t < 16) {
        W[t] = words[i + t] | 0;
      } else {
        const s0 = rotr(7, W[t - 15]) ^ rotr(18, W[t - 15]) ^ (W[t - 15] >>> 3);
        const s1 = rotr(17, W[t - 2]) ^ rotr(19, W[t - 2]) ^ (W[t - 2] >>> 10);
        W[t] = (W[t - 16] + s0 + W[t - 7] + s1) | 0;
      }
      const S1 = rotr(6, e) ^ rotr(11, e) ^ rotr(25, e);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[t] + W[t]) | 0;
      const S0 = rotr(2, a) ^ rotr(13, a) ^ rotr(22, a);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) | 0;
      h = g;
      g = f;
      f = e;
      e = (d + temp1) | 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) | 0;
    }
    H[0] = (H[0] + a) | 0;
    H[1] = (H[1] + b) | 0;
    H[2] = (H[2] + c) | 0;
    H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0;
    H[5] = (H[5] + f) | 0;
    H[6] = (H[6] + g) | 0;
    H[7] = (H[7] + h) | 0;
  }

  return H.map((v) => (v >>> 0).toString(16).padStart(8, '0')).join('');
}

const INITIAL_DB: StandaloneDatabase = {
  services: [
    {
      id: 'srv-thermal',
      title: 'تنظيف شامل وتغيير المعجون الحراري (Thermal Paste)',
      category: 'تبريد وتنظيف',
      startingPrice: 350,
      estimatedDuration: '60 - 90 دقيقة',
      warranty: 'ضمان 3 أشهر على كفاءة التبريد',
      description:
        'تفكيك كامل لنظام التبريد، إزالة الأتربة من المراوح والمشتت الحراري، وتطبيق معجون حراري عالي الكفاءة لخفض الحرارة ومنع التهنيج.',
    },
    {
      id: 'srv-parts',
      title: 'تغيير كيبورد أو بطارية أو شاشة اللاب توب',
      category: 'هاردوير',
      startingPrice: 650,
      estimatedDuration: 'ساعة واحدة',
      warranty: 'ضمان 6 أشهر على القطعة والتركيب',
      description:
        'توفير وتركيب قطع غيار أصلية مطابقة لمواصفات المصنع لجميع الماركات (Dell, HP, Lenovo, Asus, Apple) مع فحص الجهد والبطارية.',
    },
    {
      id: 'srv-windows',
      title: 'تنزيل وتثبيت ويندوز أصلي مع البرامج الأساسية والأوفيس',
      category: 'سوفت وير',
      startingPrice: 250,
      estimatedDuration: '45 - 60 دقيقة',
      warranty: 'دعم فني 30 يوماً',
      description:
        'تثبيت أحدث إصدار مستقر من Windows 10 أو Windows 11 مع تعريفات الجهاز الرسمية، حزمة Microsoft Office، وبرامج الحماية والعمل.',
    },
    {
      id: 'srv-software',
      title: 'حل مشاكل السوفت وير وإزالة الفيروسات وعلاج البطء',
      category: 'سوفت وير',
      startingPrice: 200,
      estimatedDuration: '45 دقيقة',
      warranty: 'ضمان استقرار النظام 30 يوماً',
      description:
        'فحص شامل للنظام، إزالة البرمجيات الخبيثة دون فقدان الملفات المهمة، تحسين إقلاع النظام، وإصلاح أخطاء الشاشة الزرقاء.',
    },
    {
      id: 'srv-hardware',
      title: 'تشخيص وحل أعطال الهاردوير والماذربورد',
      category: 'هاردوير',
      startingPrice: 400,
      estimatedDuration: '24 - 48 ساعة',
      warranty: 'ضمان 3 أشهر على الإصلاح',
      description:
        'فحص دوائر الطاقة واللوحة الأم بأجهزة القياس الدقيقة، إصلاح منافذ الشحن والبيانات، وترقية الرامات وأقراص التخزين NVMe SSD.',
    },
    {
      id: 'srv-b2b',
      title: 'صيانة دورية ودعم فني لأجهزة وشبكات الشركات',
      category: 'شركات',
      startingPrice: 1200,
      estimatedDuration: 'زيارة ميدانية مجدولة',
      warranty: 'اتفاقية مستوى خدمة SLA',
      description:
        'باقة زيارات ميدانية لمقار الشركات والمكاتب تشمل فحص محطات العمل، صيانة الطابعات والشبكة الداخلية، والنسخ الاحتياطي.',
    },
  ],
  products: [
    {
      id: 'prd-mouse',
      name: 'ماوس لاسلكي احترافي مريح لليد',
      category: 'ماوس وكيبورد',
      price: 480,
      stock: 18,
      description:
        'دقة استشعار قابلة للتعديل حتى 3200 DPI، نقرات صامتة للعمل المكتبي، واتصال مزدوج بلوتوث وناقل USB لاسلكي.',
      imageUrl: '/src/assets/images/product_wireless_mouse_1794841858426.jpg',
    },
    {
      id: 'prd-keyboard',
      name: 'كيبورد ميكانيكي مدمج بهيكل ألومنيوم',
      category: 'ماوس وكيبورد',
      price: 1450,
      stock: 9,
      description:
        'مفاتيح ميكانيكية خطية هادئة مناسبة للبرمجة والعمل الطويل، هيكل متين باللون الرمادي الداكن مع كابل USB-C قابل للفصل.',
      imageUrl: '/src/assets/images/product_mech_keyboard_1794841858998.jpg',
    },
    {
      id: 'prd-cooling',
      name: 'قاعدة تبريد لاب توب ألومنيوم بمروحتين',
      category: 'قواعد تبريد',
      price: 620,
      stock: 14,
      description:
        'تصميم من الألومنيوم المصقول مع شبكة تهوية عالية التدفق ومروحتين صامتتين، وزوايا ارتفاع مريحة للرقبة.',
      imageUrl: '/src/assets/images/product_cooling_pad_1794841859191.jpg',
    },
    {
      id: 'prd-bag',
      name: 'شنطة لاب توب احترافية مضادة للماء (15.6 بوصة)',
      category: 'شنط لاب توب',
      price: 890,
      stock: 12,
      description:
        'مبطنة بطبقة حماية ثلاثية ضد الصدمات والأمطار، مع جيوب منظمة للشاحن والماوس والمستندات الرسمية.',
      imageUrl: '/src/assets/images/product_laptop_bag_1794841859872.jpg',
    },
    {
      id: 'prd-charger',
      name: 'شاحن لاب توب سريع 65W USB-C بتقنية GaN',
      category: 'شواحن',
      price: 780,
      stock: 15,
      description:
        'شاحن أصلي صغير الحجم مع حماية من تذبذب التيار وكابل مضفر عالي التحمل، متوافق مع أجهزة اللاب توب الحديثة.',
      imageUrl: '/src/assets/images/product_usb_charger_1794841859919.jpg',
    },
    {
      id: 'prd-flash',
      name: 'فلاشة معدنية فائقة السرعة 64 جيجابايت USB 3.2',
      category: 'فلاشات وتخزين',
      price: 320,
      stock: 32,
      description:
        'جسم معدني مقاوم للصدمات والحرارة مع منفذ USB-C / USB-A بسرعة نقل تصل إلى 150 ميجابايت في الثانية.',
      imageUrl: '/src/assets/images/product_usb_charger_1794841859919.jpg',
    },
  ],
  devices: [
    {
      id: 'dev-laptop-1',
      name: 'Dell Precision 5560 Workstation',
      brand: 'Dell',
      category: 'لاب توب',
      condition: 'استيراد بحالة الزيرو',
      price: 34500,
      stock: 4,
      imageUrl: '/src/assets/images/device_laptop_pro_1794871559585.jpg',
      description:
        'لاب توب محطة عمل احترافي بهيكل ألومنيوم نحيف، مخصص لأعمال الهندسة والمونتاج والتصميم ثلاثي الأبعاد.',
      specs: {
        processor: 'Intel Core i7-11850H (8 Cores, up to 4.8GHz)',
        ram: '32GB DDR4 3200MHz',
        storage: '1TB NVMe M.2 SSD Gen4',
        gpu: 'NVIDIA RTX A2000 4GB GDDR6',
        display: '15.6" FHD+ InfinityEdge Anti-Glare 500nits',
        batteryOrPower: 'بطارية 86Wh أصلية بحالة ممتازة + شاحن Type-C 130W',
        ports: '3x Thunderbolt 4 USB-C · قارئ SD Card · منفذ صوت',
        warranty: 'ضمان 6 أشهر شامل الفحص والاستبدال',
      },
    },
    {
      id: 'dev-laptop-2',
      name: 'Lenovo ThinkPad T14 Gen 2 Business',
      brand: 'Lenovo',
      category: 'لاب توب',
      condition: 'استيراد بحالة الزيرو',
      price: 19800,
      stock: 6,
      imageUrl: '/src/assets/images/device_laptop_pro_1794871559585.jpg',
      description:
        'لاب توب أعمال عملي واعتمادي فائق المتانة ومثالي للبرمجة والشركات والعمل اليومي المكثف.',
      specs: {
        processor: 'Intel Core i5-1145G7 (11th Gen vPro)',
        ram: '16GB DDR4 3200MHz',
        storage: '512GB NVMe PCIe SSD',
        gpu: 'Intel Iris Xe Graphics',
        display: '14.0" FHD IPS Matte 300nits',
        batteryOrPower: 'بطارية 50Wh حتى 8 ساعات عمل + شاحن 65W أصلي',
        ports: '2x Thunderbolt 4 · 2x USB-A 3.2 · HDMI 2.0 · RJ-45 LAN',
        warranty: 'ضمان 6 أشهر شامل الصيانة',
      },
    },
    {
      id: 'dev-pc-1',
      name: 'تجميعة ASh Workstation & Gaming Pro',
      brand: 'ASh Custom',
      category: 'كمبيوتر PC',
      condition: 'جديد',
      price: 38900,
      stock: 3,
      imageUrl: '/src/assets/images/device_desktop_pc_1794871560266.jpg',
      description:
        'جهاز كمبيوتر مكتبي متكامل مبني بأحدث معمارية مع تبريد احترافي هوائي للألعاب الثقيلة وأعمال الريندر.',
      specs: {
        processor: 'AMD Ryzen 7 7700X (8 Cores / 16 Threads)',
        ram: '32GB DDR5 5600MHz Dual Channel',
        storage: '1TB NVMe PCIe 4.0 SSD',
        gpu: 'NVIDIA GeForce RTX 4060 8GB GDDR6',
        display: 'يدعم حتى 4 شاشات بدقة 4K',
        batteryOrPower: 'باور سبلاي 750W 80+ Bronze أصلي + كيس احترافي بتهوية عالية',
        ports: 'USB-C 3.2 · 6x USB-A · HDMI 2.1 · 3x DisplayPort · LAN',
        warranty: 'ضمان سنة كاملة على المكونات والتجميع',
      },
    },
    {
      id: 'dev-mon-1',
      name: 'شاشة Dell UltraSharp U2722D احترافية',
      brand: 'Dell',
      category: 'شاشات كمبيوتر',
      condition: 'كسر زيرو',
      price: 13200,
      stock: 5,
      imageUrl: '/src/assets/images/device_pc_monitor_1794871559355.jpg',
      description:
        'شاشة 27 بوصة بدقة 2K وألوان معايرة احترافياً للمصممين والمبرمجين مع حامل هيدروليك متعدد الزوايا.',
      specs: {
        processor: 'لوحة IPS 27 بوصة ألوان دقيقة 100% sRGB / 95% DCI-P3',
        ram: 'معدل تحديث 60Hz · زمن استجابة 5ms',
        storage: 'دقة العرض: QHD (2560 × 1440)',
        gpu: 'سطوع 350 cd/m² · تباين 1000:1 مضاد للانعكاس',
        display: '27" QHD IPS بدون حواف + حامل دوار ومرتفع',
        batteryOrPower: 'استهلاك اقتصادي 25W مع كابل باور أصلي',
        ports: 'HDMI 1.4 · DisplayPort 1.4 In/Out · 4x USB 3.2 Hub',
        warranty: 'ضمان 6 أشهر على البانل والإضاءة',
      },
    },
  ],
  orders: [
    {
      id: 'ord-seed-1',
      orderNumber: 'ORD-2401',
      orderType: 'combined',
      status: 'قيد الانتظار',
      statusUpdatedAt: '2026-11-16T09:15:00.000Z',
      technicianNotes: 'تم استلام الطلب وجاري جدولة زيارة المهندس لمقر الشركة.',
      clientSegment: 'شركات / مؤسسات',
      customerName: 'شركة النيل للاستشارات الهندسية',
      phone: '01012345678',
      address: 'المعادي، شارع 9، مبنى 42، الدور الثالث، القاهرة',
      deviceType: 'لاب توب (3 أجهزة عمل)',
      serviceId: 'srv-thermal',
      serviceTitle: 'تنظيف شامل وتغيير المعجون الحراري (Thermal Paste)',
      serviceStartingPrice: 350,
      problemDescription:
        'ارتفاع ملحوظ في درجة حرارة أجهزة التصميم الهندسي وصوت مرتفع للمراوح أثناء العمل.',
      preferredDate: '2026-11-18',
      preferredTimeSlot: 'صباحاً (10:00 ص - 2:00 م)',
      items: [
        {
          productId: 'prd-cooling',
          productName: 'قاعدة تبريد لاب توب ألومنيوم بمروحتين',
          unitPrice: 620,
          quantity: 2,
        },
      ],
      productsTotal: 1240,
      estimatedTotal: 1590,
      createdAt: '2026-11-16T09:15:00.000Z',
    },
    {
      id: 'ord-seed-2',
      orderNumber: 'ORD-2402',
      orderType: 'maintenance',
      status: 'جاري الصيانة',
      statusUpdatedAt: '2026-11-16T10:00:00.000Z',
      technicianNotes: 'الفني يعمل حالياً على استبدال لوحة المفاتيح واختبار الأزرار.',
      clientSegment: 'أفراد / منازل',
      customerName: 'أحمد محمود عبد الرحمن',
      phone: '01198765432',
      address: 'مدينة نصر، شارع عباس العقاد، عمارة 18، شقة 6',
      deviceType: 'لاب توب Lenovo IdeaPad',
      serviceId: 'srv-parts',
      serviceTitle: 'تغيير كيبورد أو بطارية أو شاشة اللاب توب',
      serviceStartingPrice: 650,
      problemDescription: 'بعض أزرار الكيبورد لا تستجيب وتحتاج لاستبدال كامل.',
      preferredDate: '2026-11-17',
      preferredTimeSlot: 'عصراً (2:00 م - 6:00 م)',
      items: [],
      productsTotal: 0,
      estimatedTotal: 650,
      createdAt: '2026-11-15T14:30:00.000Z',
    },
  ],
  offers: [
    {
      id: 'ofr-seed-thermal',
      title: 'عرض التبريد الشامل للأجهزة والشركات',
      subtitle: 'فحص حراري وتنظيف كامل مع تغيير المعجون الحراري بأعلى جودة وبضمان 3 أشهر.',
      imageUrl: '/src/assets/images/hero_repair_lab_1794841859240.jpg',
      linkTarget: 'booking',
      active: true,
      createdAt: '2026-11-16T08:00:00.000Z',
    },
    {
      id: 'ofr-seed-accessories',
      title: 'تشكيلة إكسسوارات العمل والشواحن السريعة GaN',
      subtitle: 'اطلب الماوس والكيبورد وقواعد التبريد الألومنيوم الآن مع التوصيل أو مع زيارة المهندس.',
      imageUrl: '/src/assets/images/product_cooling_pad_1794841859191.jpg',
      linkTarget: 'store',
      active: true,
      createdAt: '2026-11-16T08:05:00.000Z',
    },
  ],
  staffUsers: [],
  siteSettings: JSON.parse(JSON.stringify(DEFAULT_SITE_SETTINGS)) as SiteSettings,
  admin: {
    email: 'abdotrrn12@gmail.com',
    passwordSha256: '9f719ff1d6e1452928ec8d1120115201ca604b548af49cd2030e504ee0c347b6',
  },
  sessions: [],
};

function cloneInitialDb(): StandaloneDatabase {
  return JSON.parse(JSON.stringify(INITIAL_DB)) as StandaloneDatabase;
}

function readLocalDb(): StandaloneDatabase {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const seed = cloneInitialDb();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
      return seed;
    }
    const parsed = JSON.parse(raw) as Partial<StandaloneDatabase>;
    let updated = false;
    if (!Array.isArray(parsed.devices)) {
      parsed.devices = cloneInitialDb().devices;
      updated = true;
    }
    if (!parsed.siteSettings || typeof parsed.siteSettings !== 'object') {
      parsed.siteSettings = JSON.parse(JSON.stringify(DEFAULT_SITE_SETTINGS)) as SiteSettings;
      updated = true;
    } else {
      parsed.siteSettings = {
        ...DEFAULT_SITE_SETTINGS,
        ...parsed.siteSettings,
        heroHighlights:
          Array.isArray(parsed.siteSettings.heroHighlights) &&
          parsed.siteSettings.heroHighlights.length === 4
            ? parsed.siteSettings.heroHighlights
            : DEFAULT_SITE_SETTINGS.heroHighlights,
        contactPhones: Array.isArray(parsed.siteSettings.contactPhones)
          ? parsed.siteSettings.contactPhones
          : DEFAULT_SITE_SETTINGS.contactPhones,
        socialLinks: Array.isArray(parsed.siteSettings.socialLinks)
          ? parsed.siteSettings.socialLinks
          : DEFAULT_SITE_SETTINGS.socialLinks,
      };
    }
    if (updated) {
      writeLocalDb(parsed as StandaloneDatabase);
    }
    return parsed as StandaloneDatabase;
  } catch {
    return cloneInitialDb();
  }
}

function writeLocalDb(db: StandaloneDatabase): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    // Ignore storage quota errors
  }
}

function genId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

function genToken(): string {
  return `st_${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}${Math.random()
    .toString(36)
    .slice(2)}`;
}

function jsonResp(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function sanitizeStaff(s: StandaloneStaffUser): StaffUser {
  const { passwordSha256: _ignored, ...rest } = s;
  return rest;
}

function resolveUser(db: StandaloneDatabase, token: string | null): AuthUser | null {
  if (!token) return null;
  const sess = db.sessions.find((s) => s.token === token);
  if (!sess) return null;
  if (sess.role === 'owner') {
    return {
      id: 'owner',
      role: 'owner',
      name: 'صاحب الشركة (الإدارة)',
      identifier: db.admin.email,
      permissions: ALL_PERMISSIONS,
    };
  }
  const staff = db.staffUsers.find((u) => u.id === sess.userId);
  if (!staff || !staff.active) return null;
  return {
    id: staff.id,
    role: 'staff',
    name: staff.name,
    identifier: staff.username,
    roleTitle: staff.roleTitle,
    permissions: staff.permissions,
  };
}

function hasPerm(user: AuthUser | null, ...allowed: PermissionKey[]): boolean {
  if (!user) return false;
  if (user.role === 'owner') return true;
  return allowed.some((p) => user.permissions.includes(p));
}

async function handleApiRequest(urlStr: string, init?: RequestInit): Promise<Response> {
  const method = (init?.method || 'GET').toUpperCase();
  const parsedUrl = new URL(urlStr, 'http://localhost');
  const pathname = parsedUrl.pathname;
  const headersObj = new Headers(init?.headers || {});
  const authHeader = headersObj.get('Authorization') || headersObj.get('authorization') || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;

  let body: Record<string, unknown> = {};
  if (typeof init?.body === 'string' && init.body.trim()) {
    try {
      body = JSON.parse(init.body) as Record<string, unknown>;
    } catch {
      body = {};
    }
  }

  const db = readLocalDb();
  const user = resolveUser(db, token);

  // Auth routes
  if (pathname === '/api/admin/login' && method === 'POST') {
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (email !== db.admin.email.toLowerCase() || sha256Hex(password) !== db.admin.passwordSha256) {
      return jsonResp({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' }, 401);
    }
    const newToken = genToken();
    db.sessions = [
      { token: newToken, userId: 'owner', role: 'owner', email: db.admin.email, createdAt: new Date().toISOString() },
      ...db.sessions.slice(0, 19),
    ];
    writeLocalDb(db);
    return jsonResp({
      token: newToken,
      email: db.admin.email,
      user: {
        id: 'owner',
        role: 'owner',
        name: 'صاحب الشركة (الإدارة)',
        identifier: db.admin.email,
        permissions: ALL_PERMISSIONS,
      },
    });
  }

  if (pathname === '/api/staff/login' && method === 'POST') {
    const username = String(body.username || '').trim().toLowerCase();
    const password = String(body.password || '');
    const idx = db.staffUsers.findIndex((u) => u.username.toLowerCase() === username);
    const staff = idx !== -1 ? db.staffUsers[idx] : undefined;
    if (!staff || sha256Hex(password) !== staff.passwordSha256) {
      return jsonResp({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' }, 401);
    }
    if (!staff.active) {
      return jsonResp({ error: 'تم إيقاف هذا الحساب مؤقتاً من قِبل الإدارة.' }, 403);
    }
    const nowIso = new Date().toISOString();
    db.staffUsers[idx].lastLoginAt = nowIso;
    const newToken = genToken();
    db.sessions = [
      { token: newToken, userId: staff.id, role: 'staff', email: staff.username, createdAt: nowIso },
      ...db.sessions.slice(0, 19),
    ];
    writeLocalDb(db);
    return jsonResp({
      token: newToken,
      user: {
        id: staff.id,
        role: 'staff',
        name: staff.name,
        identifier: staff.username,
        roleTitle: staff.roleTitle,
        permissions: staff.permissions,
      },
    });
  }

  if (pathname === '/api/admin/me' && method === 'GET') {
    if (!user) return jsonResp({ error: 'غير مصرح.' }, 401);
    return jsonResp({ email: user.identifier, user });
  }

  if (pathname === '/api/admin/logout' && method === 'POST') {
    if (token) {
      db.sessions = db.sessions.filter((s) => s.token !== token);
      writeLocalDb(db);
    }
    return jsonResp({ ok: true });
  }

  if (pathname === '/api/admin/credentials' && method === 'POST') {
    if (user?.role !== 'owner') return jsonResp({ error: 'غير مصرح.' }, 403);
    if (sha256Hex(String(body.currentPassword || '')) !== db.admin.passwordSha256) {
      return jsonResp({ error: 'كلمة المرور الحالية غير صحيحة.' }, 401);
    }
    const nextEmail = body.newEmail ? String(body.newEmail).trim().toLowerCase() : db.admin.email;
    db.admin.email = nextEmail;
    if (body.newPassword) {
      if (String(body.newPassword).length < 6) {
        return jsonResp({ error: 'كلمة المرور الجديدة يجب أن لا تقل عن 6 أحرف.' }, 400);
      }
      db.admin.passwordSha256 = sha256Hex(String(body.newPassword));
    }
    writeLocalDb(db);
    return jsonResp({ email: nextEmail });
  }

  if (pathname === '/api/admin/forgot-password' && method === 'POST') {
    const email = String(body.email || '').trim().toLowerCase();
    if (email === db.admin.email.toLowerCase()) {
      const code = String(Math.floor(100000 + Math.random() * 899999));
      db.admin.recoveryCodeSha256 = sha256Hex(code);
      db.admin.recoveryExpiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      writeLocalDb(db);
      return jsonResp({
        ok: true,
        message: `الوضع المحلي (HTML): رمز التحقق المؤقت الخاص بك هو ${code}`,
      });
    }
    return jsonResp({
      ok: true,
      message: 'إذا كان البريد الإلكتروني مطابقاً لحساب الإدارة، تم إنشاء رمز التحقق.',
    });
  }

  if (pathname === '/api/admin/reset-password' && method === 'POST') {
    const email = String(body.email || '').trim().toLowerCase();
    const code = String(body.code || '').trim();
    const newPassword = String(body.newPassword || '');
    if (
      email !== db.admin.email.toLowerCase() ||
      !db.admin.recoveryCodeSha256 ||
      sha256Hex(code) !== db.admin.recoveryCodeSha256 ||
      newPassword.length < 6
    ) {
      return jsonResp({ error: 'بيانات الاستعادة أو رمز التحقق غير صحيح.' }, 400);
    }
    db.admin.passwordSha256 = sha256Hex(newPassword);
    delete db.admin.recoveryCodeSha256;
    delete db.admin.recoveryExpiresAt;
    db.sessions = [];
    writeLocalDb(db);
    return jsonResp({ ok: true, message: 'تم تحديث كلمة المرور بنجاح.' });
  }

  // Upload (in standalone HTML mode, store data URL directly)
  if (pathname === '/api/upload' && method === 'POST') {
    if (!hasPerm(user, 'manage_products', 'manage_offers', 'manage_devices', 'manage_site_settings')) {
      return jsonResp({ error: 'غير مصرح.' }, 403);
    }
    const dataUrl = String(body.dataUrl || '');
    if (!dataUrl.startsWith('data:image/')) {
      return jsonResp({ error: 'صيغة الصورة غير صالحة.' }, 400);
    }
    return jsonResp({ url: dataUrl }, 201);
  }

  // Staff CRUD
  if (pathname === '/api/staff' && method === 'GET') {
    if (user?.role !== 'owner') return jsonResp({ error: 'غير مصرح.' }, 403);
    return jsonResp(db.staffUsers.map(sanitizeStaff));
  }
  if (pathname === '/api/staff' && method === 'POST') {
    if (user?.role !== 'owner') return jsonResp({ error: 'غير مصرح.' }, 403);
    const name = String(body.name || '').trim();
    const username = String(body.username || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (name.length < 2 || username.length < 3 || password.length < 4) {
      return jsonResp({ error: 'بيانات الموظف غير مكتملة.' }, 400);
    }
    if (db.staffUsers.some((u) => u.username.toLowerCase() === username)) {
      return jsonResp({ error: 'اسم المستخدم مستخدم بالفعل.' }, 400);
    }
    const created: StandaloneStaffUser = {
      id: genId('stf'),
      name,
      username,
      roleTitle: String(body.roleTitle || 'موظف'),
      permissions: Array.isArray(body.permissions) ? (body.permissions as PermissionKey[]) : [],
      active: body.active !== false,
      passwordSha256: sha256Hex(password),
      createdAt: new Date().toISOString(),
    };
    db.staffUsers.unshift(created);
    writeLocalDb(db);
    return jsonResp(sanitizeStaff(created), 201);
  }
  if (pathname.startsWith('/api/staff/')) {
    if (user?.role !== 'owner') return jsonResp({ error: 'غير مصرح.' }, 403);
    const id = pathname.replace('/api/staff/', '');
    if (method === 'PUT') {
      const idx = db.staffUsers.findIndex((u) => u.id === id);
      if (idx === -1) return jsonResp({ error: 'غير موجود.' }, 404);
      const cur = db.staffUsers[idx];
      db.staffUsers[idx] = {
        ...cur,
        name: body.name !== undefined ? String(body.name).trim() : cur.name,
        username: body.username !== undefined ? String(body.username).trim().toLowerCase() : cur.username,
        roleTitle: body.roleTitle !== undefined ? String(body.roleTitle).trim() : cur.roleTitle,
        permissions: Array.isArray(body.permissions) ? (body.permissions as PermissionKey[]) : cur.permissions,
        active: body.active !== undefined ? Boolean(body.active) : cur.active,
        passwordSha256: body.newPassword ? sha256Hex(String(body.newPassword)) : cur.passwordSha256,
      };
      writeLocalDb(db);
      return jsonResp(sanitizeStaff(db.staffUsers[idx]));
    }
    if (method === 'DELETE') {
      db.staffUsers = db.staffUsers.filter((u) => u.id !== id);
      writeLocalDb(db);
      return jsonResp({ ok: true });
    }
  }

  // Offers
  if (pathname === '/api/offers' && method === 'GET') {
    return jsonResp(db.offers.filter((o) => o.active));
  }
  if (pathname === '/api/offers/manage' && method === 'GET') {
    if (!hasPerm(user, 'manage_offers')) return jsonResp({ error: 'غير مصرح.' }, 403);
    return jsonResp(db.offers);
  }
  if (pathname === '/api/offers' && method === 'POST') {
    if (!hasPerm(user, 'manage_offers')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const created: PromotionalOffer = {
      id: genId('ofr'),
      title: String(body.title || 'عرض خاص من ASh tech').trim(),
      subtitle: body.subtitle ? String(body.subtitle).trim() : undefined,
      imageUrl: String(body.imageUrl || '').trim(),
      linkTarget: (body.linkTarget as OfferLinkTarget) || 'none',
      active: body.active !== false,
      createdAt: new Date().toISOString(),
    };
    db.offers.unshift(created);
    writeLocalDb(db);
    return jsonResp(created, 201);
  }
  if (pathname.startsWith('/api/offers/')) {
    if (!hasPerm(user, 'manage_offers')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const id = pathname.replace('/api/offers/', '');
    if (method === 'PUT') {
      const idx = db.offers.findIndex((o) => o.id === id);
      if (idx === -1) return jsonResp({ error: 'غير موجود.' }, 404);
      const cur = db.offers[idx];
      db.offers[idx] = {
        ...cur,
        title: body.title !== undefined ? String(body.title).trim() : cur.title,
        subtitle: body.subtitle !== undefined ? String(body.subtitle).trim() || undefined : cur.subtitle,
        imageUrl: body.imageUrl !== undefined ? String(body.imageUrl).trim() : cur.imageUrl,
        linkTarget: (body.linkTarget as OfferLinkTarget) ?? cur.linkTarget,
        active: body.active !== undefined ? Boolean(body.active) : cur.active,
      };
      writeLocalDb(db);
      return jsonResp(db.offers[idx]);
    }
    if (method === 'DELETE') {
      db.offers = db.offers.filter((o) => o.id !== id);
      writeLocalDb(db);
      return jsonResp({ ok: true });
    }
  }

  // Services
  if (pathname === '/api/services' && method === 'GET') {
    return jsonResp(db.services);
  }
  if (pathname === '/api/services' && method === 'POST') {
    if (!hasPerm(user, 'manage_services')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const created: MaintenanceService = {
      id: genId('srv'),
      title: String(body.title || '').trim(),
      category: (body.category as MaintenanceService['category']) || 'هاردوير',
      startingPrice: Number(body.startingPrice || 0),
      estimatedDuration: String(body.estimatedDuration || '60 دقيقة').trim(),
      warranty: String(body.warranty || 'ضمان 3 أشهر').trim(),
      description: String(body.description || '').trim(),
    };
    db.services.push(created);
    writeLocalDb(db);
    return jsonResp(created, 201);
  }
  if (pathname.startsWith('/api/services/')) {
    if (!hasPerm(user, 'manage_services')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const id = pathname.replace('/api/services/', '');
    if (method === 'PUT') {
      const idx = db.services.findIndex((s) => s.id === id);
      if (idx === -1) return jsonResp({ error: 'غير موجود.' }, 404);
      const cur = db.services[idx];
      db.services[idx] = {
        ...cur,
        title: body.title !== undefined ? String(body.title).trim() : cur.title,
        category: (body.category as MaintenanceService['category']) ?? cur.category,
        startingPrice: body.startingPrice !== undefined ? Number(body.startingPrice) : cur.startingPrice,
        estimatedDuration: body.estimatedDuration !== undefined ? String(body.estimatedDuration).trim() : cur.estimatedDuration,
        warranty: body.warranty !== undefined ? String(body.warranty).trim() : cur.warranty,
        description: body.description !== undefined ? String(body.description).trim() : cur.description,
      };
      writeLocalDb(db);
      return jsonResp(db.services[idx]);
    }
    if (method === 'DELETE') {
      db.services = db.services.filter((s) => s.id !== id);
      writeLocalDb(db);
      return jsonResp({ ok: true });
    }
  }

  // Products
  if (pathname === '/api/products' && method === 'GET') {
    return jsonResp(db.products);
  }
  if (pathname === '/api/products' && method === 'POST') {
    if (!hasPerm(user, 'manage_products')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const created: StoreProduct = {
      id: genId('prd'),
      name: String(body.name || '').trim(),
      category: String(body.category || 'عام').trim(),
      price: Number(body.price || 0),
      stock: Number(body.stock ?? 10),
      description: String(body.description || '').trim(),
      imageUrl: String(body.imageUrl || '').trim(),
    };
    db.products.push(created);
    writeLocalDb(db);
    return jsonResp(created, 201);
  }
  if (pathname.startsWith('/api/products/')) {
    if (!hasPerm(user, 'manage_products')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const id = pathname.replace('/api/products/', '');
    if (method === 'PUT') {
      const idx = db.products.findIndex((p) => p.id === id);
      if (idx === -1) return jsonResp({ error: 'غير موجود.' }, 404);
      const cur = db.products[idx];
      db.products[idx] = {
        ...cur,
        name: body.name !== undefined ? String(body.name).trim() : cur.name,
        category: body.category !== undefined ? String(body.category).trim() : cur.category,
        price: body.price !== undefined ? Number(body.price) : cur.price,
        stock: body.stock !== undefined ? Number(body.stock) : cur.stock,
        description: body.description !== undefined ? String(body.description).trim() : cur.description,
        imageUrl: body.imageUrl !== undefined ? String(body.imageUrl).trim() : cur.imageUrl,
      };
      writeLocalDb(db);
      return jsonResp(db.products[idx]);
    }
    if (method === 'DELETE') {
      db.products = db.products.filter((p) => p.id !== id);
      writeLocalDb(db);
      return jsonResp({ ok: true });
    }
  }

  // Devices (Laptops, PCs, Monitors)
  if (pathname === '/api/devices' && method === 'GET') {
    return jsonResp(db.devices);
  }
  if (pathname === '/api/devices' && method === 'POST') {
    if (!hasPerm(user, 'manage_devices')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const validCategories: DeviceCategory[] = ['لاب توب', 'كمبيوتر PC', 'شاشات كمبيوتر'];
    const category: DeviceCategory = validCategories.includes(body.category as DeviceCategory)
      ? (body.category as DeviceCategory)
      : 'لاب توب';
    const validConditions: DeviceCondition[] = ['جديد', 'استيراد بحالة الزيرو', 'كسر زيرو'];
    const condition: DeviceCondition = validConditions.includes(body.condition as DeviceCondition)
      ? (body.condition as DeviceCondition)
      : 'استيراد بحالة الزيرو';
    const rawSpecs = (body.specs ?? {}) as Partial<DeviceSpecs>;
    const defaultImg =
      category === 'كمبيوتر PC'
        ? '/src/assets/images/device_desktop_pc_1794871560266.jpg'
        : category === 'شاشات كمبيوتر'
          ? '/src/assets/images/device_pc_monitor_1794871559355.jpg'
          : '/src/assets/images/device_laptop_pro_1794871559585.jpg';
    const created: ComputerDevice = {
      id: genId('dev'),
      name: String(body.name || '').trim(),
      brand: String(body.brand || 'Dell').trim(),
      category,
      condition,
      price: Number(body.price || 0),
      stock: Number(body.stock ?? 1),
      imageUrl: String(body.imageUrl || '').trim() || defaultImg,
      description: String(body.description || '').trim(),
      specs: {
        processor: String(rawSpecs.processor || '').trim(),
        ram: String(rawSpecs.ram || '').trim(),
        storage: String(rawSpecs.storage || '').trim(),
        gpu: String(rawSpecs.gpu || '').trim(),
        display: String(rawSpecs.display || '').trim(),
        batteryOrPower: String(rawSpecs.batteryOrPower || '').trim(),
        ports: String(rawSpecs.ports || '').trim(),
        warranty: String(rawSpecs.warranty || 'ضمان 6 أشهر').trim(),
      },
    };
    db.devices.unshift(created);
    writeLocalDb(db);
    return jsonResp(created, 201);
  }
  if (pathname.startsWith('/api/devices/')) {
    if (!hasPerm(user, 'manage_devices')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const id = pathname.replace('/api/devices/', '');
    if (method === 'PUT') {
      const idx = db.devices.findIndex((d) => d.id === id);
      if (idx === -1) return jsonResp({ error: 'غير موجود.' }, 404);
      const cur = db.devices[idx];
      const incomingSpecs = (body.specs ?? {}) as Partial<DeviceSpecs>;
      const validCategories: DeviceCategory[] = ['لاب توب', 'كمبيوتر PC', 'شاشات كمبيوتر'];
      const validConditions: DeviceCondition[] = ['جديد', 'استيراد بحالة الزيرو', 'كسر زيرو'];
      db.devices[idx] = {
        ...cur,
        name: body.name !== undefined ? String(body.name).trim() || cur.name : cur.name,
        brand: body.brand !== undefined ? String(body.brand).trim() : cur.brand,
        category: validCategories.includes(body.category as DeviceCategory)
          ? (body.category as DeviceCategory)
          : cur.category,
        condition: validConditions.includes(body.condition as DeviceCondition)
          ? (body.condition as DeviceCondition)
          : cur.condition,
        price: body.price !== undefined ? Number(body.price) : cur.price,
        stock: body.stock !== undefined ? Number(body.stock) : cur.stock,
        imageUrl: body.imageUrl !== undefined ? String(body.imageUrl).trim() || cur.imageUrl : cur.imageUrl,
        description: body.description !== undefined ? String(body.description).trim() : cur.description,
        specs: {
          processor:
            incomingSpecs.processor !== undefined ? String(incomingSpecs.processor).trim() : cur.specs.processor,
          ram: incomingSpecs.ram !== undefined ? String(incomingSpecs.ram).trim() : cur.specs.ram,
          storage:
            incomingSpecs.storage !== undefined ? String(incomingSpecs.storage).trim() : cur.specs.storage,
          gpu: incomingSpecs.gpu !== undefined ? String(incomingSpecs.gpu).trim() : cur.specs.gpu,
          display:
            incomingSpecs.display !== undefined ? String(incomingSpecs.display).trim() : cur.specs.display,
          batteryOrPower:
            incomingSpecs.batteryOrPower !== undefined
              ? String(incomingSpecs.batteryOrPower).trim()
              : cur.specs.batteryOrPower,
          ports: incomingSpecs.ports !== undefined ? String(incomingSpecs.ports).trim() : cur.specs.ports,
          warranty:
            incomingSpecs.warranty !== undefined ? String(incomingSpecs.warranty).trim() : cur.specs.warranty,
        },
      };
      writeLocalDb(db);
      return jsonResp(db.devices[idx]);
    }
    if (method === 'DELETE') {
      db.devices = db.devices.filter((d) => d.id !== id);
      writeLocalDb(db);
      return jsonResp({ ok: true });
    }
  }

  // Site Settings
  if (pathname === '/api/site-settings' && method === 'GET') {
    return jsonResp(db.siteSettings);
  }
  if (pathname === '/api/site-settings' && method === 'PUT') {
    if (!hasPerm(user, 'manage_site_settings')) return jsonResp({ error: 'غير مصرح.' }, 403);
    const cur = db.siteSettings;
    const validPlatforms: SocialPlatform[] = [
      'facebook',
      'youtube',
      'instagram',
      'tiktok',
      'whatsapp',
      'x',
      'linkedin',
    ];
    const str = (v: unknown, fb: string) => (v !== undefined ? String(v).trim() : fb);
    const nextHighlights: HeroHighlightItem[] = Array.isArray(body.heroHighlights)
      ? (body.heroHighlights as Partial<HeroHighlightItem>[]).slice(0, 4).map((item, idx) => ({
          title: str(item?.title, cur.heroHighlights[idx]?.title || ''),
          subtitle: str(item?.subtitle, cur.heroHighlights[idx]?.subtitle || ''),
        }))
      : cur.heroHighlights;
    const nextPhones: ContactPhoneItem[] = Array.isArray(body.contactPhones)
      ? (body.contactPhones as Partial<ContactPhoneItem>[])
          .filter((p) => p && String(p.number || '').trim())
          .map((p) => ({
            id: String(p.id || genId('ph')),
            label: String(p.label || 'هاتف التواصل').trim(),
            number: String(p.number).trim(),
          }))
      : cur.contactPhones;
    const nextSocials: SocialPageLink[] = Array.isArray(body.socialLinks)
      ? (body.socialLinks as Partial<SocialPageLink>[])
          .filter((s) => s && String(s.url || '').trim())
          .map((s) => ({
            id: String(s.id || genId('soc')),
            platform: validPlatforms.includes(s.platform as SocialPlatform)
              ? (s.platform as SocialPlatform)
              : 'facebook',
            label: String(s.label || s.platform || 'صفحة').trim(),
            url: String(s.url).trim(),
          }))
      : cur.socialLinks;
    db.siteSettings = {
      heroKicker: str(body.heroKicker, cur.heroKicker),
      heroTitle: str(body.heroTitle, cur.heroTitle) || cur.heroTitle,
      heroSubtitle: str(body.heroSubtitle, cur.heroSubtitle),
      heroPrimaryCta: str(body.heroPrimaryCta, cur.heroPrimaryCta) || cur.heroPrimaryCta,
      heroSecondaryCta: str(body.heroSecondaryCta, cur.heroSecondaryCta),
      heroImageUrl: str(body.heroImageUrl, cur.heroImageUrl) || cur.heroImageUrl,
      logoUrl: str(body.logoUrl, cur.logoUrl) || cur.logoUrl,
      heroHighlights: nextHighlights,
      servicesTitle: str(body.servicesTitle, cur.servicesTitle) || cur.servicesTitle,
      servicesSubtitle: str(body.servicesSubtitle, cur.servicesSubtitle),
      bookingKicker: str(body.bookingKicker, cur.bookingKicker),
      bookingTitle: str(body.bookingTitle, cur.bookingTitle) || cur.bookingTitle,
      bookingSubtitle: str(body.bookingSubtitle, cur.bookingSubtitle),
      bookingFeature1Title: str(body.bookingFeature1Title, cur.bookingFeature1Title),
      bookingFeature1Desc: str(body.bookingFeature1Desc, cur.bookingFeature1Desc),
      bookingFeature2Title: str(body.bookingFeature2Title, cur.bookingFeature2Title),
      bookingFeature2Desc: str(body.bookingFeature2Desc, cur.bookingFeature2Desc),
      bookingDirectPhoneTitle: str(body.bookingDirectPhoneTitle, cur.bookingDirectPhoneTitle),
      footerDescription: str(body.footerDescription, cur.footerDescription),
      contactPhones: nextPhones,
      socialLinks: nextSocials,
    };
    writeLocalDb(db);
    return jsonResp(db.siteSettings);
  }

  // Orders
  if (pathname === '/api/orders/track' && method === 'GET') {
    const q = (parsedUrl.searchParams.get('query') || '').replace(/\s+/g, '').toLowerCase();
    const matches: TrackedOrderSummary[] = db.orders
      .filter(
        (o) =>
          o.orderNumber.toLowerCase() === q ||
          o.phone.replace(/\s+/g, '').toLowerCase() === q
      )
      .map((o) => ({
        orderNumber: o.orderNumber,
        orderType: o.orderType,
        status: o.status,
        statusUpdatedAt: o.statusUpdatedAt || o.createdAt,
        technicianNotes: o.technicianNotes,
        customerName: o.customerName,
        deviceType: o.deviceType,
        serviceTitle: o.serviceTitle,
        serviceTitles: o.serviceTitles || (o.serviceTitle ? [o.serviceTitle] : undefined),
        preferredDate: o.preferredDate,
        preferredTimeSlot: o.preferredTimeSlot,
        items: o.items,
        estimatedTotal: o.estimatedTotal,
        createdAt: o.createdAt,
      }));
    return jsonResp(matches);
  }

  if (pathname === '/api/orders' && method === 'GET') {
    if (!hasPerm(user, 'view_orders', 'update_order_status')) {
      return jsonResp({ error: 'غير مصرح.' }, 403);
    }
    return jsonResp(db.orders);
  }

  if (pathname === '/api/orders' && method === 'POST') {
    const rawItems = Array.isArray(body.items)
      ? (body.items as Array<{ productId: string; quantity: number }>)
      : [];
    const resolvedItems: OrderCartLine[] = [];
    for (const item of rawItems) {
      const prod =
        db.products.find((p) => p.id === item.productId) ||
        db.devices.find((d) => d.id === item.productId);
      if (prod && item.quantity > 0) {
        resolvedItems.push({
          productId: prod.id,
          productName: prod.name,
          unitPrice: prod.price,
          quantity: Number(item.quantity),
        });
      }
    }
    const productsTotal = resolvedItems.reduce((s, i) => s + i.unitPrice * i.quantity, 0);
    const requestedServiceIds: string[] = Array.isArray(body.serviceIds)
      ? Array.from(new Set(body.serviceIds.map((id) => String(id).trim()).filter(Boolean)))
      : body.serviceId
        ? [String(body.serviceId).trim()]
        : [];
    const matchedServices = requestedServiceIds
      .map((id) => db.services.find((s) => s.id === id))
      .filter((s): s is MaintenanceService => Boolean(s));
    const servicePrice = matchedServices.reduce((sum, s) => sum + s.startingPrice, 0);
    const hasMaint = Boolean(
      body.deviceType || body.problemDescription || matchedServices.length > 0
    );
    const hasProds = resolvedItems.length > 0;
    const nowIso = new Date().toISOString();
    const newOrder: CustomerOrder = {
      id: genId('ord'),
      orderNumber: `ORD-${2400 + db.orders.length + 1}`,
      orderType: hasMaint && hasProds ? 'combined' : hasMaint ? 'maintenance' : 'store',
      status: 'قيد الانتظار',
      statusUpdatedAt: nowIso,
      clientSegment:
        body.clientSegment === 'شركات / مؤسسات' ? 'شركات / مؤسسات' : 'أفراد / منازل',
      customerName: String(body.customerName || '').trim(),
      phone: String(body.phone || '').trim(),
      address: String(body.address || '').trim(),
      deviceType: body.deviceType ? String(body.deviceType).trim() : undefined,
      serviceId: matchedServices[0]?.id,
      serviceIds: matchedServices.length > 0 ? matchedServices.map((s) => s.id) : undefined,
      serviceTitle:
        matchedServices.length > 0
          ? matchedServices.map((s) => s.title).join(' + ')
          : undefined,
      serviceTitles:
        matchedServices.length > 0 ? matchedServices.map((s) => s.title) : undefined,
      serviceStartingPrice: servicePrice,
      problemDescription: body.problemDescription
        ? String(body.problemDescription).trim()
        : undefined,
      preferredDate: body.preferredDate ? String(body.preferredDate).trim() : undefined,
      preferredTimeSlot: body.preferredTimeSlot
        ? String(body.preferredTimeSlot).trim()
        : undefined,
      items: resolvedItems,
      productsTotal,
      estimatedTotal: productsTotal + servicePrice,
      createdAt: nowIso,
    };
    for (const line of resolvedItems) {
      const idx = db.products.findIndex((p) => p.id === line.productId);
      if (idx !== -1) {
        db.products[idx].stock = Math.max(0, db.products[idx].stock - line.quantity);
      } else {
        const dIdx = db.devices.findIndex((d) => d.id === line.productId);
        if (dIdx !== -1) {
          db.devices[dIdx].stock = Math.max(0, db.devices[dIdx].stock - line.quantity);
        }
      }
    }
    db.orders.unshift(newOrder);
    writeLocalDb(db);
    return jsonResp(newOrder, 201);
  }

  if (pathname.startsWith('/api/orders/')) {
    const id = pathname.replace('/api/orders/', '');
    if (method === 'PATCH') {
      if (!hasPerm(user, 'update_order_status')) return jsonResp({ error: 'غير مصرح.' }, 403);
      const idx = db.orders.findIndex((o) => o.id === id);
      if (idx === -1) return jsonResp({ error: 'غير موجود.' }, 404);
      const validStatuses: OrderStatus[] = [
        'قيد الانتظار',
        'جاري التحضير',
        'جاري التوصيل',
        'جاري الصيانة',
        'تم الانتهاء',
        'ملغي',
      ];
      if (body.status !== undefined) {
        if (!validStatuses.includes(body.status as OrderStatus)) {
          return jsonResp({ error: 'حالة الطلب غير صالحة.' }, 400);
        }
        db.orders[idx].status = body.status as OrderStatus;
        db.orders[idx].statusUpdatedAt = new Date().toISOString();
      }
      if (body.technicianNotes !== undefined) {
        db.orders[idx].technicianNotes = String(body.technicianNotes).trim() || undefined;
      }
      if (user) {
        db.orders[idx].lastUpdatedBy = user.name;
      }
      writeLocalDb(db);
      return jsonResp(db.orders[idx]);
    }
    if (method === 'DELETE') {
      if (!hasPerm(user, 'delete_orders')) return jsonResp({ error: 'غير مصرح.' }, 403);
      db.orders = db.orders.filter((o) => o.id !== id);
      writeLocalDb(db);
      return jsonResp({ ok: true });
    }
  }

  return jsonResp({ error: 'المسار غير متاح.' }, 404);
}

export function installStandaloneApiIfNeeded(): void {
  if (typeof window === 'undefined') return;
  const isStandalone =
    window.__ASHTECH_STANDALONE__ === true || window.location.protocol === 'file:';
  if (!isStandalone) return;

  const originalFetch = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;
    if (url.startsWith('/api/')) {
      return handleApiRequest(url, init);
    }
    return originalFetch(input, init);
  };
}
