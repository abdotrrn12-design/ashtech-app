import type { CustomerOrder, SiteSettings } from '../types';
import { DEFAULT_LOGO_URL, formatArabicDate, formatEGP, resolveAssetUrl } from './format';

function loadImageSafe(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function wrapTextLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const words = String(text || '').split(/\s+/).filter(Boolean);
  if (words.length === 0) return [''];
  const lines: string[] = [];
  let current = words[0];
  for (let i = 1; i < words.length; i++) {
    const candidate = `${current} ${words[i]}`;
    if (ctx.measureText(candidate).width <= maxWidth) {
      current = candidate;
    } else {
      lines.push(current);
      current = words[i];
    }
  }
  lines.push(current);
  return lines;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function base64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function buildPdfFromJpeg(
  jpegBytes: Uint8Array,
  imgWidth: number,
  imgHeight: number
): Blob {
  const encoder = new TextEncoder();
  const pageW = 595.28;
  const pageH = 841.89;
  const streamCmd = `q\n${pageW.toFixed(2)} 0 0 ${pageH.toFixed(2)} 0 0 cm\n/Im0 Do\nQ\n`;
  const streamBytes = encoder.encode(streamCmd);

  const chunks: Uint8Array[] = [];
  const offsets: number[] = [0];
  let bytePos = 0;

  const pushStr = (str: string) => {
    const b = encoder.encode(str);
    chunks.push(b);
    bytePos += b.length;
  };
  const pushBytes = (b: Uint8Array) => {
    chunks.push(b);
    bytePos += b.length;
  };

  pushStr('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');

  // 1: Catalog
  offsets.push(bytePos);
  pushStr('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');

  // 2: Pages
  offsets.push(bytePos);
  pushStr('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n');

  // 3: Page
  offsets.push(bytePos);
  pushStr(
    `3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>\nendobj\n`
  );

  // 4: Image XObject
  offsets.push(bytePos);
  pushStr(
    `4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${imgWidth} /Height ${imgHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.length} >>\nstream\n`
  );
  pushBytes(jpegBytes);
  pushStr('\nendstream\nendobj\n');

  // 5: Contents
  offsets.push(bytePos);
  pushStr(`5 0 obj\n<< /Length ${streamBytes.length} >>\nstream\n`);
  pushBytes(streamBytes);
  pushStr('endstream\nendobj\n');

  // xref
  const xrefStart = bytePos;
  pushStr(`xref\n0 ${offsets.length}\n`);
  pushStr('0000000000 65535 f \n');
  for (let i = 1; i < offsets.length; i++) {
    pushStr(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
  }
  pushStr(
    `trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`
  );

  return new Blob(chunks as BlobPart[], { type: 'application/pdf' });
}

function orderTypeArabic(type: CustomerOrder['orderType']): string {
  switch (type) {
    case 'maintenance':
      return 'حجز زيارة صيانة';
    case 'store':
      return 'طلب منتجات من المتجر';
    case 'combined':
      return 'صيانة + منتجات متجر';
  }
}

export async function downloadOrderInvoicePdf(
  order: CustomerOrder,
  siteSettings: SiteSettings
): Promise<void> {
  if (typeof document !== 'undefined' && 'fonts' in document) {
    try {
      await document.fonts.ready;
    } catch {
      // ignore font loading timeout
    }
  }

  const width = 1240;
  const height = 1754;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('تعذر إنشاء الفاتورة.');
  }

  // White paper background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  // Top accent bar
  ctx.fillStyle = '#1d4ed8';
  ctx.fillRect(0, 0, width, 16);

  const margin = 72;
  const rightX = width - margin;
  const leftX = margin;
  const contentW = width - margin * 2;

  // Load company logo
  const logoSrc = resolveAssetUrl(siteSettings.logoUrl || DEFAULT_LOGO_URL);
  const logoImg = await loadImageSafe(logoSrc);

  // Header Brand Area (Right side in RTL)
  let headerY = 64;
  if (logoImg) {
    const ratio = logoImg.width / (logoImg.height || 1);
    const drawH = 74;
    const drawW = Math.min(180, drawH * ratio);
    ctx.drawImage(logoImg, rightX - drawW, headerY, drawW, drawH);

    ctx.direction = 'ltr';
    ctx.textAlign = 'right';
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 34px Cairo, sans-serif';
    ctx.fillText('ASh tech', rightX - drawW - 20, headerY + 34);

    ctx.direction = 'rtl';
    ctx.fillStyle = '#475569';
    ctx.font = '20px "IBM Plex Sans Arabic", Cairo, sans-serif';
    ctx.fillText(
      'للصيانة الهندسية وحلول الأجهزة والمتجر',
      rightX - drawW - 20,
      headerY + 66
    );
  } else {
    ctx.direction = 'ltr';
    ctx.textAlign = 'right';
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 38px Cairo, sans-serif';
    ctx.fillText('ASh tech', rightX, headerY + 38);
  }

  // Invoice Title (Left side)
  ctx.direction = 'rtl';
  ctx.textAlign = 'left';
  ctx.fillStyle = '#1d4ed8';
  ctx.font = 'bold 32px Cairo, sans-serif';
  ctx.fillText('فاتورة طلب ومستند استلام', leftX, headerY + 32);

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 22px "IBM Plex Mono", monospace';
  ctx.fillText(`#${order.orderNumber}`, leftX, headerY + 66);

  // Divider
  let y = 172;
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(leftX, y);
  ctx.lineTo(rightX, y);
  ctx.stroke();

  y += 28;

  // Two Info Cards: Customer Info (Right) + Order Metadata (Left)
  const cardGap = 24;
  const cardW = (contentW - cardGap) / 2;
  const cardH = 196;

  // Customer card (right)
  ctx.fillStyle = '#f8fafc';
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1.5;
  drawRoundedRect(ctx, rightX - cardW, y, cardW, cardH, 12);
  ctx.fill();
  ctx.stroke();

  // Order metadata card (left)
  drawRoundedRect(ctx, leftX, y, cardW, cardH, 12);
  ctx.fill();
  ctx.stroke();

  // Populate Customer Card (RTL right-aligned inside right card)
  ctx.direction = 'rtl';
  ctx.textAlign = 'right';
  const custTextX = rightX - 24;
  ctx.fillStyle = '#1d4ed8';
  ctx.font = 'bold 20px Cairo, sans-serif';
  ctx.fillText('بيانات العميل', custTextX, y + 36);

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 22px Cairo, sans-serif';
  ctx.fillText(order.customerName, custTextX, y + 72);

  ctx.fillStyle = '#334155';
  ctx.font = '20px "IBM Plex Sans Arabic", Cairo, sans-serif';
  ctx.fillText(`الهاتف: ${order.phone}`, custTextX, y + 106);
  ctx.fillText(`الفئة: ${order.clientSegment}`, custTextX, y + 138);

  const addrLines = wrapTextLines(ctx, `العنوان: ${order.address}`, cardW - 48);
  ctx.fillText(addrLines[0] || '', custTextX, y + 170);

  // Populate Order Meta Card (left card, RTL right-aligned inside left card)
  const metaTextX = leftX + cardW - 24;
  ctx.fillStyle = '#1d4ed8';
  ctx.font = 'bold 20px Cairo, sans-serif';
  ctx.fillText('تفاصيل الفاتورة والطلب', metaTextX, y + 36);

  ctx.fillStyle = '#0f172a';
  ctx.font = '20px "IBM Plex Sans Arabic", Cairo, sans-serif';
  ctx.fillText(`نوع الطلب: ${orderTypeArabic(order.orderType)}`, metaTextX, y + 74);
  ctx.fillText(`حالة الطلب: ${order.status}`, metaTextX, y + 108);
  ctx.fillText(`التاريخ: ${formatArabicDate(order.createdAt)}`, metaTextX, y + 142);
  if (order.preferredDate) {
    ctx.fillText(`الموعد المفضل: ${order.preferredDate}`, metaTextX, y + 176);
  }

  y += cardH + 34;

  // Table Header
  const tableHeaderH = 54;
  ctx.fillStyle = '#0f172a';
  drawRoundedRect(ctx, leftX, y, contentW, tableHeaderH, 10);
  ctx.fill();

  const colDescRight = rightX - 24;
  const colQtyCenter = leftX + 390;
  const colUnitCenter = leftX + 240;
  const colTotalLeft = leftX + 24;

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 20px Cairo, sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('البند / الخدمة أو المنتج', colDescRight, y + 34);
  ctx.textAlign = 'center';
  ctx.fillText('الكمية', colQtyCenter, y + 34);
  ctx.fillText('سعر الوحدة', colUnitCenter, y + 34);
  ctx.textAlign = 'left';
  ctx.fillText('الإجمالي', colTotalLeft, y + 34);

  y += tableHeaderH + 8;

  interface InvoiceRow {
    desc: string;
    qty: string;
    unit: string;
    total: string;
  }

  const rows: InvoiceRow[] = [];
  const srvList =
    order.serviceTitles && order.serviceTitles.length > 0
      ? order.serviceTitles
      : order.serviceTitle
        ? [order.serviceTitle]
        : [];

  if (srvList.length > 0) {
    const srvPrice = order.serviceStartingPrice ?? Math.max(0, order.estimatedTotal - order.productsTotal);
    rows.push({
      desc: `خدمات الصيانة: ${srvList.join(' + ')}${order.deviceType ? ` (${order.deviceType})` : ''}`,
      qty: String(srvList.length),
      unit: formatEGP(srvPrice),
      total: formatEGP(srvPrice),
    });
  }

  for (const item of order.items) {
    rows.push({
      desc: item.productName,
      qty: String(item.quantity),
      unit: formatEGP(item.unitPrice),
      total: formatEGP(item.unitPrice * item.quantity),
    });
  }

  if (rows.length === 0) {
    rows.push({
      desc: order.problemDescription || 'خدمة فحص وصيانة',
      qty: '1',
      unit: formatEGP(order.estimatedTotal),
      total: formatEGP(order.estimatedTotal),
    });
  }

  ctx.font = '20px "IBM Plex Sans Arabic", Cairo, sans-serif';
  const maxDescWidth = contentW - 500;

  rows.forEach((row, index) => {
    const descLines = wrapTextLines(ctx, row.desc, maxDescWidth);
    const rowH = Math.max(58, descLines.length * 30 + 28);

    if (index % 2 === 1) {
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(leftX, y, contentW, rowH);
    }

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(leftX, y + rowH);
    ctx.lineTo(rightX, y + rowH);
    ctx.stroke();

    ctx.fillStyle = '#0f172a';
    ctx.textAlign = 'right';
    descLines.forEach((line, lIdx) => {
      ctx.fillText(line, colDescRight, y + 36 + lIdx * 30);
    });

    ctx.textAlign = 'center';
    ctx.fillStyle = '#334155';
    ctx.fillText(row.qty, colQtyCenter, y + 36);
    ctx.fillText(row.unit, colUnitCenter, y + 36);

    ctx.textAlign = 'left';
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 20px Cairo, sans-serif';
    ctx.fillText(row.total, colTotalLeft, y + 36);
    ctx.font = '20px "IBM Plex Sans Arabic", Cairo, sans-serif';

    y += rowH;
  });

  y += 32;

  // Totals Summary Box (Left Side)
  const summaryW = 460;
  const summaryH = 160;
  ctx.fillStyle = '#eff6ff';
  ctx.strokeStyle = '#bfdbfe';
  ctx.lineWidth = 2;
  drawRoundedRect(ctx, leftX, y, summaryW, summaryH, 12);
  ctx.fill();
  ctx.stroke();

  const srvSubtotal =
    order.serviceStartingPrice ?? Math.max(0, order.estimatedTotal - order.productsTotal);

  ctx.direction = 'rtl';
  ctx.font = '20px "IBM Plex Sans Arabic", Cairo, sans-serif';
  ctx.fillStyle = '#334155';
  ctx.textAlign = 'right';
  ctx.fillText('تكلفة خدمات الصيانة المبدئية:', leftX + summaryW - 24, y + 40);
  ctx.textAlign = 'left';
  ctx.fillText(formatEGP(srvSubtotal), leftX + 24, y + 40);

  ctx.textAlign = 'right';
  ctx.fillText('إجمالي المنتجات والأجهزة:', leftX + summaryW - 24, y + 78);
  ctx.textAlign = 'left';
  ctx.fillText(formatEGP(order.productsTotal), leftX + 24, y + 78);

  ctx.strokeStyle = '#93c5fd';
  ctx.beginPath();
  ctx.moveTo(leftX + 20, y + 98);
  ctx.lineTo(leftX + summaryW - 20, y + 98);
  ctx.stroke();

  ctx.fillStyle = '#1d4ed8';
  ctx.font = 'bold 26px Cairo, sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('الإجمالي النهائي:', leftX + summaryW - 24, y + 138);
  ctx.textAlign = 'left';
  ctx.fillText(formatEGP(order.estimatedTotal), leftX + 24, y + 138);

  // Notes on the right side next to summary
  if (order.technicianNotes || order.problemDescription) {
    const notesW = contentW - summaryW - 28;
    ctx.fillStyle = '#f8fafc';
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1.5;
    drawRoundedRect(ctx, rightX - notesW, y, notesW, summaryH, 12);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 20px Cairo, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText('ملاحظات الطلب / الصيانة:', rightX - 20, y + 38);

    ctx.fillStyle = '#475569';
    ctx.font = '18px "IBM Plex Sans Arabic", Cairo, sans-serif';
    const noteText = order.technicianNotes || order.problemDescription || '';
    const noteLines = wrapTextLines(ctx, noteText, notesW - 40).slice(0, 3);
    noteLines.forEach((line, i) => {
      ctx.fillText(line, rightX - 20, y + 72 + i * 28);
    });
  }

  // Footer
  const footerY = height - 110;
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(leftX, footerY);
  ctx.lineTo(rightX, footerY);
  ctx.stroke();

  const phoneSummary =
    siteSettings.contactPhones.length > 0
      ? siteSettings.contactPhones.map((p) => p.number).join(' · ')
      : '01009116199';

  ctx.textAlign = 'center';
  ctx.fillStyle = '#334155';
  ctx.font = 'bold 20px Cairo, sans-serif';
  ctx.fillText(
    'شكراً لثقتكم في ASh tech · خدمة العملاء والدعم الفني: ' + phoneSummary,
    width / 2,
    footerY + 40
  );
  ctx.fillStyle = '#64748b';
  ctx.font = '18px "IBM Plex Sans Arabic", Cairo, sans-serif';
  ctx.fillText(
    'يرجى الاحتفاظ بهذه الفاتورة لمتابعة الضمان وحالة الصيانة.',
    width / 2,
    footerY + 72
  );

  // Convert Canvas to PDF 1.4 Blob and trigger download
  const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
  const b64 = dataUrl.split(',')[1] || '';
  const jpegBytes = base64ToBytes(b64);
  const pdfBlob = buildPdfFromJpeg(jpegBytes, width, height);

  const blobUrl = URL.createObjectURL(pdfBlob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = `ASh-tech-Invoice-${order.orderNumber}.pdf`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(blobUrl), 1500);
}
