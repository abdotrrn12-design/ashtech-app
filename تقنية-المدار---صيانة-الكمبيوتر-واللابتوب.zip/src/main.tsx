import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import {installStandaloneApiIfNeeded} from './utils/standaloneApi.ts';

installStandaloneApiIfNeeded();

createRoot(document.getElementById('root')!).render(<App />);
