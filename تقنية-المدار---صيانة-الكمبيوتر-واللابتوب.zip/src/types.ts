export type ServiceCategory = 'هاردوير' | 'تبريد وتنظيف' | 'سوفت وير' | 'شركات';

export interface MaintenanceService {
  id: string;
  title: string;
  category: ServiceCategory;
  startingPrice: number;
  estimatedDuration: string;
  description: string;
  warranty: string;
}

export type ProductCategory = string;

export interface StoreProduct {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;
  stock: number;
  description: string;
  imageUrl: string;
}

export type DeviceCategory = 'لاب توب' | 'كمبيوتر PC' | 'شاشات كمبيوتر';
export type DeviceCondition = 'جديد' | 'استيراد بحالة الزيرو' | 'كسر زيرو';

export interface DeviceSpecs {
  processor: string;
  ram: string;
  storage: string;
  gpu: string;
  display: string;
  batteryOrPower: string;
  ports: string;
  warranty: string;
}

export interface ComputerDevice {
  id: string;
  name: string;
  brand: string;
  category: DeviceCategory;
  condition: DeviceCondition;
  price: number;
  stock: number;
  imageUrl: string;
  description: string;
  specs: DeviceSpecs;
}

export interface CartItem {
  product: StoreProduct;
  quantity: number;
}

export type OrderType = 'maintenance' | 'store' | 'combined';
export type OrderStatus =
  | 'قيد الانتظار'
  | 'جاري التحضير'
  | 'جاري التوصيل'
  | 'جاري الصيانة'
  | 'تم الانتهاء'
  | 'ملغي';
export type ClientSegment = 'أفراد / منازل' | 'شركات / مؤسسات';

export interface OrderCartLine {
  productId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
}

export interface CustomerOrder {
  id: string;
  orderNumber: string;
  orderType: OrderType;
  status: OrderStatus;
  statusUpdatedAt?: string;
  technicianNotes?: string;
  clientSegment: ClientSegment;
  customerName: string;
  phone: string;
  address: string;
  deviceType?: string;
  serviceId?: string;
  serviceIds?: string[];
  serviceTitle?: string;
  serviceTitles?: string[];
  serviceStartingPrice?: number;
  problemDescription?: string;
  preferredDate?: string;
  preferredTimeSlot?: string;
  items: OrderCartLine[];
  productsTotal: number;
  estimatedTotal: number;
  createdAt: string;
  lastUpdatedBy?: string;
}

export interface TrackedOrderSummary {
  orderNumber: string;
  orderType: OrderType;
  status: OrderStatus;
  statusUpdatedAt?: string;
  technicianNotes?: string;
  customerName: string;
  deviceType?: string;
  serviceTitle?: string;
  serviceTitles?: string[];
  preferredDate?: string;
  preferredTimeSlot?: string;
  items: OrderCartLine[];
  estimatedTotal: number;
  createdAt: string;
}

export type OfferLinkTarget = 'booking' | 'store' | 'none';

export interface PromotionalOffer {
  id: string;
  title: string;
  subtitle?: string;
  imageUrl: string;
  linkTarget: OfferLinkTarget;
  active: boolean;
  createdAt: string;
}

export type SocialPlatform =
  | 'facebook'
  | 'youtube'
  | 'instagram'
  | 'tiktok'
  | 'whatsapp'
  | 'x'
  | 'linkedin';

export interface ContactPhoneItem {
  id: string;
  label: string;
  number: string;
}

export interface SocialPageLink {
  id: string;
  platform: SocialPlatform;
  label: string;
  url: string;
}

export interface HeroHighlightItem {
  title: string;
  subtitle: string;
}

export interface SiteSettings {
  heroKicker: string;
  heroTitle: string;
  heroSubtitle: string;
  heroPrimaryCta: string;
  heroSecondaryCta: string;
  heroImageUrl: string;
  logoUrl: string;
  heroHighlights: HeroHighlightItem[];
  servicesTitle: string;
  servicesSubtitle: string;
  bookingKicker: string;
  bookingTitle: string;
  bookingSubtitle: string;
  bookingFeature1Title: string;
  bookingFeature1Desc: string;
  bookingFeature2Title: string;
  bookingFeature2Desc: string;
  bookingDirectPhoneTitle: string;
  footerDescription: string;
  contactPhones: ContactPhoneItem[];
  socialLinks: SocialPageLink[];
}

export type PermissionKey =
  | 'view_orders'
  | 'update_order_status'
  | 'delete_orders'
  | 'manage_services'
  | 'manage_products'
  | 'manage_devices'
  | 'manage_offers'
  | 'manage_site_settings';

export type UserRole = 'owner' | 'staff';

export interface AuthUser {
  id: string;
  role: UserRole;
  name: string;
  identifier: string;
  roleTitle?: string;
  permissions: PermissionKey[];
}

export interface StaffUser {
  id: string;
  name: string;
  username: string;
  roleTitle: string;
  permissions: PermissionKey[];
  active: boolean;
  lastLoginAt?: string;
  createdAt: string;
}

