import { useCallback, useEffect, useState } from 'react';
import { AccessoriesStore } from './components/AccessoriesStore';
import { AdminPanel } from './components/AdminPanel';
import { CartDrawer } from './components/CartDrawer';
import { CustomerTracking } from './components/CustomerTracking';
import { DevicesStore } from './components/DevicesStore';
import { HomeAndBooking } from './components/HomeAndBooking';
import { ActiveView, Navbar } from './components/Navbar';
import { SocialBrandIcon } from './components/SocialBrandIcon';
import { DEFAULT_LOGO_URL, DEFAULT_SITE_SETTINGS, resolveAssetUrl } from './utils/format';
import type {
  AuthUser,
  CartItem,
  ComputerDevice,
  CustomerOrder,
  MaintenanceService,
  PromotionalOffer,
  SiteSettings,
  StaffUser,
  StoreProduct,
} from './types';

const CART_STORAGE_KEY = 'ashtech_cart_v1';
const ADMIN_TOKEN_KEY = 'ashtech_admin_token_v1';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('home');
  const [trackingQuery, setTrackingQuery] = useState('');
  const [services, setServices] = useState<MaintenanceService[]>([]);
  const [products, setProducts] = useState<StoreProduct[]>([]);
  const [devices, setDevices] = useState<ComputerDevice[]>([]);
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [publicOffers, setPublicOffers] = useState<PromotionalOffer[]>([]);
  const [managedOffers, setManagedOffers] = useState<PromotionalOffer[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);
  const [staffUsers, setStaffUsers] = useState<StaffUser[]>([]);
  const [loadingServices, setLoadingServices] = useState(true);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [loadingDevices, setLoadingDevices] = useState(true);
  const [loadingOrders, setLoadingOrders] = useState(false);

  const [adminToken, setAdminToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem(ADMIN_TOKEN_KEY);
    } catch {
      return null;
    }
  });
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });
  const [cartOpen, setCartOpen] = useState(false);
  const [attachCartToBooking, setAttachCartToBooking] = useState(true);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore storage quota errors
    }
  }, [cart]);

  useEffect(() => {
    try {
      if (adminToken) {
        localStorage.setItem(ADMIN_TOKEN_KEY, adminToken);
      } else {
        localStorage.removeItem(ADMIN_TOKEN_KEY);
      }
    } catch {
      // Ignore storage errors
    }
  }, [adminToken]);

  const fetchPublicData = useCallback(async () => {
    try {
      const [srvRes, prdRes, devRes, ofrRes, setRes] = await Promise.all([
        fetch('/api/services'),
        fetch('/api/products'),
        fetch('/api/devices'),
        fetch('/api/offers'),
        fetch('/api/site-settings'),
      ]);
      if (srvRes.ok) {
        setServices((await srvRes.json()) as MaintenanceService[]);
      }
      if (prdRes.ok) {
        setProducts((await prdRes.json()) as StoreProduct[]);
      }
      if (devRes.ok) {
        setDevices((await devRes.json()) as ComputerDevice[]);
      }
      if (ofrRes.ok) {
        setPublicOffers((await ofrRes.json()) as PromotionalOffer[]);
      }
      if (setRes.ok) {
        setSiteSettings((await setRes.json()) as SiteSettings);
      }
    } finally {
      setLoadingServices(false);
      setLoadingProducts(false);
      setLoadingDevices(false);
    }
  }, []);

  const fetchProtectedData = useCallback(async (token: string) => {
    setLoadingOrders(true);
    try {
      const meRes = await fetch('/api/admin/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!meRes.ok) {
        setAdminToken(null);
        setAuthUser(null);
        setOrders([]);
        setManagedOffers([]);
        setStaffUsers([]);
        return;
      }
      const meData = (await meRes.json()) as { email: string; user: AuthUser };
      const user = meData.user;
      setAuthUser(user);

      const isOwner = user.role === 'owner';
      const canOrders =
        isOwner ||
        user.permissions.includes('view_orders') ||
        user.permissions.includes('update_order_status');
      const canOffers = isOwner || user.permissions.includes('manage_offers');

      const [ordRes, ofrRes, stfRes] = await Promise.all([
        canOrders
          ? fetch('/api/orders', { headers: { Authorization: `Bearer ${token}` } })
          : Promise.resolve(null),
        canOffers
          ? fetch('/api/offers/manage', { headers: { Authorization: `Bearer ${token}` } })
          : Promise.resolve(null),
        isOwner
          ? fetch('/api/staff', { headers: { Authorization: `Bearer ${token}` } })
          : Promise.resolve(null),
      ]);

      if (ordRes && ordRes.ok) {
        setOrders((await ordRes.json()) as CustomerOrder[]);
      } else {
        setOrders([]);
      }
      if (ofrRes && ofrRes.ok) {
        setManagedOffers((await ofrRes.json()) as PromotionalOffer[]);
      } else {
        setManagedOffers([]);
      }
      if (stfRes && stfRes.ok) {
        setStaffUsers((await stfRes.json()) as StaffUser[]);
      } else {
        setStaffUsers([]);
      }
    } finally {
      setLoadingOrders(false);
    }
  }, []);

  useEffect(() => {
    fetchPublicData();
  }, [fetchPublicData]);

  useEffect(() => {
    if (adminToken) {
      fetchProtectedData(adminToken);
    }
  }, [adminToken, fetchProtectedData]);

  const handleNavigate = (view: ActiveView, sectionId?: string) => {
    setActiveView(view);
    if (sectionId) {
      window.setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 60);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleAddToCart = (product: StoreProduct) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + 1, product.stock) }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQty = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.product.id === productId
            ? {
                ...item,
                quantity: Math.min(item.quantity + delta, item.product.stock),
              }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleCombineCartWithBooking = () => {
    setAttachCartToBooking(true);
    handleNavigate('home', 'booking-section');
  };

  const handleOrderCreated = (order: CustomerOrder, clearedCart: boolean) => {
    if (adminToken) {
      setOrders((prev) => [order, ...prev]);
    }
    if (clearedCart) {
      setCart([]);
      fetch('/api/products')
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => {
          if (data) setProducts(data as StoreProduct[]);
        })
        .catch(() => {});
      fetch('/api/devices')
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => {
          if (data) setDevices(data as ComputerDevice[]);
        })
        .catch(() => {});
    }
  };

  const handleAuthLogin = (token: string, user: AuthUser) => {
    setAdminToken(token);
    setAuthUser(user);
  };

  const handleAuthLogout = async () => {
    if (adminToken) {
      try {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${adminToken}` },
        });
      } catch {
        // Ignore network errors on logout
      }
    }
    setAdminToken(null);
    setAuthUser(null);
    setOrders([]);
    setManagedOffers([]);
    setStaffUsers([]);
  };

  const handleOffersUpdated = (nextOffers: PromotionalOffer[]) => {
    setManagedOffers(nextOffers);
    setPublicOffers(nextOffers.filter((o) => o.active));
  };

  const handleTrackOrder = (orderNumber: string) => {
    setTrackingQuery(orderNumber);
    setCartOpen(false);
    handleNavigate('tracking');
  };

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Navbar
        activeView={activeView}
        onNavigate={handleNavigate}
        cartCount={totalCartItems}
        onOpenCart={() => setCartOpen(true)}
        logoUrl={siteSettings.logoUrl}
      />

      <main className="flex-1">
        {activeView === 'home' && (
          <HomeAndBooking
            siteSettings={siteSettings}
            offers={publicOffers}
            services={services}
            loadingServices={loadingServices}
            cart={cart}
            attachCartToBooking={attachCartToBooking}
            onToggleAttachCart={setAttachCartToBooking}
            onOrderCreated={handleOrderCreated}
            onGoToStore={() => handleNavigate('store')}
            onTrackOrder={handleTrackOrder}
          />
        )}

        {activeView === 'devices' && (
          <DevicesStore
            devices={devices}
            loading={loadingDevices}
            cart={cart}
            onAddToCart={handleAddToCart}
            onOpenCart={() => setCartOpen(true)}
          />
        )}

        {activeView === 'store' && (
          <AccessoriesStore
            products={products}
            loading={loadingProducts}
            cart={cart}
            onAddToCart={handleAddToCart}
            onOpenCart={() => setCartOpen(true)}
          />
        )}

        {activeView === 'tracking' && (
          <CustomerTracking initialQuery={trackingQuery} />
        )}

        {(activeView === 'admin' || activeView === 'staff') && (
          <AdminPanel
            portalMode={activeView === 'staff' ? 'staff' : 'admin'}
            adminToken={adminToken}
            authUser={authUser}
            onLoginSuccess={handleAuthLogin}
            onLogout={handleAuthLogout}
            onEmailUpdated={(nextEmail) =>
              setAuthUser((prev) => (prev ? { ...prev, identifier: nextEmail } : prev))
            }
            services={services}
            products={products}
            devices={devices}
            orders={orders}
            offers={managedOffers}
            siteSettings={siteSettings}
            staffUsers={staffUsers}
            loadingOrders={loadingOrders}
            onServicesChange={setServices}
            onProductsChange={setProducts}
            onDevicesChange={setDevices}
            onOrdersChange={setOrders}
            onOffersChange={handleOffersUpdated}
            onSiteSettingsChange={setSiteSettings}
            onStaffChange={setStaffUsers}
          />
        )}
      </main>

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveCartItem}
        onCombineWithBooking={handleCombineCartWithBooking}
        onStandaloneOrderCreated={(order) => handleOrderCreated(order, true)}
        onTrackOrder={handleTrackOrder}
      />

      {/* Quiet Corporate Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-5">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-slate-800/80">
            <div className="flex items-center gap-3.5">
              <div className="bg-white rounded-lg px-2.5 py-1.5 shrink-0">
                <img
                  src={resolveAssetUrl(siteSettings.logoUrl || DEFAULT_LOGO_URL)}
                  alt="شعار ASh tech"
                  className="h-9 w-auto object-contain"
                />
              </div>
              <div>
                <div
                  dir="ltr"
                  className="font-display text-lg font-bold text-white text-end md:text-start"
                >
                  ASh tech
                </div>
                <p className="text-xs text-slate-400 mt-0.5 max-w-sm">
                  {siteSettings.footerDescription}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-6 text-xs">
              <button
                type="button"
                onClick={() => handleNavigate('home', 'services-section')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                خدمات الصيانة
              </button>
              <button
                type="button"
                onClick={() => handleNavigate('home', 'booking-section')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                حجز زيارة
              </button>
              <button
                type="button"
                onClick={() => handleNavigate('devices')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                لاب توب و PC وشاشات
              </button>
              <button
                type="button"
                onClick={() => handleNavigate('store')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                متجر الإكسسوارات
              </button>
              <button
                type="button"
                onClick={() => handleNavigate('tracking')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                متابعة الطلب
              </button>
            </div>

            <div className="flex flex-col items-start md:items-end gap-2.5">
              {siteSettings.contactPhones.length > 0 && (
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 tabular-nums">
                  <span>التواصل:</span>
                  {siteSettings.contactPhones.map((ph) => (
                    <a
                      key={ph.id}
                      href={`tel:${ph.number}`}
                      className="inline-flex items-center gap-1.5 text-slate-200 hover:text-white transition-colors"
                    >
                      {ph.label && (
                        <span className="text-slate-400 text-[11px]">({ph.label})</span>
                      )}
                      <span dir="ltr" className="font-mono-nums font-medium">
                        {ph.number}
                      </span>
                    </a>
                  ))}
                </div>
              )}

              {siteSettings.socialLinks.length > 0 && (
                <div className="flex flex-wrap items-center gap-2">
                  {siteSettings.socialLinks.map((soc) => (
                    <a
                      key={soc.id}
                      href={soc.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={soc.label || soc.platform}
                      title={soc.label || soc.platform}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-blue-700 text-slate-200 hover:text-white border border-slate-700 hover:border-blue-600 flex items-center justify-center transition-colors"
                    >
                      <SocialBrandIcon platform={soc.platform} className="w-4 h-4" />
                    </a>
                  ))}
                </div>
              )}

              <div className="text-[11px] text-slate-500 tabular-nums">
                © {new Date().getFullYear()} ASh tech · جميع الحقوق محفوظة
              </div>
            </div>
          </div>

          {/* Discreet tiny Staff & Admin Panel links at the very bottom of the page */}
          <div className="pt-3 flex items-center justify-end gap-4">
            <button
              type="button"
              onClick={() => handleNavigate('staff')}
              className="text-[11px] leading-none text-slate-600 hover:text-slate-400 transition-colors cursor-pointer"
            >
              دخول الموظفين والعمال
            </button>
            <span className="text-[11px] leading-none text-slate-700" aria-hidden="true">
              ·
            </span>
            <button
              type="button"
              onClick={() => handleNavigate('admin')}
              className="text-[11px] leading-none text-slate-600 hover:text-slate-400 transition-colors cursor-pointer"
            >
              لوحة التحكم (الإدارة)
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
