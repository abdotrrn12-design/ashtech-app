import 'dotenv/config';
import crypto from 'crypto';
import express, { NextFunction, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import type {
  AuthUser,
  ComputerDevice,
  ContactPhoneItem,
  CustomerOrder,
  DeviceCategory,
  DeviceCondition,
  DeviceSpecs,
  HeroHighlightItem,
  MaintenanceService,
  OfferLinkTarget,
  OrderCartLine,
  OrderStatus,
  PermissionKey,
  PromotionalOffer,
  SiteSettings,
  SocialPageLink,
  SocialPlatform,
  StaffUser,
  StoreProduct,
  TrackedOrderSummary,
  UserRole,
} from './src/types';
import { DEFAULT_SITE_SETTINGS } from './src/utils/format';

interface AdminAccount {
  email: string;
  passwordHash: string;
  recoveryCodeHash?: string;
  recoveryExpiresAt?: string;
}

interface StoredStaffUser extends StaffUser {
  passwordHash: string;
}

interface AdminSession {
  token: string;
  userId?: string;
  role?: UserRole;
  email: string;
  createdAt: string;
}

interface DatabaseSchema {
  services: MaintenanceService[];
  products: StoreProduct[];
  devices: ComputerDevice[];
  orders: CustomerOrder[];
  offers: PromotionalOffer[];
  staffUsers: StoredStaffUser[];
  siteSettings: SiteSettings;
  admin: AdminAccount;
  sessions: AdminSession[];
}

const ALL_PERMISSIONS: PermissionKey[] = [
  'view_orders',
  'update_order_status',
  'delete_orders',
  'manage_services',
  'manage_products',
  'manage_devices',
  'manage_offers',
  'manage_site_settings',
];

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const DEFAULT_ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'abdotrrn12@gmail.com';
const DEFAULT_ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ASh@2026';

function hashPassword(password: string, existingSalt?: string): string {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(derived, storedBuf);
}

const SEED_SERVICES: MaintenanceService[] = [
  {
    id: 'srv-thermal',
    title: 'تنظيف شامل وتغيير المعجون الحراري (Thermal Paste)',
    category: 'تبريد وتنظيف',
    startingPrice: 350,
    estimatedDuration: '60 - 90 دقيقة',
    warranty: 'ضمان 3 أشهر على كفاءة التبريد',
    description:
      'تفكيك كامل لنظام التبريد، إزالة الأتربة من المراوح والمشتت الحراري، وتطبيق معجون حراري عالي الكفاءة لخفض الحرارة ومنع التهنيج.',
  },
  {
    id: 'srv-parts',
    title: 'تغيير كيبورد أو بطارية أو شاشة اللاب توب',
    category: 'هاردوير',
    startingPrice: 650,
    estimatedDuration: 'ساعة واحدة',
    warranty: 'ضمان 6 أشهر على القطعة والتركيب',
    description:
      'توفير وتركيب قطع غيار أصلية مطابقة لمواصفات المصنع لجميع الماركات (Dell, HP, Lenovo, Asus, Apple) مع فحص الجهد والبطارية.',
  },
  {
    id: 'srv-windows',
    title: 'تنزيل وتثبيت ويندوز أصلي مع البرامج الأساسية والأوفيس',
    category: 'سوفت وير',
    startingPrice: 250,
    estimatedDuration: '45 - 60 دقيقة',
    warranty: 'دعم فني 30 يوماً',
    description:
      'تثبيت أحدث إصدار مستقر من Windows 10 أو Windows 11 مع تعريفات الجهاز الرسمية، حزمة Microsoft Office، وبرامج الحماية والعمل.',
  },
  {
    id: 'srv-software',
    title: 'حل مشاكل السوفت وير وإزالة الفيروسات وعلاج البطء',
    category: 'سوفت وير',
    startingPrice: 200,
    estimatedDuration: '45 دقيقة',
    warranty: 'ضمان استقرار النظام 30 يوماً',
    description:
      'فحص شامل للنظام، إزالة البرمجيات الخبيثة دون فقدان الملفات المهمة، تحسين إقلاع النظام، وإصلاح أخطاء الشاشة الزرقاء.',
  },
  {
    id: 'srv-hardware',
    title: 'تشخيص وحل أعطال الهاردوير والماذربورد',
    category: 'هاردوير',
    startingPrice: 400,
    estimatedDuration: '24 - 48 ساعة',
    warranty: 'ضمان 3 أشهر على الإصلاح',
    description:
      'فحص دوائر الطاقة واللوحة الأم بأجهزة القياس الدقيقة، إصلاح منافذ الشحن والبيانات، وترقية الرامات وأقراص التخزين NVMe SSD.',
  },
  {
    id: 'srv-b2b',
    title: 'صيانة دورية ودعم فني لأجهزة وشبكات الشركات',
    category: 'شركات',
    startingPrice: 1200,
    estimatedDuration: 'زيارة ميدانية مجدولة',
    warranty: 'اتفاقية مستوى خدمة SLA',
    description:
      'باقة زيارات ميدانية لمقار الشركات والمكاتب تشمل فحص محطات العمل، صيانة الطابعات والشبكة الداخلية، والنسخ الاحتياطي.',
  },
];

const SEED_PRODUCTS: StoreProduct[] = [
  {
    id: 'prd-mouse',
    name: 'ماوس لاسلكي احترافي مريح لليد',
    category: 'ماوس وكيبورد',
    price: 480,
    stock: 18,
    description:
      'دقة استشعار قابلة للتعديل حتى 3200 DPI، نقرات صامتة للعمل المكتبي، واتصال مزدوج بلوتوث وناقل USB لاسلكي.',
    imageUrl: '/src/assets/images/product_wireless_mouse_1794841858426.jpg',
  },
  {
    id: 'prd-keyboard',
    name: 'كيبورد ميكانيكي مدمج بهيكل ألومنيوم',
    category: 'ماوس وكيبورد',
    price: 1450,
    stock: 9,
    description:
      'مفاتيح ميكانيكية خطية هادئة مناسبة للبرمجة والعمل الطويل، هيكل متين باللون الرمادي الداكن مع كابل USB-C قابل للفصل.',
    imageUrl: '/src/assets/images/product_mech_keyboard_1794841858998.jpg',
  },
  {
    id: 'prd-cooling',
    name: 'قاعدة تبريد لاب توب ألومنيوم بمروحتين',
    category: 'قواعد تبريد',
    price: 620,
    stock: 14,
    description:
      'تصميم من الألومنيوم المصقول مع شبكة تهوية عالية التدفق ومروحتين صامتتين، وزوايا ارتفاع مريحة للرقبة.',
    imageUrl: '/src/assets/images/product_cooling_pad_1794841859191.jpg',
  },
  {
    id: 'prd-bag',
    name: 'شنطة لاب توب احترافية مضادة للماء (15.6 بوصة)',
    category: 'شنط لاب توب',
    price: 890,
    stock: 12,
    description:
      'مبطنة بطبقة حماية ثلاثية ضد الصدمات والأمطار، مع جيوب منظمة للشاحن والماوس والمستندات الرسمية.',
    imageUrl: '/src/assets/images/product_laptop_bag_1794841859872.jpg',
  },
  {
    id: 'prd-charger',
    name: 'شاحن لاب توب سريع 65W USB-C بتقنية GaN',
    category: 'شواحن',
    price: 780,
    stock: 15,
    description:
      'شاحن أصلي صغير الحجم مع حماية من تذبذب التيار وكابل مضفر عالي التحمل، متوافق مع أجهزة اللاب توب الحديثة.',
    imageUrl: '/src/assets/images/product_usb_charger_1794841859919.jpg',
  },
  {
    id: 'prd-flash',
    name: 'فلاشة معدنية فائقة السرعة 64 جيجابايت USB 3.2',
    category: 'فلاشات وتخزين',
    price: 320,
    stock: 32,
    description:
      'جسم معدني مقاوم للصدمات والحرارة مع منفذ USB-C / USB-A بسرعة نقل تصل إلى 150 ميجابايت في الثانية.',
    imageUrl: '/src/assets/images/product_usb_charger_1794841859919.jpg',
  },
];

const SEED_DEVICES: ComputerDevice[] = [
  {
    id: 'dev-laptop-1',
    name: 'Dell Precision 5560 Workstation',
    brand: 'Dell',
    category: 'لاب توب',
    condition: 'استيراد بحالة الزيرو',
    price: 34500,
    stock: 4,
    imageUrl: '/src/assets/images/device_laptop_pro_1794871559585.jpg',
    description:
      'لاب توب محطة عمل احترافي بهيكل ألومنيوم نحيف، مخصص لأعمال الهندسة والمونتاج والتصميم ثلاثي الأبعاد.',
    specs: {
      processor: 'Intel Core i7-11850H (8 Cores, up to 4.8GHz)',
      ram: '32GB DDR4 3200MHz',
      storage: '1TB NVMe M.2 SSD Gen4',
      gpu: 'NVIDIA RTX A2000 4GB GDDR6',
      display: '15.6" FHD+ InfinityEdge Anti-Glare 500nits',
      batteryOrPower: 'بطارية 86Wh أصلية بحالة ممتازة + شاحن Type-C 130W',
      ports: '3x Thunderbolt 4 USB-C · قارئ SD Card · منفذ صوت',
      warranty: 'ضمان 6 أشهر شامل الفحص والاستبدال',
    },
  },
  {
    id: 'dev-laptop-2',
    name: 'Lenovo ThinkPad T14 Gen 2 Business',
    brand: 'Lenovo',
    category: 'لاب توب',
    condition: 'استيراد بحالة الزيرو',
    price: 19800,
    stock: 6,
    imageUrl: '/src/assets/images/device_laptop_pro_1794871559585.jpg',
    description:
      'لاب توب أعمال عملي واعتمادي فائق المتانة ومثالي للبرمجة والشركات والعمل اليومي المكثف.',
    specs: {
      processor: 'Intel Core i5-1145G7 (11th Gen vPro)',
      ram: '16GB DDR4 3200MHz',
      storage: '512GB NVMe PCIe SSD',
      gpu: 'Intel Iris Xe Graphics',
      display: '14.0" FHD IPS Matte 300nits',
      batteryOrPower: 'بطارية 50Wh حتى 8 ساعات عمل + شاحن 65W أصلي',
      ports: '2x Thunderbolt 4 · 2x USB-A 3.2 · HDMI 2.0 · RJ-45 LAN',
      warranty: 'ضمان 6 أشهر شامل الصيانة',
    },
  },
  {
    id: 'dev-pc-1',
    name: 'تجميعة ASh Workstation & Gaming Pro',
    brand: 'ASh Custom',
    category: 'كمبيوتر PC',
    condition: 'جديد',
    price: 38900,
    stock: 3,
    imageUrl: '/src/assets/images/device_desktop_pc_1794871560266.jpg',
    description:
      'جهاز كمبيوتر مكتبي متكامل مبني بأحدث معمارية مع تبريد احترافي هوائي للألعاب الثقيلة وأعمال الريندر.',
    specs: {
      processor: 'AMD Ryzen 7 7700X (8 Cores / 16 Threads)',
      ram: '32GB DDR5 5600MHz Dual Channel',
      storage: '1TB NVMe PCIe 4.0 SSD',
      gpu: 'NVIDIA GeForce RTX 4060 8GB GDDR6',
      display: 'يدعم حتى 4 شاشات بدقة 4K',
      batteryOrPower: 'باور سبلاي 750W 80+ Bronze أصلي + كيس احترافي بتهوية عالية',
      ports: 'USB-C 3.2 · 6x USB-A · HDMI 2.1 · 3x DisplayPort · LAN',
      warranty: 'ضمان سنة كاملة على المكونات والتجميع',
    },
  },
  {
    id: 'dev-mon-1',
    name: 'شاشة Dell UltraSharp U2722D احترافية',
    brand: 'Dell',
    category: 'شاشات كمبيوتر',
    condition: 'كسر زيرو',
    price: 13200,
    stock: 5,
    imageUrl: '/src/assets/images/device_pc_monitor_1794871559355.jpg',
    description:
      'شاشة 27 بوصة بدقة 2K وألوان معايرة احترافياً للمصممين والمبرمجين مع حامل هيدروليك متعدد الزوايا.',
    specs: {
      processor: 'لوحة IPS 27 بوصة ألوان دقيقة 100% sRGB / 95% DCI-P3',
      ram: 'معدل تحديث 60Hz · زمن استجابة 5ms',
      storage: 'دقة العرض: QHD (2560 × 1440)',
      gpu: 'سطوع 350 cd/m² · تباين 1000:1 مضاد للانعكاس',
      display: '27" QHD IPS بدون حواف + حامل دوار ومرتفع',
      batteryOrPower: 'استهلاك اقتصادي 25W مع كابل باور أصلي',
      ports: 'HDMI 1.4 · DisplayPort 1.4 In/Out · 4x USB 3.2 Hub',
      warranty: 'ضمان 6 أشهر على البانل والإضاءة',
    },
  },
];

const SEED_ORDERS: CustomerOrder[] = [
  {
    id: 'ord-seed-1',
    orderNumber: 'ORD-2401',
    orderType: 'combined',
    status: 'قيد الانتظار',
    statusUpdatedAt: '2026-11-16T09:15:00.000Z',
    technicianNotes: 'تم استلام الطلب وجاري جدولة زيارة المهندس لمقر الشركة.',
    clientSegment: 'شركات / مؤسسات',
    customerName: 'شركة النيل للاستشارات الهندسية',
    phone: '01012345678',
    address: 'المعادي، شارع 9، مبنى 42، الدور الثالث، القاهرة',
    deviceType: 'لاب توب (3 أجهزة عمل)',
    serviceId: 'srv-thermal',
    serviceTitle: 'تنظيف شامل وتغيير المعجون الحراري (Thermal Paste)',
    serviceStartingPrice: 350,
    problemDescription:
      'ارتفاع ملحوظ في درجة حرارة أجهزة التصميم الهندسي وصوت مرتفع للمراوح أثناء العمل.',
    preferredDate: '2026-11-18',
    preferredTimeSlot: 'صباحاً (10:00 ص - 2:00 م)',
    items: [
      {
        productId: 'prd-cooling',
        productName: 'قاعدة تبريد لاب توب ألومنيوم بمروحتين',
        unitPrice: 620,
        quantity: 2,
      },
    ],
    productsTotal: 1240,
    estimatedTotal: 1590,
    createdAt: '2026-11-16T09:15:00.000Z',
  },
  {
    id: 'ord-seed-2',
    orderNumber: 'ORD-2402',
    orderType: 'maintenance',
    status: 'جاري الصيانة',
    statusUpdatedAt: '2026-11-16T10:00:00.000Z',
    technicianNotes: 'الفني يعمل حالياً على استبدال لوحة المفاتيح واختبار الأزرار.',
    clientSegment: 'أفراد / منازل',
    customerName: 'أحمد محمود عبد الرحمن',
    phone: '01198765432',
    address: 'مدينة نصر، شارع عباس العقاد، عمارة 18، شقة 6',
    deviceType: 'لاب توب Lenovo IdeaPad',
    serviceId: 'srv-parts',
    serviceTitle: 'تغيير كيبورد أو بطارية أو شاشة اللاب توب',
    serviceStartingPrice: 650,
    problemDescription: 'بعض أزرار الكيبورد لا تستجيب وتحتاج لاستبدال كامل.',
    preferredDate: '2026-11-17',
    preferredTimeSlot: 'عصراً (2:00 م - 6:00 م)',
    items: [],
    productsTotal: 0,
    estimatedTotal: 650,
    createdAt: '2026-11-15T14:30:00.000Z',
  },
];

const SEED_OFFERS: PromotionalOffer[] = [
  {
    id: 'ofr-seed-thermal',
    title: 'عرض التبريد الشامل للأجهزة والشركات',
    subtitle: 'فحص حراري وتنظيف كامل مع تغيير المعجون الحراري بأعلى جودة وبضمان 3 أشهر.',
    imageUrl: '/src/assets/images/hero_repair_lab_1794841859240.jpg',
    linkTarget: 'booking',
    active: true,
    createdAt: '2026-11-16T08:00:00.000Z',
  },
  {
    id: 'ofr-seed-accessories',
    title: 'تشكيلة إكسسوارات العمل والشواحن السريعة GaN',
    subtitle: 'اطلب الماوس والكيبورد وقواعد التبريد الألومنيوم الآن مع التوصيل أو مع زيارة المهندس.',
    imageUrl: '/src/assets/images/product_cooling_pad_1794841859191.jpg',
    linkTarget: 'store',
    active: true,
    createdAt: '2026-11-16T08:05:00.000Z',
  },
];

function ensureDatabase(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    const initial: DatabaseSchema = {
      services: SEED_SERVICES,
      products: SEED_PRODUCTS,
      devices: SEED_DEVICES,
      orders: SEED_ORDERS,
      offers: SEED_OFFERS,
      staffUsers: [],
      siteSettings: JSON.parse(JSON.stringify(DEFAULT_SITE_SETTINGS)) as SiteSettings,
      admin: {
        email: DEFAULT_ADMIN_EMAIL.toLowerCase(),
        passwordHash: hashPassword(DEFAULT_ADMIN_PASSWORD),
      },
      sessions: [],
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  const parsed = JSON.parse(raw) as Partial<DatabaseSchema>;
  let dirty = false;
  if (!parsed.admin || !parsed.admin.email || !parsed.admin.passwordHash) {
    parsed.admin = {
      email: DEFAULT_ADMIN_EMAIL.toLowerCase(),
      passwordHash: hashPassword(DEFAULT_ADMIN_PASSWORD),
    };
    dirty = true;
  }
  if (!Array.isArray(parsed.devices)) {
    parsed.devices = SEED_DEVICES;
    dirty = true;
  }
  if (!Array.isArray(parsed.offers)) {
    parsed.offers = SEED_OFFERS;
    dirty = true;
  }
  if (!Array.isArray(parsed.staffUsers)) {
    parsed.staffUsers = [];
    dirty = true;
  }
  if (!parsed.siteSettings || typeof parsed.siteSettings !== 'object') {
    parsed.siteSettings = JSON.parse(JSON.stringify(DEFAULT_SITE_SETTINGS)) as SiteSettings;
    dirty = true;
  } else {
    parsed.siteSettings = {
      ...DEFAULT_SITE_SETTINGS,
      ...parsed.siteSettings,
      heroHighlights:
        Array.isArray(parsed.siteSettings.heroHighlights) &&
        parsed.siteSettings.heroHighlights.length === 4
          ? parsed.siteSettings.heroHighlights
          : DEFAULT_SITE_SETTINGS.heroHighlights,
      contactPhones: Array.isArray(parsed.siteSettings.contactPhones)
        ? parsed.siteSettings.contactPhones
        : DEFAULT_SITE_SETTINGS.contactPhones,
      socialLinks: Array.isArray(parsed.siteSettings.socialLinks)
        ? parsed.siteSettings.socialLinks
        : DEFAULT_SITE_SETTINGS.socialLinks,
    };
  }
  if (!Array.isArray(parsed.sessions)) {
    parsed.sessions = [];
    dirty = true;
  }
  if (Array.isArray(parsed.orders)) {
    const legacyStatusMap: Record<string, OrderStatus> = {
      جديد: 'قيد الانتظار',
      'قيد التنفيذ': 'جاري الصيانة',
      مكتمل: 'تم الانتهاء',
    };
    parsed.orders = parsed.orders.map((ord) => {
      const mapped = legacyStatusMap[String(ord.status)];
      if (mapped) {
        dirty = true;
        return { ...ord, status: mapped };
      }
      return ord;
    });
  }
  const complete = parsed as DatabaseSchema;
  if (dirty) {
    fs.writeFileSync(DB_FILE, JSON.stringify(complete, null, 2), 'utf-8');
  }
  return complete;
}

function readDb(): DatabaseSchema {
  return ensureDatabase();
}

function writeDb(data: DatabaseSchema): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function generateId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return null;
  return header.slice(7).trim() || null;
}

interface AuthenticatedRequest extends Request {
  authUser?: AuthUser;
}

function sanitizeStaffUser(staff: StoredStaffUser): StaffUser {
  const { passwordHash: _ignored, ...rest } = staff;
  return rest;
}

function resolveSessionUser(db: DatabaseSchema, session: AdminSession): AuthUser | null {
  if (!session.role || session.role === 'owner') {
    return {
      id: 'owner',
      role: 'owner',
      name: 'صاحب الشركة (الإدارة)',
      identifier: db.admin.email,
      permissions: ALL_PERMISSIONS,
    };
  }
  const staff = db.staffUsers.find((u) => u.id === session.userId);
  if (!staff || !staff.active) {
    return null;
  }
  return {
    id: staff.id,
    role: 'staff',
    name: staff.name,
    identifier: staff.username,
    roleTitle: staff.roleTitle,
    permissions: staff.permissions,
  };
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  if (!token) {
    res.status(401).json({ error: 'يجب تسجيل الدخول للمتابعة.' });
    return;
  }
  const db = readDb();
  const session = db.sessions.find((s) => s.token === token);
  if (!session) {
    res.status(401).json({ error: 'انتهت الجلسة، يرجى تسجيل الدخول مجدداً.' });
    return;
  }
  const user = resolveSessionUser(db, session);
  if (!user) {
    res.status(401).json({ error: 'الحساب موقوف أو غير متاح حالياً.' });
    return;
  }
  req.authUser = user;
  next();
}

function requireOwner(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  requireAuth(req, res, () => {
    if (req.authUser?.role !== 'owner') {
      res.status(403).json({ error: 'هذه الصلاحية مخصصة لصاحب الشركة فقط.' });
      return;
    }
    next();
  });
}

function requirePermission(...allowed: PermissionKey[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    requireAuth(req, res, () => {
      const user = req.authUser;
      if (!user) return;
      if (user.role === 'owner' || allowed.some((p) => user.permissions.includes(p))) {
        next();
        return;
      }
      res.status(403).json({ error: 'ليس لديك صلاحية لتنفيذ هذا الإجراء.' });
    });
  };
}

async function startServer() {
  ensureDatabase();
  const app = express();
  app.use(express.json({ limit: '8mb' }));
  app.use('/uploads', express.static(UPLOADS_DIR));

  // Admin (Owner) Authentication API
  app.post('/api/admin/login', (req, res) => {
    const { email, password } = req.body ?? {};
    if (!email || !password) {
      res.status(400).json({ error: 'يرجى إدخال البريد الإلكتروني وكلمة المرور.' });
      return;
    }
    const db = readDb();
    const normalizedEmail = String(email).trim().toLowerCase();
    if (
      normalizedEmail !== db.admin.email.toLowerCase() ||
      !verifyPassword(String(password), db.admin.passwordHash)
    ) {
      res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' });
      return;
    }

    const token = crypto.randomBytes(32).toString('hex');
    db.sessions = [
      {
        token,
        userId: 'owner',
        role: 'owner',
        email: db.admin.email,
        createdAt: new Date().toISOString(),
      },
      ...db.sessions.slice(0, 19),
    ];
    writeDb(db);
    const user: AuthUser = {
      id: 'owner',
      role: 'owner',
      name: 'صاحب الشركة (الإدارة)',
      identifier: db.admin.email,
      permissions: ALL_PERMISSIONS,
    };
    res.json({ token, email: db.admin.email, user });
  });

  // Staff / Worker Authentication API
  app.post('/api/staff/login', (req, res) => {
    const { username, password } = req.body ?? {};
    if (!username || !password) {
      res.status(400).json({ error: 'يرجى إدخال اسم المستخدم وكلمة المرور.' });
      return;
    }
    const db = readDb();
    const normalizedUsername = String(username).trim().toLowerCase();
    const staffIndex = db.staffUsers.findIndex(
      (u) => u.username.toLowerCase() === normalizedUsername
    );
    const staff = staffIndex !== -1 ? db.staffUsers[staffIndex] : undefined;

    if (!staff || !verifyPassword(String(password), staff.passwordHash)) {
      res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
      return;
    }
    if (!staff.active) {
      res.status(403).json({
        error: 'تم إيقاف هذا الحساب مؤقتاً من قِبل الإدارة. يرجى التواصل مع المسؤول.',
      });
      return;
    }

    const nowIso = new Date().toISOString();
    db.staffUsers[staffIndex].lastLoginAt = nowIso;

    const token = crypto.randomBytes(32).toString('hex');
    db.sessions = [
      {
        token,
        userId: staff.id,
        role: 'staff',
        email: staff.username,
        createdAt: nowIso,
      },
      ...db.sessions.slice(0, 19),
    ];
    writeDb(db);

    const user: AuthUser = {
      id: staff.id,
      role: 'staff',
      name: staff.name,
      identifier: staff.username,
      roleTitle: staff.roleTitle,
      permissions: staff.permissions,
    };
    res.json({ token, user });
  });

  app.get('/api/admin/me', (req, res) => {
    const token = extractBearerToken(req);
    if (!token) {
      res.status(401).json({ error: 'غير مصرح.' });
      return;
    }
    const db = readDb();
    const session = db.sessions.find((s) => s.token === token);
    if (!session) {
      res.status(401).json({ error: 'جلسة غير صالحة.' });
      return;
    }
    const user = resolveSessionUser(db, session);
    if (!user) {
      res.status(401).json({ error: 'الحساب موقوف أو غير متاح.' });
      return;
    }
    res.json({ email: user.identifier, user });
  });

  app.post('/api/admin/logout', (req, res) => {
    const token = extractBearerToken(req);
    if (token) {
      const db = readDb();
      db.sessions = db.sessions.filter((s) => s.token !== token);
      writeDb(db);
    }
    res.json({ ok: true });
  });

  app.post('/api/admin/credentials', requireOwner, (req, res) => {
    const { currentPassword, newEmail, newPassword } = req.body ?? {};
    if (!currentPassword) {
      res.status(400).json({ error: 'يرجى إدخال كلمة المرور الحالية للتأكيد.' });
      return;
    }
    const db = readDb();
    if (!verifyPassword(String(currentPassword), db.admin.passwordHash)) {
      res.status(401).json({ error: 'كلمة المرور الحالية غير صحيحة.' });
      return;
    }

    const updatedEmail = newEmail
      ? String(newEmail).trim().toLowerCase()
      : db.admin.email;
    if (!updatedEmail.includes('@')) {
      res.status(400).json({ error: 'البريد الإلكتروني الجديد غير صالح.' });
      return;
    }

    db.admin.email = updatedEmail;
    if (newPassword) {
      if (String(newPassword).length < 6) {
        res.status(400).json({ error: 'كلمة المرور الجديدة يجب أن لا تقل عن 6 أحرف.' });
        return;
      }
      db.admin.passwordHash = hashPassword(String(newPassword));
    }

    const token = extractBearerToken(req);
    db.sessions = db.sessions.map((s) =>
      s.token === token ? { ...s, email: updatedEmail } : s
    );
    writeDb(db);
    res.json({ email: updatedEmail });
  });

  app.post('/api/admin/forgot-password', async (req, res) => {
    const { email } = req.body ?? {};
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!normalizedEmail || !normalizedEmail.includes('@')) {
      res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني صحيح.' });
      return;
    }

    const db = readDb();
    if (normalizedEmail === db.admin.email.toLowerCase()) {
      const code = String(crypto.randomInt(100000, 999999));
      db.admin.recoveryCodeHash = hashPassword(code);
      db.admin.recoveryExpiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      writeDb(db);

      const resendKey = process.env.RESEND_API_KEY;
      const fromAddress =
        process.env.ADMIN_RECOVERY_FROM || 'ASh tech <onboarding@resend.dev>';

      if (resendKey) {
        try {
          await fetch('https://api.resend.com/emails', {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${resendKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              from: fromAddress,
              to: [db.admin.email],
              subject: 'رمز استعادة كلمة مرور لوحة تحكم ASh tech',
              html: `<div dir="rtl" style="font-family:sans-serif;line-height:1.8"><h2>استعادة كلمة المرور - ASh tech</h2><p>رمز التحقق الخاص بك هو:</p><p style="font-size:24px;font-weight:bold;letter-spacing:4px">${code}</p><p>الرمز صالح لمدة 15 دقيقة.</p></div>`,
            }),
          });
        } catch (err) {
          console.error('Failed to send recovery email via Resend:', err);
        }
      } else {
        console.info(`[ASh tech Admin Recovery] Code for ${db.admin.email}: ${code}`);
      }
    }

    res.json({
      ok: true,
      message:
        'إذا كان البريد الإلكتروني مطابقاً لحساب الإدارة، فقد تم إرسال رمز التحقق إليه (صالح لمدة 15 دقيقة).',
    });
  });

  app.post('/api/admin/reset-password', (req, res) => {
    const { email, code, newPassword } = req.body ?? {};
    const normalizedEmail = String(email || '').trim().toLowerCase();
    const cleanCode = String(code || '').trim();
    const cleanPassword = String(newPassword || '');

    if (!normalizedEmail || !cleanCode || cleanPassword.length < 6) {
      res.status(400).json({
        error: 'يرجى إدخال البريد الإلكتروني ورمز التحقق وكلمة مرور جديدة (6 أحرف على الأقل).',
      });
      return;
    }

    const db = readDb();
    if (
      normalizedEmail !== db.admin.email.toLowerCase() ||
      !db.admin.recoveryCodeHash ||
      !db.admin.recoveryExpiresAt
    ) {
      res.status(400).json({ error: 'بيانات الاستعادة غير صالحة أو منتهية الصلاحية.' });
      return;
    }

    if (new Date(db.admin.recoveryExpiresAt).getTime() < Date.now()) {
      delete db.admin.recoveryCodeHash;
      delete db.admin.recoveryExpiresAt;
      writeDb(db);
      res.status(400).json({ error: 'انتهت صلاحية رمز التحقق، يرجى طلب رمز جديد.' });
      return;
    }

    if (!verifyPassword(cleanCode, db.admin.recoveryCodeHash)) {
      res.status(400).json({ error: 'رمز التحقق غير صحيح.' });
      return;
    }

    db.admin.passwordHash = hashPassword(cleanPassword);
    delete db.admin.recoveryCodeHash;
    delete db.admin.recoveryExpiresAt;
    db.sessions = [];
    writeDb(db);

    res.json({ ok: true, message: 'تم تحديث كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.' });
  });

  // Single HTML Export API (Owner Only)
  app.get('/api/export-single-html', requireOwner, (_req, res) => {
    const singlePath = path.resolve(process.cwd(), 'ash-tech-single.html');
    if (!fs.existsSync(singlePath)) {
      res.status(404).json({ error: 'ملف HTML الموحد غير متوفر بعد.' });
      return;
    }
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="index.html"');
    res.sendFile(singlePath);
  });

  // Image Upload API (Products, Devices, Offers, or Site Settings permission)
  app.post(
    '/api/upload',
    requirePermission('manage_products', 'manage_offers', 'manage_devices', 'manage_site_settings'),
    (req, res) => {
    const { dataUrl } = req.body ?? {};
    if (typeof dataUrl !== 'string') {
      res.status(400).json({ error: 'صيغة الصورة غير صالحة.' });
      return;
    }
    const match = /^data:image\/(png|jpeg|jpg|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(
      dataUrl
    );
    if (!match) {
      res.status(400).json({
        error: 'يرجى رفع صورة صالحة بصيغة PNG أو JPG أو WEBP.',
      });
      return;
    }
    const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
    const buffer = Buffer.from(match[2], 'base64');
    if (buffer.byteLength > 5 * 1024 * 1024) {
      res.status(400).json({ error: 'حجم الصورة يتجاوز الحد الأقصى (5 ميجابايت).' });
      return;
    }

    if (!fs.existsSync(UPLOADS_DIR)) {
      fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    }
    const fileName = `media_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`;
    fs.writeFileSync(path.join(UPLOADS_DIR, fileName), buffer);
    res.status(201).json({ url: `/uploads/${fileName}` });
  });

  // Staff / Worker Accounts Management API (Owner Only)
  app.get('/api/staff', requireOwner, (_req, res) => {
    const db = readDb();
    res.json(db.staffUsers.map(sanitizeStaffUser));
  });

  app.post('/api/staff', requireOwner, (req, res) => {
    const { name, username, password, roleTitle, permissions, active } = req.body ?? {};
    const cleanName = String(name || '').trim();
    const cleanUsername = String(username || '').trim().toLowerCase();
    const cleanPassword = String(password || '');
    const cleanRoleTitle = String(roleTitle || 'فني / موظف').trim();

    if (cleanName.length < 2 || cleanUsername.length < 3 || cleanPassword.length < 4) {
      res.status(400).json({
        error: 'يرجى إدخال الاسم واسم المستخدم (3 أحرف على الأقل) وكلمة المرور (4 أحرف على الأقل).',
      });
      return;
    }

    const db = readDb();
    if (
      cleanUsername === db.admin.email.toLowerCase() ||
      db.staffUsers.some((u) => u.username.toLowerCase() === cleanUsername)
    ) {
      res.status(400).json({ error: 'اسم المستخدم مستخدم بالفعل، يرجى اختيار اسم آخر.' });
      return;
    }

    const validPerms = Array.isArray(permissions)
      ? permissions.filter((p): p is PermissionKey => ALL_PERMISSIONS.includes(p))
      : [];

    const newStaff: StoredStaffUser = {
      id: generateId('stf'),
      name: cleanName,
      username: cleanUsername,
      roleTitle: cleanRoleTitle,
      permissions: validPerms,
      active: active !== false,
      passwordHash: hashPassword(cleanPassword),
      createdAt: new Date().toISOString(),
    };

    db.staffUsers.unshift(newStaff);
    writeDb(db);
    res.status(201).json(sanitizeStaffUser(newStaff));
  });

  app.put('/api/staff/:id', requireOwner, (req, res) => {
    const { id } = req.params;
    const { name, username, newPassword, roleTitle, permissions, active } = req.body ?? {};
    const db = readDb();
    const index = db.staffUsers.findIndex((u) => u.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'حساب الموظف غير موجود.' });
      return;
    }

    const current = db.staffUsers[index];
    const nextUsername =
      username !== undefined ? String(username).trim().toLowerCase() : current.username;

    if (nextUsername.length < 3) {
      res.status(400).json({ error: 'اسم المستخدم يجب أن لا يقل عن 3 أحرف.' });
      return;
    }
    if (
      nextUsername === db.admin.email.toLowerCase() ||
      db.staffUsers.some((u) => u.id !== id && u.username.toLowerCase() === nextUsername)
    ) {
      res.status(400).json({ error: 'اسم المستخدم مستخدم لحساب آخر.' });
      return;
    }

    if (newPassword && String(newPassword).length < 4) {
      res.status(400).json({ error: 'كلمة المرور الجديدة يجب أن لا تقل عن 4 أحرف.' });
      return;
    }

    const nextPerms = Array.isArray(permissions)
      ? permissions.filter((p): p is PermissionKey => ALL_PERMISSIONS.includes(p))
      : current.permissions;

    const updated: StoredStaffUser = {
      ...current,
      name: name !== undefined ? String(name).trim() || current.name : current.name,
      username: nextUsername,
      roleTitle: roleTitle !== undefined ? String(roleTitle).trim() || current.roleTitle : current.roleTitle,
      permissions: nextPerms,
      active: active !== undefined ? Boolean(active) : current.active,
      passwordHash: newPassword ? hashPassword(String(newPassword)) : current.passwordHash,
    };

    db.staffUsers[index] = updated;
    if (!updated.active) {
      db.sessions = db.sessions.filter((s) => s.userId !== id);
    }
    writeDb(db);
    res.json(sanitizeStaffUser(updated));
  });

  app.delete('/api/staff/:id', requireOwner, (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const nextStaff = db.staffUsers.filter((u) => u.id !== id);
    if (nextStaff.length === db.staffUsers.length) {
      res.status(404).json({ error: 'حساب الموظف غير موجود.' });
      return;
    }
    db.staffUsers = nextStaff;
    db.sessions = db.sessions.filter((s) => s.userId !== id);
    writeDb(db);
    res.json({ ok: true });
  });

  // Promotional Offers API
  app.get('/api/offers', (_req, res) => {
    const db = readDb();
    res.json(db.offers.filter((o) => o.active));
  });

  app.get('/api/offers/manage', requirePermission('manage_offers'), (_req, res) => {
    const db = readDb();
    res.json(db.offers);
  });

  app.post('/api/offers', requirePermission('manage_offers'), (req, res) => {
    const { title, subtitle, imageUrl, linkTarget, active } = req.body ?? {};
    const cleanImage = String(imageUrl || '').trim();
    if (!cleanImage) {
      res.status(400).json({ error: 'يرجى رفع أو اختيار صورة للعرض.' });
      return;
    }
    const validTarget: OfferLinkTarget =
      linkTarget === 'booking' || linkTarget === 'store' ? linkTarget : 'none';
    const db = readDb();
    const newOffer: PromotionalOffer = {
      id: generateId('ofr'),
      title: String(title || '').trim() || 'عرض خاص من ASh tech',
      subtitle: subtitle ? String(subtitle).trim() : undefined,
      imageUrl: cleanImage,
      linkTarget: validTarget,
      active: active !== false,
      createdAt: new Date().toISOString(),
    };
    db.offers.unshift(newOffer);
    writeDb(db);
    res.status(201).json(newOffer);
  });

  app.put('/api/offers/:id', requirePermission('manage_offers'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const index = db.offers.findIndex((o) => o.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'العرض غير موجود.' });
      return;
    }
    const current = db.offers[index];
    const reqTarget = req.body?.linkTarget;
    const nextTarget: OfferLinkTarget =
      reqTarget === 'booking' || reqTarget === 'store' || reqTarget === 'none'
        ? reqTarget
        : current.linkTarget;

    const updated: PromotionalOffer = {
      ...current,
      title:
        req.body.title !== undefined
          ? String(req.body.title).trim() || current.title
          : current.title,
      subtitle:
        req.body.subtitle !== undefined
          ? String(req.body.subtitle).trim() || undefined
          : current.subtitle,
      imageUrl:
        req.body.imageUrl !== undefined
          ? String(req.body.imageUrl).trim() || current.imageUrl
          : current.imageUrl,
      linkTarget: nextTarget,
      active: req.body.active !== undefined ? Boolean(req.body.active) : current.active,
    };
    db.offers[index] = updated;
    writeDb(db);
    res.json(updated);
  });

  app.delete('/api/offers/:id', requirePermission('manage_offers'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const nextOffers = db.offers.filter((o) => o.id !== id);
    if (nextOffers.length === db.offers.length) {
      res.status(404).json({ error: 'العرض غير موجود.' });
      return;
    }
    db.offers = nextOffers;
    writeDb(db);
    res.json({ ok: true });
  });

  // Services API
  app.get('/api/services', (_req, res) => {
    const db = readDb();
    res.json(db.services);
  });

  app.post('/api/services', requirePermission('manage_services'), (req, res) => {
    const { title, category, startingPrice, estimatedDuration, warranty, description } =
      req.body ?? {};
    if (!title || typeof startingPrice !== 'number' || startingPrice < 0) {
      res.status(400).json({ error: 'بيانات الخدمة غير مكتملة أو السعر غير صالح.' });
      return;
    }
    const db = readDb();
    const newService: MaintenanceService = {
      id: generateId('srv'),
      title: String(title).trim(),
      category: category || 'هاردوير',
      startingPrice: Number(startingPrice),
      estimatedDuration: String(estimatedDuration || '60 دقيقة').trim(),
      warranty: String(warranty || 'ضمان 3 أشهر').trim(),
      description: String(description || '').trim(),
    };
    db.services.push(newService);
    writeDb(db);
    res.status(201).json(newService);
  });

  app.put('/api/services/:id', requirePermission('manage_services'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const index = db.services.findIndex((s) => s.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'الخدمة غير موجودة.' });
      return;
    }
    const current = db.services[index];
    const updated: MaintenanceService = {
      ...current,
      title: req.body.title !== undefined ? String(req.body.title).trim() : current.title,
      category: req.body.category ?? current.category,
      startingPrice:
        req.body.startingPrice !== undefined
          ? Number(req.body.startingPrice)
          : current.startingPrice,
      estimatedDuration:
        req.body.estimatedDuration !== undefined
          ? String(req.body.estimatedDuration).trim()
          : current.estimatedDuration,
      warranty:
        req.body.warranty !== undefined ? String(req.body.warranty).trim() : current.warranty,
      description:
        req.body.description !== undefined
          ? String(req.body.description).trim()
          : current.description,
    };
    db.services[index] = updated;
    writeDb(db);
    res.json(updated);
  });

  app.delete('/api/services/:id', requirePermission('manage_services'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const nextServices = db.services.filter((s) => s.id !== id);
    if (nextServices.length === db.services.length) {
      res.status(404).json({ error: 'الخدمة غير موجودة.' });
      return;
    }
    db.services = nextServices;
    writeDb(db);
    res.json({ ok: true });
  });

  // Products API
  app.get('/api/products', (_req, res) => {
    const db = readDb();
    res.json(db.products);
  });

  app.post('/api/products', requirePermission('manage_products'), (req, res) => {
    const { name, category, price, stock, description, imageUrl } = req.body ?? {};
    if (!name || typeof price !== 'number' || price < 0) {
      res.status(400).json({ error: 'بيانات المنتج غير مكتملة أو السعر غير صالح.' });
      return;
    }
    const db = readDb();
    const newProduct: StoreProduct = {
      id: generateId('prd'),
      name: String(name).trim(),
      category: category || 'ماوس وكيبورد',
      price: Number(price),
      stock: typeof stock === 'number' && stock >= 0 ? stock : 10,
      description: String(description || '').trim(),
      imageUrl:
        String(imageUrl || '').trim() ||
        '/src/assets/images/product_wireless_mouse_1794841858426.jpg',
    };
    db.products.push(newProduct);
    writeDb(db);
    res.status(201).json(newProduct);
  });

  app.put('/api/products/:id', requirePermission('manage_products'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const index = db.products.findIndex((p) => p.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'المنتج غير موجود.' });
      return;
    }
    const current = db.products[index];
    const updated: StoreProduct = {
      ...current,
      name: req.body.name !== undefined ? String(req.body.name).trim() : current.name,
      category: req.body.category ?? current.category,
      price: req.body.price !== undefined ? Number(req.body.price) : current.price,
      stock: req.body.stock !== undefined ? Number(req.body.stock) : current.stock,
      description:
        req.body.description !== undefined
          ? String(req.body.description).trim()
          : current.description,
      imageUrl:
        req.body.imageUrl !== undefined ? String(req.body.imageUrl).trim() : current.imageUrl,
    };
    db.products[index] = updated;
    writeDb(db);
    res.json(updated);
  });

  app.delete('/api/products/:id', requirePermission('manage_products'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const nextProducts = db.products.filter((p) => p.id !== id);
    if (nextProducts.length === db.products.length) {
      res.status(404).json({ error: 'المنتج غير موجود.' });
      return;
    }
    db.products = nextProducts;
    writeDb(db);
    res.json({ ok: true });
  });

  // Computer Devices Store API (Laptops, Desktop PCs, Monitors)
  app.get('/api/devices', (_req, res) => {
    const db = readDb();
    res.json(db.devices);
  });

  app.post('/api/devices', requirePermission('manage_devices'), (req, res) => {
    const body = req.body ?? {};
    const name = String(body.name || '').trim();
    const price = Number(body.price);
    if (!name || Number.isNaN(price) || price < 0) {
      res.status(400).json({ error: 'بيانات الجهاز غير مكتملة أو السعر غير صالح.' });
      return;
    }

    const validCategories: DeviceCategory[] = ['لاب توب', 'كمبيوتر PC', 'شاشات كمبيوتر'];
    const category: DeviceCategory = validCategories.includes(body.category)
      ? body.category
      : 'لاب توب';

    const validConditions: DeviceCondition[] = ['جديد', 'استيراد بحالة الزيرو', 'كسر زيرو'];
    const condition: DeviceCondition = validConditions.includes(body.condition)
      ? body.condition
      : 'استيراد بحالة الزيرو';

    const defaultImg =
      category === 'كمبيوتر PC'
        ? '/src/assets/images/device_desktop_pc_1794871560266.jpg'
        : category === 'شاشات كمبيوتر'
          ? '/src/assets/images/device_pc_monitor_1794871559355.jpg'
          : '/src/assets/images/device_laptop_pro_1794871559585.jpg';

    const rawSpecs = (body.specs ?? {}) as Partial<DeviceSpecs>;
    const newDevice: ComputerDevice = {
      id: generateId('dev'),
      name,
      brand: String(body.brand || 'Dell').trim(),
      category,
      condition,
      price,
      stock: typeof body.stock === 'number' && body.stock >= 0 ? body.stock : Number(body.stock ?? 1),
      imageUrl: String(body.imageUrl || '').trim() || defaultImg,
      description: String(body.description || '').trim(),
      specs: {
        processor: String(rawSpecs.processor || '').trim(),
        ram: String(rawSpecs.ram || '').trim(),
        storage: String(rawSpecs.storage || '').trim(),
        gpu: String(rawSpecs.gpu || '').trim(),
        display: String(rawSpecs.display || '').trim(),
        batteryOrPower: String(rawSpecs.batteryOrPower || '').trim(),
        ports: String(rawSpecs.ports || '').trim(),
        warranty: String(rawSpecs.warranty || 'ضمان 6 أشهر').trim(),
      },
    };

    const db = readDb();
    db.devices.unshift(newDevice);
    writeDb(db);
    res.status(201).json(newDevice);
  });

  app.put('/api/devices/:id', requirePermission('manage_devices'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const index = db.devices.findIndex((d) => d.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'الجهاز غير موجود.' });
      return;
    }

    const current = db.devices[index];
    const body = req.body ?? {};
    const validCategories: DeviceCategory[] = ['لاب توب', 'كمبيوتر PC', 'شاشات كمبيوتر'];
    const validConditions: DeviceCondition[] = ['جديد', 'استيراد بحالة الزيرو', 'كسر زيرو'];
    const incomingSpecs = (body.specs ?? {}) as Partial<DeviceSpecs>;

    const updated: ComputerDevice = {
      ...current,
      name: body.name !== undefined ? String(body.name).trim() || current.name : current.name,
      brand: body.brand !== undefined ? String(body.brand).trim() : current.brand,
      category: validCategories.includes(body.category) ? body.category : current.category,
      condition: validConditions.includes(body.condition) ? body.condition : current.condition,
      price: body.price !== undefined ? Number(body.price) : current.price,
      stock: body.stock !== undefined ? Number(body.stock) : current.stock,
      imageUrl:
        body.imageUrl !== undefined ? String(body.imageUrl).trim() || current.imageUrl : current.imageUrl,
      description:
        body.description !== undefined ? String(body.description).trim() : current.description,
      specs: {
        processor:
          incomingSpecs.processor !== undefined
            ? String(incomingSpecs.processor).trim()
            : current.specs.processor,
        ram: incomingSpecs.ram !== undefined ? String(incomingSpecs.ram).trim() : current.specs.ram,
        storage:
          incomingSpecs.storage !== undefined
            ? String(incomingSpecs.storage).trim()
            : current.specs.storage,
        gpu: incomingSpecs.gpu !== undefined ? String(incomingSpecs.gpu).trim() : current.specs.gpu,
        display:
          incomingSpecs.display !== undefined
            ? String(incomingSpecs.display).trim()
            : current.specs.display,
        batteryOrPower:
          incomingSpecs.batteryOrPower !== undefined
            ? String(incomingSpecs.batteryOrPower).trim()
            : current.specs.batteryOrPower,
        ports:
          incomingSpecs.ports !== undefined ? String(incomingSpecs.ports).trim() : current.specs.ports,
        warranty:
          incomingSpecs.warranty !== undefined
            ? String(incomingSpecs.warranty).trim()
            : current.specs.warranty,
      },
    };

    db.devices[index] = updated;
    writeDb(db);
    res.json(updated);
  });

  app.delete('/api/devices/:id', requirePermission('manage_devices'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const nextDevices = db.devices.filter((d) => d.id !== id);
    if (nextDevices.length === db.devices.length) {
      res.status(404).json({ error: 'الجهاز غير موجود.' });
      return;
    }
    db.devices = nextDevices;
    writeDb(db);
    res.json({ ok: true });
  });

  // Site Settings API (Home Texts/Images, Dynamic Contact Phones, Social Pages)
  app.get('/api/site-settings', (_req, res) => {
    const db = readDb();
    res.json(db.siteSettings);
  });

  app.put('/api/site-settings', requirePermission('manage_site_settings'), (req, res) => {
    const body = (req.body ?? {}) as Partial<SiteSettings>;
    const db = readDb();
    const current = db.siteSettings;
    const validPlatforms: SocialPlatform[] = [
      'facebook',
      'youtube',
      'instagram',
      'tiktok',
      'whatsapp',
      'x',
      'linkedin',
    ];

    const str = (val: unknown, fallback: string) =>
      val !== undefined ? String(val).trim() : fallback;

    const nextHighlights: HeroHighlightItem[] = Array.isArray(body.heroHighlights)
      ? body.heroHighlights.slice(0, 4).map((item, idx) => ({
          title: str(item?.title, current.heroHighlights[idx]?.title || ''),
          subtitle: str(item?.subtitle, current.heroHighlights[idx]?.subtitle || ''),
        }))
      : current.heroHighlights;

    const nextPhones: ContactPhoneItem[] = Array.isArray(body.contactPhones)
      ? body.contactPhones
          .filter((p) => p && String(p.number || '').trim())
          .map((p) => ({
            id: String(p.id || generateId('ph')),
            label: String(p.label || 'هاتف التواصل').trim(),
            number: String(p.number).trim(),
          }))
      : current.contactPhones;

    const nextSocials: SocialPageLink[] = Array.isArray(body.socialLinks)
      ? body.socialLinks
          .filter((s) => s && String(s.url || '').trim())
          .map((s) => ({
            id: String(s.id || generateId('soc')),
            platform: validPlatforms.includes(s.platform) ? s.platform : 'facebook',
            label: String(s.label || s.platform).trim(),
            url: String(s.url).trim(),
          }))
      : current.socialLinks;

    const updated: SiteSettings = {
      heroKicker: str(body.heroKicker, current.heroKicker),
      heroTitle: str(body.heroTitle, current.heroTitle) || current.heroTitle,
      heroSubtitle: str(body.heroSubtitle, current.heroSubtitle),
      heroPrimaryCta: str(body.heroPrimaryCta, current.heroPrimaryCta) || current.heroPrimaryCta,
      heroSecondaryCta: str(body.heroSecondaryCta, current.heroSecondaryCta),
      heroImageUrl: str(body.heroImageUrl, current.heroImageUrl) || current.heroImageUrl,
      logoUrl: str(body.logoUrl, current.logoUrl) || current.logoUrl,
      heroHighlights: nextHighlights,
      servicesTitle: str(body.servicesTitle, current.servicesTitle) || current.servicesTitle,
      servicesSubtitle: str(body.servicesSubtitle, current.servicesSubtitle),
      bookingKicker: str(body.bookingKicker, current.bookingKicker),
      bookingTitle: str(body.bookingTitle, current.bookingTitle) || current.bookingTitle,
      bookingSubtitle: str(body.bookingSubtitle, current.bookingSubtitle),
      bookingFeature1Title: str(body.bookingFeature1Title, current.bookingFeature1Title),
      bookingFeature1Desc: str(body.bookingFeature1Desc, current.bookingFeature1Desc),
      bookingFeature2Title: str(body.bookingFeature2Title, current.bookingFeature2Title),
      bookingFeature2Desc: str(body.bookingFeature2Desc, current.bookingFeature2Desc),
      bookingDirectPhoneTitle: str(body.bookingDirectPhoneTitle, current.bookingDirectPhoneTitle),
      footerDescription: str(body.footerDescription, current.footerDescription),
      contactPhones: nextPhones,
      socialLinks: nextSocials,
    };

    db.siteSettings = updated;
    writeDb(db);
    res.json(updated);
  });

  // Orders API (Public POST & order tracking lookup, Admin-only for full list/PATCH/DELETE)
  app.get('/api/orders/track', (req, res) => {
    const rawQuery = String(req.query.query || '').trim();
    if (!rawQuery) {
      res.status(400).json({ error: 'يرجى إدخال رقم الطلب أو رقم الهاتف.' });
      return;
    }
    const normalized = rawQuery.replace(/\s+/g, '').toLowerCase();
    const db = readDb();
    const matches: TrackedOrderSummary[] = db.orders
      .filter(
        (o) =>
          o.orderNumber.toLowerCase() === normalized ||
          o.phone.replace(/\s+/g, '').toLowerCase() === normalized
      )
      .map((o) => ({
        orderNumber: o.orderNumber,
        orderType: o.orderType,
        status: o.status,
        statusUpdatedAt: o.statusUpdatedAt || o.createdAt,
        technicianNotes: o.technicianNotes,
        customerName: o.customerName,
        deviceType: o.deviceType,
        serviceTitle: o.serviceTitle,
        serviceTitles: o.serviceTitles || (o.serviceTitle ? [o.serviceTitle] : undefined),
        preferredDate: o.preferredDate,
        preferredTimeSlot: o.preferredTimeSlot,
        items: o.items,
        estimatedTotal: o.estimatedTotal,
        createdAt: o.createdAt,
      }));
    res.json(matches);
  });

  app.get('/api/orders', requirePermission('view_orders', 'update_order_status'), (_req, res) => {
    const db = readDb();
    res.json(db.orders);
  });

  app.post('/api/orders', (req, res) => {
    const body = req.body ?? {};
    if (!body.customerName || !body.phone || !body.address) {
      res.status(400).json({ error: 'يرجى إدخال الاسم ورقم الهاتف والعنوان بشكل صحيح.' });
      return;
    }

    const db = readDb();
    const rawItems: Array<{ productId: string; quantity: number }> = Array.isArray(body.items)
      ? body.items
      : [];

    const resolvedItems: OrderCartLine[] = [];
    for (const item of rawItems) {
      const catalogItem =
        db.products.find((p) => p.id === item.productId) ||
        db.devices.find((d) => d.id === item.productId);
      if (catalogItem && item.quantity > 0) {
        resolvedItems.push({
          productId: catalogItem.id,
          productName: catalogItem.name,
          unitPrice: catalogItem.price,
          quantity: Number(item.quantity),
        });
      }
    }

    const productsTotal = resolvedItems.reduce(
      (sum, item) => sum + item.unitPrice * item.quantity,
      0
    );

    const requestedServiceIds: string[] = Array.isArray(body.serviceIds)
      ? Array.from(new Set(body.serviceIds.map((id: unknown) => String(id).trim()).filter(Boolean)))
      : body.serviceId
        ? [String(body.serviceId).trim()]
        : [];

    const matchedServices = requestedServiceIds
      .map((id) => db.services.find((s) => s.id === id))
      .filter((s): s is MaintenanceService => Boolean(s));

    const servicePrice = matchedServices.reduce((sum, s) => sum + s.startingPrice, 0);
    const hasMaintenance = Boolean(
      body.deviceType || body.problemDescription || matchedServices.length > 0
    );
    const hasProducts = resolvedItems.length > 0;

    if (!hasMaintenance && !hasProducts) {
      res.status(400).json({ error: 'يجب اختيار خدمة صيانة أو إضافة منتج واحد على الأقل.' });
      return;
    }

    const orderType =
      hasMaintenance && hasProducts ? 'combined' : hasMaintenance ? 'maintenance' : 'store';

    const nowIso = new Date().toISOString();
    const orderNumber = `ORD-${2400 + db.orders.length + 1}`;
    const newOrder: CustomerOrder = {
      id: generateId('ord'),
      orderNumber,
      orderType,
      status: 'قيد الانتظار',
      statusUpdatedAt: nowIso,
      clientSegment: body.clientSegment === 'شركات / مؤسسات' ? 'شركات / مؤسسات' : 'أفراد / منازل',
      customerName: String(body.customerName).trim(),
      phone: String(body.phone).trim(),
      address: String(body.address).trim(),
      deviceType: body.deviceType ? String(body.deviceType).trim() : undefined,
      serviceId: matchedServices[0]?.id,
      serviceIds: matchedServices.length > 0 ? matchedServices.map((s) => s.id) : undefined,
      serviceTitle:
        matchedServices.length > 0
          ? matchedServices.map((s) => s.title).join(' + ')
          : body.serviceTitle
            ? String(body.serviceTitle)
            : undefined,
      serviceTitles:
        matchedServices.length > 0 ? matchedServices.map((s) => s.title) : undefined,
      serviceStartingPrice: servicePrice,
      problemDescription: body.problemDescription
        ? String(body.problemDescription).trim()
        : undefined,
      preferredDate: body.preferredDate ? String(body.preferredDate).trim() : undefined,
      preferredTimeSlot: body.preferredTimeSlot ? String(body.preferredTimeSlot).trim() : undefined,
      items: resolvedItems,
      productsTotal,
      estimatedTotal: productsTotal + servicePrice,
      createdAt: nowIso,
    };

    for (const line of resolvedItems) {
      const pIdx = db.products.findIndex((p) => p.id === line.productId);
      if (pIdx !== -1) {
        db.products[pIdx].stock = Math.max(0, db.products[pIdx].stock - line.quantity);
      } else {
        const dIdx = db.devices.findIndex((d) => d.id === line.productId);
        if (dIdx !== -1) {
          db.devices[dIdx].stock = Math.max(0, db.devices[dIdx].stock - line.quantity);
        }
      }
    }

    db.orders.unshift(newOrder);
    writeDb(db);
    res.status(201).json(newOrder);
  });

  app.patch('/api/orders/:id', requirePermission('update_order_status'), (req: AuthenticatedRequest, res) => {
    const { id } = req.params;
    const { status, technicianNotes } = req.body ?? {};
    const validStatuses: OrderStatus[] = [
      'قيد الانتظار',
      'جاري التحضير',
      'جاري التوصيل',
      'جاري الصيانة',
      'تم الانتهاء',
      'ملغي',
    ];
    if (status !== undefined && !validStatuses.includes(status)) {
      res.status(400).json({ error: 'حالة الطلب غير صالحة.' });
      return;
    }
    const db = readDb();
    const index = db.orders.findIndex((o) => o.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'الطلب غير موجود.' });
      return;
    }
    if (status !== undefined) {
      db.orders[index].status = status;
      db.orders[index].statusUpdatedAt = new Date().toISOString();
    }
    if (technicianNotes !== undefined) {
      db.orders[index].technicianNotes = String(technicianNotes).trim() || undefined;
    }
    if (req.authUser) {
      db.orders[index].lastUpdatedBy = req.authUser.name;
    }
    writeDb(db);
    res.json(db.orders[index]);
  });

  app.delete('/api/orders/:id', requirePermission('delete_orders'), (req, res) => {
    const { id } = req.params;
    const db = readDb();
    const nextOrders = db.orders.filter((o) => o.id !== id);
    if (nextOrders.length === db.orders.length) {
      res.status(404).json({ error: 'الطلب غير موجود.' });
      return;
    }
    db.orders = nextOrders;
    writeDb(db);
    res.json({ ok: true });
  });

  const isProd = process.env.NODE_ENV === 'production' || process.argv.includes('--prod');
  if (isProd) {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
