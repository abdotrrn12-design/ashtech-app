import * as esbuild from 'esbuild';
import fs from 'fs';
import path from 'path';

const rootDir = process.cwd();
const distDir = path.join(rootDir, 'dist');
const distAssetsDir = path.join(distDir, 'assets');
const outputFile = path.join(rootDir, 'ash-tech-single.html');

function mimeTypeFor(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.png') return 'image/png';
  if (ext === '.jpg' || ext === '.jpeg') return 'image/jpeg';
  if (ext === '.webp') return 'image/webp';
  if (ext === '.svg') return 'image/svg+xml';
  return 'application/octet-stream';
}

function collectImageMap() {
  const map = new Map();

  const logoRel = '/assets/aistudio/file_000000007d188210a1641b4a37901e51_a002371b.png';
  const logoAbs = path.join(rootDir, 'public', logoRel);
  if (fs.existsSync(logoAbs)) {
    const b64 = fs.readFileSync(logoAbs).toString('base64');
    map.set(logoRel, `data:${mimeTypeFor(logoAbs)};base64,${b64}`);
  }

  const imagesDir = path.join(rootDir, 'src', 'assets', 'images');
  if (fs.existsSync(imagesDir)) {
    for (const file of fs.readdirSync(imagesDir)) {
      const abs = path.join(imagesDir, file);
      if (fs.statSync(abs).isFile()) {
        const rel = `/src/assets/images/${file}`;
        const b64 = fs.readFileSync(abs).toString('base64');
        map.set(rel, `data:${mimeTypeFor(abs)};base64,${b64}`);
      }
    }
  }

  return map;
}

async function main() {
  if (!fs.existsSync(path.join(distDir, 'index.html'))) {
    throw new Error('dist/index.html not found. Run "npm run build" first.');
  }

  let html = fs.readFileSync(path.join(distDir, 'index.html'), 'utf-8');
  const assetFiles = fs.existsSync(distAssetsDir) ? fs.readdirSync(distAssetsDir) : [];

  const cssFile = assetFiles.find((f) => f.endsWith('.css'));
  const jsFile = assetFiles.find((f) => f.endsWith('.js'));

  if (!cssFile || !jsFile) {
    throw new Error('Built CSS or JS bundle not found in dist/assets.');
  }

  const cssContent = fs.readFileSync(path.join(distAssetsDir, cssFile), 'utf-8');
  let jsContent = fs.readFileSync(path.join(distAssetsDir, jsFile), 'utf-8');

  // Convert ES module output into a classic IIFE script so it runs even over file://
  const transformed = await esbuild.transform(jsContent, {
    loader: 'js',
    format: 'iife',
    target: 'es2020',
    minify: true,
  });
  jsContent = transformed.code;

  // Build single deduplicated Base64 dictionary for all logo, hero, and product images
  const imageMap = collectImageMap();
  const imagesJson = JSON.stringify(Object.fromEntries(imageMap)).replace(
    /<\/script>/gi,
    '<\\/script>'
  );

  // Prevent accidental </script> termination inside inline JS/CSS
  const safeJs = jsContent.replace(/<\/script>/gi, '<\\/script>');
  const safeCss = cssContent.replace(/<\/style>/gi, '<\\/style>');

  // Strip external CSS/JS links emitted by Vite
  html = html.replace(/<link\s+rel="stylesheet"[^>]*>/gi, '');
  html = html.replace(/<script\s+type="module"[^>]*src="[^"]*"[^>]*><\/script>/gi, '');

  // Inline styles into <head>
  html = html.replace(
    '</head>',
    `<style>\n${safeCss}\n</style>\n</head>`
  );

  // Inject standalone flag, embedded images dictionary, and inline app script right before </body>
  html = html.replace(
    '</body>',
    `<script>window.__ASHTECH_STANDALONE__ = true; window.__ASHTECH_IMAGES__ = ${imagesJson};</script>\n<script>\n${safeJs}\n</script>\n</body>`
  );

  fs.writeFileSync(outputFile, html, 'utf-8');
  const sizeMb = (Buffer.byteLength(html, 'utf-8') / (1024 * 1024)).toFixed(2);
  console.log(`Single HTML file generated: ${outputFile} (${sizeMb} MB)`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
